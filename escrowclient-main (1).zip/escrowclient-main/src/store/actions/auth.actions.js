import Auth from '../services/Auth/auth';
import jsCookie from 'js-cookie';

export const register = (params) => {
        return Auth.register(params).then(response => {
            // dispatch({type: REGISTER, payload: response.data});
            return {status: response.status,user:response.data.email, message: "sign up success"};
        }).catch(e => {
            console.log(e.response.data)
            return {status: false, message: e.response.data.message || e.message};
        })
    
};

export const forgotPassword = (params) => {
    return Auth.forgot(params).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return {status: response.status, message: "Password Request Sent"};
    }).catch(e => {
        console.log(e.response.data)
        return {status: false, message: e.response.data.message || e.message};
    })

};
export const resetPassword = (params) => {
    return Auth.resetPass(params).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return {status: response.status, message: "Password Request Sent"};
    }).catch(e => {
        console.log(e.response.data)
        return {status: false, message: e.response.data.message || e.message};
    })

};


export const login = (params) => {
    
        return Auth.login(params).then(response => {
            jsCookie.set('login', {"login":true});
            // jsCookie.set('access', response.data.token);
            console.log("data", response.data)
            
            // localStorage.setItem('user', JSON.stringify({
            //     token: response.data.token,
            //     ...response.data.user
            // }));
            return response;
        }).catch(e => {
            console.log(e.response)
            return  {message: e.response && e.response.data ? e.response.data.message : e.message};
        })
    
};

