import Utils from '../services/Utils/utils';

export const sendOtp = (params) => {

    return Utils.sendOtp(params).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return {status: response.status,otp:response.data.otp, message: "Otp Request Send"};
    }).catch(e => {
        console.log(e.response.data)
        return {status: false, message: e.response.data.message || e.message,otp:e.response.data.otp || e.otp};
    })

};