import Org from '../services/Org/org';
import jsCookie from 'js-cookie';

export const signUpOrganization = (signupForm) => {
    return Org.signUp(signupForm).then(response => {
        return { status: response.status, data: response.data, message: "Request Success" };
    }).catch(e => {
        console.log(e.response.data)
        return { status: false, message: e.response };
    })
}

export const forgotPassword = (params) => {
    return Org.forgotPassword(params).then(response => {
        return { status: response.status, data: response.data, message: "Password Request Sent" };
    }).catch(e => {
        console.log(e.response.data)
        return { status: false, message: e.response.data.message || e.message };
    })

};

export const resetPasswordOrg = (params) => {
    return Org.resetPass(params).then(response => {
        return { status: response.status, message: "Password Request Sent" };
    }).catch(e => {
        console.log(e.response.data)
        return { status: false, message: e.response.data.message || e.message };
    })

};

export const createOrg = (params) => {
    return Org.resetPass(params).then(response => {
        return { status: response.status, message: "Password Request Sent" };
    }).catch(e => {
        console.log(e.response.data)
        return { status: false, message: e.response.data.message || e.message };
    })

};

export const loginOrg = (params) => {
    return Org.login(params).then(response => {
        jsCookie.set('login', '{"login":true}');
        console.log("data", response.data)
        localStorage.setItem('user', JSON.stringify({
            token: response.data,
            ...response.data.user
        }));
        return response;
    }).catch(e => {
        console.log(e.response)
        return { message: e.response && e.response.data ? e.response.data.message : e.message };
    })

};

export const getOrgProfile = (user_id) => {

    return Org.getOrgProfile(user_id).then(response => {
        return { status: response.status, user: response.data, message: "Request Success" };
    }).catch(e => {
        console.log(e.response.data)
        return { status: false, message: e.response.data.message || e.message, otp: e.response.data.otp || e.otp };
    })

};

export const updateOrgProfile = (params) => {

    return Org.updateOrgProfile(params).then(response => {
        return response;
    }).catch(e => {
        console.log(e.response.data)
        return { status: false, message: e.response.data.message || e.message, otp: e.response.data.otp || e.otp };
    })

};



export const addOrgCard = (card) => {

    return Org.addCard(card).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return { status: response.status, data: response.data, message: "Request Success" };
    }).catch(e => {
        console.log(e.response.data)
        return { status: false, message: e.response.data.message || e.message, otp: e.response.data.otp || e.otp };
    })

};
export const addOrgEmployee = (params) => {

    return Org.addOrgEmployee(params).then(response => {
        return response;
    }).catch(e => {
        console.log(e.response.data)
        return { status: false, message: e.response.data.message || e.message, otp: e.response.data.otp || e.otp };
    })

};

export const getOrgCards = (user_id) => {

    return Org.getUserCards(user_id).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return { status: response.status, data: response.data, message: "Request Success" };
    }).catch(e => {
        console.log(e.response.data)
        return { status: false, message: e.response.data.message || e.message, otp: e.response.data.otp || e.otp };
    })

};


export const addOrgAccount = (account) => {

    return Org.addAccount(account).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return { status: response.status, data: response.data, message: "Request Success" };
    }).catch(e => {
        console.log(e.response.data)
        return { status: false, message: e.response.data.message || e.message, otp: e.response.data.otp || e.otp };
    })

};
export const listEmployees = () => {

    return Org.listEmployees().then(response => {
        return response;
    }).catch(e => {
        console.log(e.response.data)
        return { status: false, message: e.response.data.message || e.message, otp: e.response.data.otp || e.otp };
    })

};

export const getOrgAccounts = (user_id) => {

    return Org.getUserAccounts(user_id).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return { status: response.status, data: response.data, message: "Request Success" };
    }).catch(e => {
        console.log(e.response.data)
        return { status: false, message: e.response.data.message || e.message, otp: e.response.data.otp || e.otp };
    })

};
export const deleteOrgRecord = (params) => {

    return Org.deleteOrgRecord(params).then(response => {
        return response;
    }).catch(e => {
        console.log(e.response.data)
        return { status: false, message: e.response.data.message || e.message, otp: e.response.data.otp || e.otp };
    })

};

export const depositOrgMoney = (body) => {

    return Org.depositMoney(body).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return { status: response.status, data: response.data, message: "Request Success" };
    }).catch(e => {
        console.log(e.response.data)
        return { status: false, message: e.response.data.message || e.message, otp: e.response.data.otp || e.otp };
    })

};
export const updateOrgEmployee = (params) => {

    return Org.updateOrgEmployee(params).then(response => {
        return response;
    }).catch(e => {
        console.log(e.response.data)
        return { status: false, message: e.response.data.message || e.message, otp: e.response.data.otp || e.otp };
    })

};

export const dispatchEmpSalary = (employees) => {

    return Org.dispatchSalary(employees).then(response => {
        return response;
    }).catch(e => {
        console.log(e.response.data)
        return { status: e.response.status, message: e.response.data.message || e.message };
    })

};