import Deal from '../services/Deal/deal';

export const initiateDeal = (params) => {

    return Deal.initDeal(params).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return {status: response.status,deal_id:response.data.deal_id, message: "Deal Created Successfully"};
    }).catch(e => {
        console.log(e.response.data)
        return {status: false, message: e.response.data.message || e.message,otp:e.response.data.otp || e.otp};
    })

};

export const getDeal = (params) => {

    return Deal.getDeal(params).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return response;
    }).catch(e => {
        console.log(e.response.data)
        return {status: false, message: e.response.data.message || e.message,otp:e.response.data.otp || e.otp};
    })

};