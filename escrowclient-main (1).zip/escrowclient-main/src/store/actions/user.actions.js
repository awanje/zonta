import User from '../services/User/user';
 
export const getUserProfile = (user_id) => {

    return User.getUserProfile(user_id).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return {status: response.status,user:response.data, message: "Request Success"};
    }).catch(e => {
        console.log(e.response.data)
        return {status: false, message: e.response.data.message || e.message,otp:e.response.data.otp || e.otp};
    })

};

export const getUserDeals = (user_id) => {

    return User.getUserDeals(user_id).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return {status: response.status,data:response.data, message: "Request Success"};
    }).catch(e => {
        console.log(e.response.data)
        return {status: false, message: e.response.data.message || e.message,otp:e.response.data.otp || e.otp};
    })

};


export const addCard = (card) => {

    return User.addCard(card).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return {status: response.status,data:response.data, message: "Request Success"};
    }).catch(e => {
        console.log(e.response.data)
        return {status: false, message: e.response.data.message || e.message,otp:e.response.data.otp || e.otp};
    })

};

export const getUserCards = (user_id) => {

    return User.getUserCards(user_id).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return {status: response.status,data:response.data, message: "Request Success"};
    }).catch(e => {
        console.log(e.response.data)
        return {status: false, message: e.response.data.message || e.message,otp:e.response.data.otp || e.otp};
    })

};


export const addAccount = (account) => {

    return User.addAccount(account).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return {status: response.status,data:response.data, message: "Request Success"};
    }).catch(e => {
        console.log(e.response.data)
        return {status: false, message: e.response.data.message || e.message,otp:e.response.data.otp || e.otp};
    })

};

export const getUserAccounts = (user_id) => {

    return User.getUserAccounts(user_id).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return {status: response.status,data:response.data, message: "Request Success"};
    }).catch(e => {
        console.log(e.response.data)
        return {status: false, message: e.response.data.message || e.message,otp:e.response.data.otp || e.otp};
    })

};


export const depositMoney = (body) => {

    return User.depositMoney(body).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return {status: response.status,data:response.data, message: "Request Success"};
    }).catch(e => {
        console.log(e.response.data)
        return {status: false, message: e.response.data.message || e.message,otp:e.response.data.otp || e.otp};
    })

};

export const withdrawMoney = (body) => {

    return User.withdrawMoney(body).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return {status: response.status,data:response.data, message: "Request Success"};
    }).catch(e => {
        console.log(e.response.data)
        return {status: false, message: e.response.data.message || e.message,otp:e.response.data.otp || e.otp};
    })

};


export const updateUserProfile = (params) => {

    return User.updateUserProfile(params).then(response => {
        // dispatch({type: REGISTER, payload: response.data});
        return response;
    }).catch(e => {
        console.log(e.response.data)
        return {status: false, message: e.response.data.message || e.message,otp:e.response.data.otp || e.otp};
    })

};
