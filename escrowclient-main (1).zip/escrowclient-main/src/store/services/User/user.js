import axiosInstance from '../../../utils/axios';

class User {
   

    static getUserProfile (user_id) {
        let apiPath = '/api/user/get-profile/' + user_id;
        return axiosInstance.get(apiPath);
    }
    
    static updateUserProfile (params) {
        let user_id = params.id;
        delete params.id;
        let apiPath = '/api/user/update-user/' + user_id;
        return axiosInstance.put(apiPath , {
            ...params
        });
    }




    static addCard = (card) => {

        
        let apiPath = '/api/bank/cards';
        return axiosInstance.post(apiPath , {
            ...card
        });
    };
    
    static getUserCards = (user_id) => {
        let apiPath = '/api/bank/cards/' + user_id + `/user`;
        return axiosInstance.get(apiPath );
    };
    
    
    static addAccount = (account) => {
    
        let apiPath = '/api/bank/bankAccounts';
        return axiosInstance.post(apiPath , {
            ...account
        });
    
    };
    
    static depositMoney(body){
        let apiPath = '/api/bank/deposit';
        body.user_type="user"
        return axiosInstance.post(apiPath , body);
    }

    static withdrawMoney(body){
        let apiPath = '/api/bank/withdraw';
        return axiosInstance.post(apiPath , body);
    }

    static getUserAccounts = (user_id) => {
    
        
        let apiPath = '/api/bank/bankAccounts/' + user_id + `/user`;
        return axiosInstance.get(apiPath);
    };

    static getUserDeals (user_id) {
        let apiPath = '/api/deal/userDeals/' + user_id;
        return axiosInstance.get(apiPath);
    }
    
}
export default User;