import axiosInstance from '../../../utils/axios';

class Deal {
    static initDeal (params) {

        return axiosInstance.post('/api/deal/init', {
            ...params
        });

    }
    static getDeal (params) {

        return axiosInstance.get(`/api/deal/${params}`);

    }
    
}
export default Deal;
