import axiosInstance from '../../../utils/axios';

class Utils {

    static sendOtp (params) {
        return axiosInstance.post('/api/util/send-otp', {
            ...params
        });
    }

    
}
export default Utils;
