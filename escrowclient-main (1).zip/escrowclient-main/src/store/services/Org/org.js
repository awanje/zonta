import axiosInstance from '../../../utils/axios';

class Organization {
   

    static signUp (signupForm) {
        let apiPath = '/api/org/register';
        return axiosInstance.post(apiPath, { ...signupForm });
    }

    static forgotPassword (params) {
        let apiPath = '/api/org/forgot-password';
        return axiosInstance.post(apiPath, {
            ...params
        });
    }

    static resetPass (params) {
        return axiosInstance.post('/api/org/reset-password', {
            ...params
        });
    }

    static login (params) {
        return axiosInstance.post('/api/org/login', {
            ...params
        });
    }

    static getOrgProfile (user_id) {
        let apiPath = '/api/org/' + user_id;
        return axiosInstance.get(apiPath);
    }

    static updateOrgProfile (params) {
        let user_id = params.id;
        delete params.id;
        let apiPath = '/api/org/update-org/' + user_id;
        return axiosInstance.put(apiPath , {
            ...params
        });
    }


    



    static addCard = (card) => {

        
        let apiPath = '/api/bank/cards';
        return axiosInstance.post(apiPath , {
            ...card
        });
    };
    
    static getUserCards = (user_id) => {
        let apiPath = '/api/bank/cards/' + user_id + `/org`;
        return axiosInstance.get(apiPath );
    };
    
    
    static addAccount = (account) => {
    
        let apiPath = '/api/bank/bankAccounts';
        return axiosInstance.post(apiPath , {
            ...account
        });
    
    };
    
    static depositMoney(body){
        let apiPath = '/api/bank/deposit';
        body.user_type="org"
        return axiosInstance.post(apiPath , body);
    }


    static getUserAccounts = (user_id) => {
    
        
        let apiPath = '/api/bank/bankAccounts/' + user_id + `/org`;
        return axiosInstance.get(apiPath);
    };
    static addOrgEmployee (params) {
        return axiosInstance.post('/api/org/addEmp', {
            ...params
        });
    }

    static listEmployees () {
        return axiosInstance.get('/api/org/listEmp');
    }
    
    static deleteOrgRecord (user_id) {
        return axiosInstance.put('/api/org/updateEmp/' + user_id);
    }
    
    static updateOrgEmployee (params) {
        let user_id = params.user_id;
        delete params.user_id;
        return axiosInstance.put('/api/org/updateEmp/' + user_id , {
            ...params
        });
    }

    static dispatchSalary (employees) {
        
        return axiosInstance.post(`/api/org/dispatchSalary` , {users:employees});
    }
    
}
export default Organization;