import React , {useEffect , useState} from 'react'
import PreLoader from '../mini_features/PreLoader.jsx'
import ForgotPasswordWrapper from './forgotOrgPasswordWrapper'
import NavBar from '../menu/NavBarWhite.jsx'
import ForgotOrgSuccess from './forgotOrgPasswordSuccess'
import Footer from '../common/Footer'
import $ from 'jquery'

const ForgotPassword=()=> {
    const [forgotOrgPasswordSuccess, setforgotOrgPasswordSuccess ] = useState(false);
    useEffect(() => {
        $('[data-loader="circle-side"]').fadeOut() 
              $('#preloader').delay(333).fadeOut('slow')
              $('body').delay(333) 
      })
    return (
        <>
            <PreLoader />
            <NavBar />
            {forgotOrgPasswordSuccess ? <ForgotOrgSuccess /> : <ForgotPasswordWrapper
            forgotPasswordSetter = {setforgotOrgPasswordSuccess} />  }
            
            <Footer />
        </>
    )
}
export default ForgotPassword;