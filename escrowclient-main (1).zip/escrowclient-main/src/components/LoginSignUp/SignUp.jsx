import React , {useEffect , useState} from 'react'
import PreLoader from '../mini_features/PreLoader.jsx'
import SignUpWrapper from './SignUpWrapper'
import NavBar from '../menu/NavBarWhite.jsx'
import SignUpSuccess from './SignUpSuccess'
import Footer from '../common/Footer'
import $ from 'jquery'
 
export default function SignUp() {
    const [signupSuccess, setSignupSuccess ] = useState(false);
    useEffect(() => {
        $('[data-loader="circle-side"]').fadeOut() 
              $('#preloader').delay(333).fadeOut('slow')
              $('body').delay(333) 
      })
    return (
        <>
            <PreLoader />
            <NavBar />
            {signupSuccess ? <SignUpSuccess /> : <SignUpWrapper
            signupSetter = {setSignupSuccess} />  }
            
            <Footer />
        </>
    )
}