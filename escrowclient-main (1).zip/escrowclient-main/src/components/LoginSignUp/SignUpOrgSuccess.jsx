import React from 'react'
export default function SignUpSuccess() {
    return (
        <div class="login-signup-page mx-auto my-5">
            <h3 class="font-weight-400 text-center">Sign Up As an Organization</h3>
            <p class="lead text-center">Your Sign Up information is safe with us.</p>
            <div class="bg-light shadow-md rounded p-4 mx-2">
                <div className="text-center my-5">
                    <p className="text-center text-success text-20 line-height-07"><i className="fas fa-check-circle"></i></p>
                    <p className="text-center text-success text-8 line-height-07">Success!</p>
                    <p className="text-center text-4">Your sign up request has been submitted successfully to company for review. Please wait for the confirmation email</p>
                </div>
            </div>
        </div>
    )
}
