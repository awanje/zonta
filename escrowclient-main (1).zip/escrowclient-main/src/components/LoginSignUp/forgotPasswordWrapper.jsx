import React, { useState, useRef, useEffect } from 'react'
import SimpleReactValidator from 'simple-react-validator';
import { Link } from "react-router-dom"
import { forgotPassword } from "../../store/actions/auth.actions"


const ForgotPasswordWrapper =(props)=>{
    const simpleValidator = useRef(new SimpleReactValidator());
    const [form,setForm]=useState({email:''})
    const [hasError, setHasError] = useState(false);
    const handleChange=(e)=>{
        const { name, value } = e.target;
        simpleValidator.current.showMessageFor(name)
setForm({[name]:value})
    }
    const handleFormSubmit=async()=>{
        if (simpleValidator.current.allValid()) {
            let response = await forgotPassword(form);
            let status=response.status;
            if(status){
props.forgotPasswordSetter(true);
            }else {
                setHasError(true)
              }
      
        }

    }
    return (<>
        {hasError?<h1 style={{textAlign:"center"}}>Bad Request</h1>:
<div class="login-signup-page mx-auto my-5">
          <h3 class="font-weight-400 text-center">Forgot Password</h3>
          <p class="lead text-center">Your information is safe with us.</p>
          <div class="bg-light shadow-md rounded p-4 mx-2">
            <form id="forgotForm" method="post">
             
              <div class="form-group">
                <label for="emailAddress">Email Address</label>
                <input type="email" onChange={handleChange} name="email" class="form-control" id="emailAddress" required placeholder="Enter Your Email" />
                {simpleValidator.current.message('email', form.email, 'required|email', { className: 'text-danger' })}
              </div>
             
              <button class="btn btn-primary btn-block my-4" type="button" onClick={handleFormSubmit}>Reset Password</button>
            </form>
 
          </div>
        </div>}
        </>
    )
}
export default ForgotPasswordWrapper;