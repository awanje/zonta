import React , {useEffect} from 'react'
import PreLoader from '../mini_features/PreLoader.jsx'
import LoginWrapper from './LoginWrapper'
import $ from 'jquery'
import { PinDropSharp } from '@material-ui/icons'

export default function Login(props) {
    useEffect(() => {
        $('[data-loader="circle-side"]').fadeOut() 
              $('#preloader').delay(333).fadeOut('slow')
              $('body').delay(333) 
      })
    return (
        <>
            <PreLoader />
            <LoginWrapper type = {props.type}/>
        </>
    )
}
