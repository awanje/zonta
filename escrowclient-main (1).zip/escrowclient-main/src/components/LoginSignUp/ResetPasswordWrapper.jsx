import React, { useState, useRef, useEffect } from 'react'
import SimpleReactValidator from 'simple-react-validator';
import { Link, useHistory } from "react-router-dom"
import { Redirect } from "react-router"
import { resetPassword } from "../../store/actions/auth.actions"
import { resetPasswordOrg } from "../../store/actions/org.actions"


const ResetPasswordWrapper = (props) => {
  const queryString = window.location.search;
  const urlParams = new URLSearchParams(queryString);
  const token = urlParams.get("token");
  const history = useHistory();

  const getPathname = window.location.pathname;
  
  useEffect(() => {
    console.log(token)
    if (token === null) {
      history.push({ pathname: '/login' });
    }
  }, [])
  const simpleValidator = useRef(new SimpleReactValidator());
  const [resetForm, setResetForm] = useState({ password: '', confirmPassword: '', passwordValidity: true })
  const [hasError, setHasError] = useState(false);
  const handleFormChange = (e) => {
    const { name, value } = e.target;
    simpleValidator.current.showMessageFor(name)
    setResetForm(prevValue => {
      return {
        ...prevValue,
        [name]: value
      }
    })
  }
  const handleFormSubmit = async () => {
    if (simpleValidator.current.allValid()) {
      if (resetForm.password === resetForm.confirmPassword) {
        delete resetForm.confirmPassword;
        delete resetForm.passwordValidity;
        resetForm.token = token;
        let response = "";
        if( getPathname === "/reset" ) {
          console.log(getPathname);
          response = await resetPassword(resetForm);
        } else if ( getPathname === "/resetOrg" || getPathname === "/createOrg" ) {
          response = await resetPasswordOrg(resetForm);
        }
        let status = response.status;
        if (status) {
          props.resetPasswordSetter(true);
          props.pathSetter(getPathname);
        } else {
          setHasError(true)
        }

      }
    }
    else {
      setResetForm(prevValue => {
        return {
          ...prevValue,
          passwordValidity: false
        }
      })
    }
  }
  return (<>
    {hasError ? <h1 style={{ textAlign: "center" }}>Bad Request</h1> :
      <div class="login-signup-page mx-auto my-5">
        <h3 class="font-weight-400 text-center">{getPathname === "/createOrg" ? "Create your Organization password" : "Reset Password"}</h3>
        <p class="lead text-center">Your information is safe with us.</p>
        <div class="bg-light shadow-md rounded p-4 mx-2">
          <form id="forgotForm" method="post">

            <div class="form-group">
              <label for="loginPassword">Password</label>
              <input type="password" onChange={handleFormChange} name="password" class="form-control" required placeholder="Enter Password" />
              {simpleValidator.current.message('password', resetForm.password, 'required|max:20', { className: 'text-danger' })}
            </div>
            <div class="form-group">
              <label for="loginPassword">Confirm Password</label>
              <input type="password" onChange={handleFormChange} class="form-control" name="confirmPassword" required placeholder="Confirm Password" />
              {simpleValidator.current.message('confirmPassword', resetForm.confirmPassword, 'required|max:20', { className: 'text-danger' })}
              {resetForm.passwordValidity ? null : <p className="text-danger">Both Passwords do not match</p>}
            </div>

            <button class="btn btn-primary btn-block my-4" type="button" onClick={handleFormSubmit}>{getPathname === "/createOrg" ? "Create password" : "Reset Password"}</button>
          </form>

        </div>
      </div>}
  </>
  )
}
export default ResetPasswordWrapper;