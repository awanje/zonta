import React, { useState, useRef, useEffect } from 'react'
import SimpleReactValidator from 'simple-react-validator';
import { Link } from "react-router-dom"
import { register } from "../../store/actions/auth.actions"

export default function SignUpWrapper(props) {
  const simpleValidator = useRef(new SimpleReactValidator());
  const [hasError, setHasError] = useState(false);
  const [signupForm, setSignupForm] = useState({
    full_name: "",
    email: "",
    password: "",
    confirmPassword: "",
    phone: "",
    render: false,
    passwordValidity: true

  });

  function handleFormChange(event) {
    const { name, value } = event.target;
    simpleValidator.current.showMessageFor(name)
    setSignupForm(prevValue => {
      return {
        ...prevValue,
        [name]: value
      }
    })
  }

  async function handleFormSubmit() {
    if (simpleValidator.current.allValid()) {
      if (signupForm.password === signupForm.confirmPassword) {
        // register(signupForm).then((response) => {
        //   let status = response.status;
        //   console.log(response);
        //   if (status) {
        //     alert("Yuhoo....You've Signed up for our platform");
        //     props.signupSetter(true);
        //   } else {
        //     setHasError(true)
        //   }
        // });
        let response = await register(signupForm);
        let status = response.status;
        console.log(response);
        if (status) {
          //alert("Yuhoo....You've Signed up for our platform");
          props.signupSetter(true);
        } else {
          setHasError(true)
        }

      } else {
        setSignupForm(prevValue => {
          return {
            ...prevValue,
            passwordValidity: false
          }
        })
      }

    } else {
      simpleValidator.current.showMessages();
      setSignupForm(prevValue => {
        return {
          ...prevValue,
          render: true
        }
      })
    }
  }

  useEffect(() => {

  }, [signupForm.render])
  return (
    <>
      { !hasError &&
        <div class="login-signup-page mx-auto my-5">
          <h3 class="font-weight-400 text-center">Sign Up</h3>
          <p class="lead text-center">Your Sign Up information is safe with us.</p>
          <div class="bg-light shadow-md rounded p-4 mx-2">
            <form id="signupForm" method="post">
              <div class="form-group">
                <label for="fullName">Full Name</label>
                <input type="text" onChange={handleFormChange} class="form-control" name="full_name" required placeholder="Enter Your Name" />
                {simpleValidator.current.message('full_name', signupForm.full_name, 'required|max:24', { className: 'text-danger' })}
              </div>
              <div class="form-group">
                <label for="emailAddress">Email Address</label>
                <input type="email" onChange={handleFormChange} name="email" class="form-control" id="emailAddress" required placeholder="Enter Your Email" />
                {simpleValidator.current.message('email', signupForm.email, 'required|email', { className: 'text-danger' })}
              </div>
              <div class="form-group">
                <label for="emailAddress">Phone Number</label>
                <input type="number" onChange={handleFormChange} name="phone" class="form-control" required placeholder="Enter Your Phone Number" />
                {simpleValidator.current.message('phone', signupForm.phone, 'required|phone|max:11', { className: 'text-danger' })}
              </div>
              <div class="form-group">
                <label for="loginPassword">Password</label>
                <input type="password" onChange={handleFormChange} name="password" class="form-control" required placeholder="Enter Password" />
                {simpleValidator.current.message('password', signupForm.password, 'required|max:20', { className: 'text-danger' })}
              </div>
              <div class="form-group">
                <label for="loginPassword">Confirm Password</label>
                <input type="password" onChange={handleFormChange} class="form-control" name="confirmPassword" required placeholder="Confirm Password" />
                {simpleValidator.current.message('confirmPassword', signupForm.confirmPassword, 'required|max:20', { className: 'text-danger' })}
                {signupForm.passwordValidity ? null : <p className="text-danger">Both Passwords do not match</p>}
              </div>
              <button class="btn btn-primary btn-block my-4" type="button" onClick={handleFormSubmit}>Sign Up</button>
            </form>
            <p class="text-3 text-muted text-center mb-0">Already have an account? <Link class="btn-link" to="/login">Log In</Link></p>
            <p class="text-3 text-muted text-center mb-0">Want to sign up as an organization? <Link class="btn-link" to="/signuporg">Sign Up</Link></p>
          </div>
        </div>}
      {hasError &&
        <h1 style={{textAlign:"center"}}>Bad Request</h1>
      }
    </>
  )
}
