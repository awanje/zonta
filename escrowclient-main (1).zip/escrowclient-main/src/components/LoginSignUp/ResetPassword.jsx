import React , {useEffect , useState} from 'react'
import PreLoader from '../mini_features/PreLoader.jsx'
import ResetPasswordWrapper from './ResetPasswordWrapper'
import NavBar from '../menu/NavBarWhite.jsx'
import ResetPasswordSuccess from './ResetPasswordSuccess'
import Footer from '../common/Footer'
import $ from 'jquery'

const ResetPassword=()=> {
    const [resetPasswordSuccess, setResetPasswordSuccess ] = useState(false);
    const [OrgPath, setOrgPath ] = useState("");
    useEffect(() => {
        $('[data-loader="circle-side"]').fadeOut() 
              $('#preloader').delay(333).fadeOut('slow')
              $('body').delay(333) 
      })
    return (
        <>
            <PreLoader />
            <NavBar />
            {resetPasswordSuccess ? <ResetPasswordSuccess path = {OrgPath}/> : <ResetPasswordWrapper
            resetPasswordSetter = {setResetPasswordSuccess}
            pathSetter = {setOrgPath} />  }
             
            <Footer />
        </>
    )
}
export default ResetPassword;