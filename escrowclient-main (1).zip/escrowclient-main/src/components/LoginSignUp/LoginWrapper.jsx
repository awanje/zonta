import React, { useState, useEffect } from 'react'
import { Link, useHistory, Redirect } from "react-router-dom"
import { login } from '../../store/actions/auth.actions'
import { loginOrg } from '../../store/actions/org.actions'
//import history from '../../utils/history'
export default function LoginWrapper(props) {
  const history = useHistory();
  const [loginForm, setLoginForm] = useState({
    email: "",
    password: ""
  })
  const [redirect, setRedirect] = useState({
    allow: false,
    path: ""
  })
  const { innerWidth: width, innerHeight: height } = window;

  function onChangeHandler(event) {
    const { name, value } = event.target;
    setLoginForm(prevValue => {
      return {
        ...prevValue,
        [name]: value,
      }
    })
  }

  function redirectToProfile() {
    setRedirect({
      allow: true,
      path: '/profile'
    })
  }

  const asyncLocalStorage = {
    setItem: function (key, value) {
        return Promise.resolve().then(function () {
            localStorage.setItem(key, value);
        });
    },
    getItem: function (key) {
        return Promise.resolve().then(function () {
            return localStorage.getItem(key);
        });
    }
};



  async function onFormSubmit() {
    console.log(props.type);

    console.log(loginForm);
    let loginResponse = "";
    if (props.type === "org") {
      loginResponse = await loginOrg({ ...loginForm, type: "org" });
    } else {
      loginResponse = await login({ ...loginForm, type: "user" });
    }
    console.log(loginResponse.status);
    if (loginResponse.status === 200) {
      console.log("found okay");
      // redirectToProfile()
      asyncLocalStorage.setItem('user', JSON.stringify({
        token: loginResponse.data.token,
        ...loginResponse.data.user
      })).then(function () {
        return history.push({ pathname: '/profile' });
      })
      

    }
    //console.log("height: " + height);
  }
  return (
    <>
      {/* {redirect.allow && <Redirect to={{pathname: `${redirect.path}`}} />} */}
      <div id="main-wrapper" style={{ height: `${height}px` }}>
        <div className="container-fluid px-0 " style={{ height: "100%" }}>
          <div className="row no-gutters " style={{ height: "100%" }}>
            {/* <!-- Welcome Text
      ============================================= --> */}
            <div className="col-md-6" style={{ height: "100%" }}>
              <div className="hero-wrap d-flex align-items-center" style={{ height: "100%" }} >
                <div className="hero-mask opacity-8 bg-primary"></div>
                <div className="hero-bg hero-bg-scroll" style={{ backgroundImage: "url('./images/bg/image-3.jpg')" }}></div>
                <div className="hero-content  w-100  d-flex flex-column" >
                  <div className="row no-gutters">
                    <div className="col-10 col-lg-9 mx-auto">
                      <div className="logo mt-5 mb-5 mb-md-0"> <Link className="d-flex" to="/" title="Payyed - HTML Template"><img src="images/logo-light.png" alt="Payyed" /></Link> </div>
                    </div>
                  </div>
                  <div className="row no-gutters my-auto">
                    <div className="col-10 col-lg-9 mx-auto">
                      <h1 className="text-11 text-white mb-4">{props.type === "org" ? "Welcome to DealWow!" : "Welcome back!"}</h1>
                      <p className="text-4 text-white line-height-4 mb-5">{props.type === "org" ? "A platform made for massive organizational payments." : "We are glad to see you again! Instant deposits, withdrawals & payouts trusted by millions worldwide."}</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            {/* <!-- Welcome Text End --> */}

            {/* <!-- Login Form
      ============================================= --> */}
            <div className="col-md-6 d-flex align-items-center">
              <div className="container my-4">
                <div className="row">
                  <div className="col-11 col-lg-9 col-xl-8 mx-auto">
                    <h3 className="font-weight-400 mb-4">Log In</h3>
                    <form id="loginForm" >
                      <div className="form-group">
                        <label for="emailAddress">Email Address</label>
                        <input type="email" name="email" className="form-control" value={loginForm.email} onChange={onChangeHandler} id="emailAddress" required placeholder="Enter Your Email" />
                      </div>
                      <div className="form-group">
                        <label for="loginPassword">Password</label>
                        <input type="password" className="form-control" name="password" value={loginForm.password} onChange={onChangeHandler} id="loginPassword" required placeholder="Enter Password" />
                      </div>
                      <div className="row">
                        {/* <div className="col-sm">
                    <div className="form-check custom-control custom-checkbox">
                      <input id="remember-me" name="remember" className="custom-control-input" type="checkbox" />
                      <label className="custom-control-label" for="remember-me">Remember Me</label>
                    </div>
                  </div> */}
                        <div className="col-sm text-right"><Link className="btn-link" to="/forgot">Forgot Password ?</Link></div>
                      </div>
                      <button className="btn btn-primary btn-block my-4" onClick={onFormSubmit} type="button">Login</button>
                    </form>
                    <p className="text-3 text-center text-muted">Don't have an account? <Link className="btn-link" to="/signup">Sign Up</Link></p>
                  </div>
                </div>
              </div>
            </div>
            {/* <!-- Login Form End --> */}
          </div>
        </div>
      </div>
    </>
  )
}
