import React , {useEffect , useState} from 'react'
import PreLoader from '../mini_features/PreLoader.jsx'
import ForgotPasswordWrapper from './forgotPasswordWrapper'
import NavBar from '../menu/NavBarWhite.jsx'
import ForgotPasswordSuccess from './forgotPasswordSuccess'
import Footer from '../common/Footer'
import $ from 'jquery'

const ForgotPassword=()=> {
    const [forgotPasswordSuccess, setForgotPasswordSuccess ] = useState(false);
    useEffect(() => {
        $('[data-loader="circle-side"]').fadeOut() 
              $('#preloader').delay(333).fadeOut('slow')
              $('body').delay(333) 
      })
    return (
        <>
            <PreLoader />
            <NavBar />
            {forgotPasswordSuccess ? <ForgotPasswordSuccess /> : <ForgotPasswordWrapper
            forgotPasswordSetter = {setForgotPasswordSuccess} />  }
            
            <Footer />
        </>
    )
}
export default ForgotPassword;