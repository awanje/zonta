import React, { useState, useRef, useEffect } from 'react'
import SimpleReactValidator from 'simple-react-validator';
import { Link } from "react-router-dom"
import { signUpOrganization } from '../../store/actions/org.actions';

export default function SignUpWrapper(props) {
  const simpleValidator = useRef(new SimpleReactValidator());
  const [hasError, setHasError] = useState(false);
  const [signupForm, setSignupForm] = useState({
    org_name: "",
    org_email: "",
    person_phone: "",
    org_phone: "",
    no_of_employees: "",
    avg_salaries: "",
    person_name: "",
    person_role: "",
    org_address: "",

  });

  function handleFormChange(event) {
    const { name, value } = event.target;
    simpleValidator.current.showMessageFor(name)
    setSignupForm(prevValue => {
      return {
        ...prevValue,
        [name]: value
      }
    })
  }

  async function handleFormSubmit() {
    if (simpleValidator.current.allValid()) {
      // alert("Yuhoo....You've Signed up for our platform");
      // props.signupSetter(true);
      let reqObj = signupForm;
      delete reqObj.render;
      reqObj.avg_salaries = Number(reqObj.avg_salaries);
      reqObj.no_of_employees = Number(reqObj.no_of_employees);
      let response = await signUpOrganization(reqObj);
        let status = response.status;
        console.log(response);
        if (status) {
          props.signupSetter(true);
        } else {
          alert("Something bad happened.");
        }
    } else {
      simpleValidator.current.showMessages();
      setSignupForm(prevValue => {
        return {
          ...prevValue,
          render: true
        }
      })
    }
  }

  useEffect(() => {
 
  }, [signupForm.render])
  return (
    <div class="container mx-auto my-5 col-lg-12">
      <h3 class="font-weight-400 text-center">Sign Up As an Organization</h3>
      <p class="lead text-center">Your Sign Up information is safe with us.</p>
      <div class="bg-light shadow-md rounded p-4 mx-2 col-lg-12">
      <div class="row">
        <form id="signupForm" class="col-lg-12" method="post">

        <div class="form-row">
          <div class="form-group col-lg-6">
            <label for="fullName">Full Name</label>
            <input type="text" onChange={handleFormChange} class="form-control" name="org_name" required placeholder="Enter Organization Name" />
            {simpleValidator.current.message('org_name', signupForm.org_name, 'required|max:24', { className: 'text-danger' })}
          </div>
          <div class="form-group col-lg-6">
            <label for="emailAddress">Email Address</label>
            <input type="email" onChange={handleFormChange} name="org_email" class="form-control" id="emailAddress" required placeholder="Enter Organization Email" />
            {simpleValidator.current.message('org_email', signupForm.org_email, 'required|email', { className: 'text-danger' })}
          </div>
        </div>

          <div class="form-row">
          <div class="form-group col-lg-6">
            <label for="personPhone">Person Number</label>
            <input type="number" onChange={handleFormChange} name="person_phone" class="form-control" required placeholder="Enter Your Phone Number" />
            {simpleValidator.current.message('person_phone', signupForm.person_phone, 'required|phone|max:11', { className: 'text-danger' })}
          </div>
          <div class="form-group col-lg-6">
            <label for="orgPhone">Organization Phone Number</label>
            <input type="number" onChange={handleFormChange} name="org_phone" class="form-control" required placeholder="Enter Organization Phone Number" />
            {simpleValidator.current.message('org_phone', signupForm.org_phone, 'required|phone|max:11', { className: 'text-danger' })}
          </div>
          </div>

          <div class="form-row">
            <div class="form-group col-lg-6">
              <label for="noOfEmployees">No of Employees</label>
              <input type="number" onChange={handleFormChange} name="no_of_employees" class="form-control" required placeholder="No. of Employees" />
              {simpleValidator.current.message('no_of_employees', signupForm.no_of_employees, 'required|max:20', { className: 'text-danger' })}
            </div>
            <div class="form-group col-lg-6">
              <label for="avgSalaries">Avg. Salaries</label>
              <input type="number" onChange={handleFormChange} name="avg_salaries" class="form-control" required placeholder="Average Salaries" />
              {simpleValidator.current.message('avg_salaries', signupForm.avg_salaries, 'required|max:20', { className: 'text-danger' })}
            </div>
          </div>

          <div class="form-row">
            <div class="form-group col-lg-6">
              <label for="personName">Person Name</label>
              <input type="text" onChange={handleFormChange} name="person_name" class="form-control" required placeholder="Your Name" />
              {simpleValidator.current.message('person_name', signupForm.person_name, 'required|max:20', { className: 'text-danger' })}
            </div>
            <div class="form-group col-lg-6">
              <label for="loginPassword">Person Role</label>
              <input type="text" onChange={handleFormChange} name="person_role" class="form-control" required placeholder="Your Role in Org." />
              {simpleValidator.current.message('person_role', signupForm.person_role, 'required|max:20', { className: 'text-danger' })}
            </div>
          </div>

          <div class="form-row">
            <div class="form-group col-lg-12">
              <label for="loginPassword">Org Address</label>
              <input type="text" onChange={handleFormChange} name="org_address" class="form-control" required placeholder="Organization Address" />
              {simpleValidator.current.message('org_address', signupForm.org_address, 'required|max:20', { className: 'text-danger' })}
            </div>
          </div>
          
          <div class="row">
          <div class="col-lg-4"></div>
          <button class="btn btn-primary btn-block my-4 col-lg-4" type="button" onClick={handleFormSubmit}>Sign Up</button>
          <div class="col-lg-4"></div>
          </div>
        </form>
        </div>
        <p class="text-3 text-muted text-center mb-0">Already have an account? <Link class="btn-link" to="/login">Log In</Link></p>
      </div>
    </div>
  )
}
