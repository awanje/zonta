import React , {useEffect , useState} from 'react'
import PreLoader from '../mini_features/PreLoader.jsx'
import SignUpOrgWrapper from './SignUpOrgWrapper'
import NavBar from '../menu/NavBarWhite.jsx'
import SignUpOrgSuccess from './SignUpOrgSuccess'
import Footer from '../common/Footer'
import $ from 'jquery'

export default function SignUp() {
    const [signupSuccess, setSignupSuccess ] = useState(false);
    useEffect(() => {
        $('[data-loader="circle-side"]').fadeOut() 
              $('#preloader').delay(333).fadeOut('slow')
              $('body').delay(333) 
      })
    return (
        <>
            <PreLoader />
            <NavBar />
            {signupSuccess ? <SignUpOrgSuccess /> : <SignUpOrgWrapper
            signupSetter = {setSignupSuccess} />  }
            
            <Footer />
        </>
    )
}