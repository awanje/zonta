import React from 'react'
import {Link} from 'react-router-dom'
export default function forgotPasswordSuccess() {
    return (
        <div class="login-signup-page mx-auto my-5">
            <h3 class="font-weight-400 text-center">Forgot Password</h3>
            <p class="lead text-center">Your information is safe with us.</p>
            <div class="bg-light shadow-md rounded p-4 mx-2">
                <div className="text-center my-5">
                    <p className="text-center text-success text-20 line-height-07"><i className="fas fa-check-circle"></i></p>
                    <p className="text-center text-success text-8 line-height-07">Success!</p>
                    <p className="text-center text-4">Check the email for reset link</p>
                    <p className="text-center text-4"><Link to="/login">Login</Link> to continue</p>

                </div>

            </div>
        </div>
    )
}
