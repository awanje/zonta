import React from 'react'

export default function SecondaryMenu() {
    return (
        <div class="bg-primary">
            <div class="container d-flex justify-content-center">
                <ul class="nav secondary-nav">
                    <li class="nav-item"> <a class="nav-link active" href="/profile">Account</a></li>
                    <li class="nav-item"> <a class="nav-link" href="/bankCards">Cards & Bank Accounts</a></li>
                    <li class="nav-item"> <a class="nav-link" href="/notifications">Notifications</a></li>
                </ul>
            </div>
        </div>
    )
}
