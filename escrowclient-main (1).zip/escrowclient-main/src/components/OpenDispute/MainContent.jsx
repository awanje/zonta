import React from 'react'
import { useLocation, useHistory, Redirect } from 'react-router-dom'
export default function MainContent() {
    const locationData = useLocation().data;
    const history = useHistory();
    let locNotSet = false;
    // if (typeof locationData !== 'undefined') {
    //     console.log(locationData);
    //     locNotSet = false;
    // }
    
    if (locNotSet) {
        return (
            <Redirect to="/requestmoney" />
        )
    } else {
        return (
            <div id="content" className="py-4">
                <div className="container">
                    <h2 className="font-weight-400 text-center mt-3">Open Dispute</h2>
                    <p className="text-4 text-center mb-4">You are about to open dispute for the deal  <span className="font-weight-500">#ZXP159</span></p>
                    <div className="row">
                        <div className="col-md-8 col-lg-12 col-xl-5 mx-auto">
                            <div className="bg-light shadow-sm rounded p-3 p-sm-4 mb-4">

                                {/* Send Money Confirm
                ============================================= */ }
                                <div className="form-group">
                                    <label for="description">Term Agreement</label>
                                    <pre style={{ height: "120px", border: "1px solid #CBCBCB", padding: "5px", borderRadius: "5px" }} className="text-4">Hey I'm just signing that</pre>
                                </div>
                                <form id="form-send-money" >

                                    <h3 className="text-5 font-weight-400 mb-3">Enter Details</h3>
                                    <div className="form-group">
                                        <label for="description">Select Reason</label>
                                        <select className="form-control select-2">
                                            <option>Fraud</option>
                                            <option>Ambiguity</option>
                                            <option>Late Delivery</option>
                                            <option>Non Satisfaction</option>
                                            <option>Other</option>
                                        </select>
                                    </div>
                                    <div className="form-group">
                                        <label for="description">Enter Details</label>
                                        <textarea rows="2" className="form-control" required placeholder="Enter Some Details"></textarea>
                                    </div>
                                    <div className="form-group">
                                        <label for="description">Attach Files</label>
                                        <input type="file" className="form-control" required placeholder="Enter Some Details" />
                                    </div>
                                    <div className="form-group">
                                        <label for="description">Enter Your Proposed Refund</label>
                                        <input type="number" className="form-control" required placeholder="Refund in PKR" />
                                    </div>
                                    
                                    <button  type="button" className="btn btn-primary btn-block">File Dispute</button>
                                </form>
                                {/* Send Money Confirm end */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

}
