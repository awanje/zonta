/* eslint-disable */
import React, { useState, useRef, useEffect } from 'react'
import { useLocation, useHistory } from 'react-router-dom'
import { GoMail } from 'react-icons/go'
import { BiPhone } from 'react-icons/bi'
import { Si1Password } from 'react-icons/si'
import { MdToday } from 'react-icons/md'
import { AiOutlineBank } from 'react-icons/ai'
var valid = require("card-validator");
import SimpleReactValidator from 'simple-react-validator';
import Tooltip from '@material-ui/core/Tooltip';
import Icon from '@material-ui/core/Icon';
import { sendOtp } from "../../../store/actions/utils.actions"
import Countdown from "react-countdown";
import {isAuthenticUser} from '../../../utils/validateUser';
export default function MainContent() {
  const [otp, setOtp] = useState(null);
  const timerRef = useRef();
  const otpTime= 15;
  

// Renderer callback with condition
const renderer = ({ hours, minutes, seconds, completed }) => {
  
    if(completed){
      setOtp(null)
      return <span>OTP Expired!</span>;
    }
  
    if(seconds > 0){
      if(otpTime != seconds){
        return (
          <span className="text-danger">
            Expires in : 
            {seconds}
          </span>
        )
      }else{
        return ( <span></span> )
      }
      
    }
     
  
};

  




  const commissionPerc = 1;
  const simpleValidator = useRef(new SimpleReactValidator());
  const locationData = useLocation().state;
  const history = useHistory();
  const [error, setError] = useState({
    seller: false,
    buyer: false
  })
  const [paymentMethodBuyer, setPaymentMethodBuyer] = useState({
    jazzCash: "none",
    easyPaisa: "none",
    card: "none",

  })
  const [paymentMethodSeller, setPaymentMethodSeller] = useState({
    jazzCash: "none",
    easyPaisa: "none",
    bank: "none"
  })


  //Basic Checks
  let stateExists = false;
  if (typeof locationData !== 'undefined') {
    stateExists = true
  }

  //console.log(locationData);

  let initialObject = {
    sellerMail: stateExists ? locationData.sellerMail : "",
    buyerMail: stateExists ? locationData.buyerMail : "",
    sendingAmount: stateExists ? locationData.sendingAmount : "",
    recievingAmount: stateExists ? locationData.recievingAmount : "",
    cardType: "",
    cardNumber: "",
    cardExpiryMonth: "",
    cardExpiryYear: "",
    cardCvc: "",
    cardHolderName: "",
    userPhone: "",
    userOTP: "",
    cardValidity: "",
    commission: "",
    OTPvalidity: false,
    submitButton: false,
    render: false,
    holdingDays: "",
    termAgreement: "",
    recIBAN: "",
    accTitle: "",
    jazzNumberSeller: "",
    easyNumberSeller: "",
    jazzNumber: "",
    easyNumber: "",
    paymentMethodBuyer: "",
    paymentMethodSeller: "",
    authenticUser:false,

  }

  const [sendForm, setSendForm] = useState(initialObject);

  //function for getting logged in user details
  useEffect(() => {
    if(isAuthenticUser()){
      let loggedInUser = JSON.parse(localStorage.getItem('user'));
      setSendForm(prevValue => {
        return {
          ...prevValue,
          authenticUser:true,
          buyerMail:loggedInUser.email,
          userPhone:loggedInUser.phone,
          buyer_id:loggedInUser.user_id
        }
      })
    }
  },[])







  function changePaymentMethodBuyer(event) {
    const value = event.target.value;
    let basic = {
      jazzCash: "none",
      easyPaisa: "none",
      card: "none",
    }
    simpleValidator.current.purgeFields()
    if (value !== "") {
      setPaymentMethodBuyer({
        ...basic,
        [value]: "block"
      })
      setSendForm(prevValue => {
        return {
          ...prevValue,
          paymentMethodBuyer: value
        }
      })
    } else {
      setPaymentMethodBuyer(basic)
    }

  }


  function changePaymentMethodSeller(event) {
    const value = event.target.value;
    let basic = {
      jazzCash: "none",
      easyPaisa: "none",
      bank: "none"
    }
    simpleValidator.current.purgeFields()
    if (value !== "") {
      setPaymentMethodSeller({
        ...basic,
        [value]: "block"
      })
      setSendForm(prevValue => {
        return {
          ...prevValue,
          paymentMethodSeller: value
        }
      })
    } else {
      setPaymentMethodSeller(basic)
    }

  }

  //Hook made to check if payment Method Objects cause erros
  // useEffect(() => {
  //   console.log(paymentMethod)
  // }, [paymentMethod])

  //Change Handler Function
  function handleFormChange(event) {

    const { name, value } = event.target;
    simpleValidator.current.showMessageFor(name)
    setSendForm(prevValue => {
      if (name === "sendingAmount") {

        let commissionValue = Math.ceil(Number((value / 100) * commissionPerc));
        let recieveMoney = Number(value) - commissionValue;

        return {

          ...prevValue,
          [name]: value,
          recievingAmount: recieveMoney,
          commission: commissionValue

        }

      } else if (name === "cardNumber") {

        var numberValidation = valid.number(value);
        let isValid = true;

        if (!numberValidation.isPotentiallyValid) {
          isValid = false;
        }

        if (value == "") {
          isValid = false;
        }

        let ctype = "";

        if (numberValidation.card) {
          ctype = numberValidation.card.type; // 'visa'
        }

        return {
          ...prevValue,
          [name]: value,
          cardType: ctype,
          cardValidity: isValid
        }

      } else {

        return {
          ...prevValue,
          [name]: value
        }

      }

    })

  }

  //OTP Sending Function
  const sendOTP = async () => {
    let response = await sendOtp({ email: sendForm.buyerMail })
    if (response.status) {
      setOtp(response.otp);
      timerRef.current.start();
      console.log('otp is, ', response.otp)
    }
    console.log(response);
  }

  //OTP Validation Function
  function validateOTP() {
    //console.log(otp + '  ' + sendForm.userOTP);
    if (otp == sendForm.userOTP) {

      setSendForm(prevValue => {
        return {
          ...prevValue,
          OTPvalidity: true,
        }
      })
      setOtp(null);
      timerRef.current.pause();
    }else{
      setSendForm(prevValue => {
        return {
          ...prevValue,
          OTPvalidity: false,
        }
      })
    }
  }

  //Function to handle Form Submit
  function submitForm() {

    //Custom Validation Expression for email or phone
    var mailFormat = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})|([0-9]{10})+$/;
    if (!mailFormat.test(sendForm.buyerMail)) {
      setError(prevValue => {
        return {
          ...prevValue,
          buyer: true
        }

      })
    }
    if (!mailFormat.test(sendForm.sellerMail)) {
      setError(prevValue => {
        return {
          ...prevValue,
          seller: true
        }

      })
    }
    //Custom Validation Check Ends for Email or Phone

    //console.log("submitted");

    //Checking Card Number Validation if Buyer Payment Method is a card
    let selfChecks = true;
    if (sendForm.paymentMethodBuyer == "card") {
      var numberValidation = valid.number(sendForm.cardNumber);
      if (!(sendForm.OTPvalidity && numberValidation.isPotentiallyValid)) {
        selfChecks = false
      }
    }

    //console.log(simpleValidator.current.allValid())


    if (simpleValidator.current.allValid() && selfChecks && mailFormat.test(sendForm.buyerMail) && mailFormat.test(sendForm.sellerMail)) {
      // alert('You submitted the form and stuff!');

      // Checking Buyer Payment Account By Payment Method
      let accNumberBuyer = "";
      if (sendForm.paymentMethodBuyer === "jazzCash") { accNumberBuyer = sendForm.jazzNumber }
      if (sendForm.paymentMethodBuyer === "easyPaisa") { accNumberBuyer = sendForm.easyNumber }
      if (sendForm.paymentMethodBuyer === "card") { accNumberBuyer = sendForm.cardNumber }

      //Checking Seller Payment account By Payment Method
      let accNumberSeller = "";
      if (sendForm.paymentMethodSeller === "jazzCash") { accNumberSeller = sendForm.jazzNumberSeller }
      if (sendForm.paymentMethodSeller === "easyPaisa") { accNumberSeller = sendForm.easyNumberSeller }
      if (sendForm.paymentMethodSeller === "bank") { accNumberSeller = sendForm.recIBAN }
      let methodArray = ["" , "easyPaisa" , "jazzCash" , "bank" , "card"];
      //Redirecting to Confirmation Page using History API and state object
      history.push({
        pathname: "/sendmoneyconfirm",
        data: {
          accountNumberSeller: accNumberSeller,
          accountNumberBuyer: accNumberBuyer,
          buyerMail: sendForm.buyerMail,
          sellerMail: sendForm.sellerMail,
          sendingAmount: sendForm.sendingAmount,
          commission: sendForm.commission,
          termAgreement: sendForm.termAgreement,
          recievingAmount: sendForm.recievingAmount,
          sellerMail: sendForm.sellerMail,
          buyerPhone:sendForm.userPhone,
          paymentMethodBuyer: methodArray.indexOf(sendForm.paymentMethodBuyer),
          paymentMethodSeller: methodArray.indexOf(sendForm.paymentMethodSeller),
          holdingDays:sendForm.holdingDays,
          initiator:"buyer",
          buyer_id:sendForm.buyer_id,
        }
      })
      //Redirect End

    } else {
      //Else Part if any of form validation fails

      //console.log("showing msgs");
      simpleValidator.current.showMessages();

      //console.log(simpleValidator.current.getErrorMessages())  //This Statement returns a object with all validation errors

      //changing sendForm state.render to trigger error display by UseEffect Hook
      setSendForm(prevValue => {
        return {
          ...prevValue,
          render: true
        }
      })

    }
  }

  //Re Rendering to display errors using effect Hook
  useEffect(() => {

  }, [sendForm.render])



  return (
    <div id="content" class="py-4">
      <div class="container">
        <h2 class="font-weight-400 text-center mt-3">Initiate Deal<span className="text-muted text-4">(Buyer)</span></h2>
        <p class="text-4 text-center mb-4">Deal with anyone, on anytime, anywhere in  Pakistan.</p>
        <div class="row">
          <div class="col-md-10 col-lg-10 col-xl-10 mx-auto">
            <div class="bg-light shadow-sm rounded p-3 p-sm-4 mb-4">
              <h3 class="text-5 font-weight-400 mb-3">Deal Details</h3>
              {/* Send Money Form
            ============================================= */}
              <form id="form-send-money" >
                <div className="form-row">
                  <div className="col-lg-6">
                    <div class="form-group">
                      <label for="emailID">Seller Email or Phone</label>
                      <div className="input-group">
                        <div className="input-group-prepend"> <span className="input-group-text"><GoMail /></span> </div>
                        <input value={sendForm.sellerMail} onChange={handleFormChange} type="text" className="form-control" placeholder="Reciepient Email Address" name="sellerMail" />

                      </div>
                      {error.seller ? <p className="text-danger">Invalid email or phone</p> : null}
                    </div>
                  </div>
                  <div className="col-lg-6">
                    <div className="form-group">
                      <label htmlFor="youSend">Buyer Email or Phone</label>
                      <div className="input-group">
                        <div className="input-group-prepend"> <span className="input-group-text"><BiPhone /></span> </div>
                        <input disabled={sendForm.authenticUser} value={sendForm.buyerMail} onChange={handleFormChange} type="text" className="form-control" placeholder="Recipient Phone Number" name="buyerMail" />
                      </div>
                      {error.buyer ? <p className="text-danger">Invalid email or phone</p> : null}
                    </div>
                  </div>
                </div>
                {/* Payment Method for seller */}
                <div className="form-row">
                  <div class="col-lg-6">
                    <div class="form-group">
                      <label for="cardHolderName">Select Seller<span className="text-muted">(Reciever)</span> Payment Method</label>
                      <select className="form-control" onChange={changePaymentMethodSeller}>
                        <option value="">Please Select Payment Method</option>
                        <option value="jazzCash">JazzCash</option>
                        <option value="easyPaisa">EasyPaisa</option>
                        <option value="bank">Bank</option>
                      </select>
                      {simpleValidator.current.message('paymentMethodSeller', sendForm.paymentMethodSeller, 'required')}
                    </div>
                  </div>
                  {/* JazzCAsh Div */}
                  {paymentMethodSeller.jazzCash === "block" && <div class="col-lg-6" >
                    <div class="form-group">
                      <label for="cvvNumber">Mobile Number </label>
                      <input value={sendForm.jazzNumberSeller} onChange={handleFormChange} name="jazzNumberSeller" type="text" class="form-control" required placeholder="JazzCash Account Number" />
                      {simpleValidator.current.message('jazzNumberSeller', sendForm.jazzNumberSeller, 'required|phone|min:11|max:11', { className: 'text-danger' })}
                      {/* { simpleValidator.current.message('jazzNumberSeller', sendForm.jazzNumberSeller, 'required|phone|min:11|max:11', { className: 'text-danger' } ) } */}
                    </div>
                  </div>}
                  {/* Jazzcash div end */}
                  {/* EasyPaisa Div */}
                  {paymentMethodSeller.easyPaisa === "block" && <div class="col-lg-6">
                    <div class="form-group">
                      <label for="cvvNumber">Mobile Number </label>
                      <input value={sendForm.easyNumberSeller} onChange={handleFormChange} name="easyNumberSeller" type="number" class="form-control" required placeholder="EasyPaisa Account Number" />
                      {simpleValidator.current.message('easyNumberSeller', sendForm.easyNumberSeller, 'required|phone|min:11|max:11', { className: 'text-danger' })}
                    </div>
                  </div>}
                  {/* Easy Paisa div end */}
                </div>

                {paymentMethodSeller.bank === "block" && <div id="bank-method-div" className="form-row">
                  <div className="col-lg-4">
                    <div class="form-group">
                      <label for="emailID">Recipient Account Title</label>
                      <div className="input-group">
                        <div className="input-group-prepend"> <span className="input-group-text">Title</span> </div>
                        <input value={sendForm.accTitle} onChange={handleFormChange} type="text" className="form-control" placeholder="Reciepient Account Title" name="accTitle" />

                      </div>
                      {simpleValidator.current.message('accTitle', sendForm.accTitle, 'required|max:24', { className: 'text-danger' })}
                    </div>
                  </div>
                  <div className="col-lg-8">
                    <div className="form-group">
                      <label htmlFor="youSend">Recipient IBAN</label>
                      <div className="input-group">
                        <div className="input-group-prepend"> <span className="input-group-text"><AiOutlineBank /></span> </div>
                        <input value={sendForm.recIBAN} onChange={handleFormChange} type="text" className="form-control" placeholder="Recipient Bank IBAN Number" name="recIBAN" />
                      </div>
                      {simpleValidator.current.message('recIBAN', sendForm.recIBAN, 'required|min:20|max:24', { className: 'text-danger' })}
                    </div>
                  </div>
                </div>}
                {/* Payment Method for seller Ends */}

                <div className="form-row">

                  <div className="col-lg-6">
                    <div class="form-group">
                      <label for="youSend">You Send</label>
                      <div class="input-group">
                        <div class="input-group-prepend"> <span class="input-group-text">PKR</span> </div>
                        <input name="sendingAmount" type="number" value={sendForm.sendingAmount} onChange={handleFormChange} class="form-control" placeholder="" />
                      </div>
                      {simpleValidator.current.message('sendingAmount', sendForm.sendingAmount, 'required|currency|min:4|min:1000,num', { className: 'text-danger' })}
                    </div>
                  </div>

                  <div className="col-lg-6">
                    <div class="form-group">
                      <label for="recipientGets">Recipient Gets</label>
                      <div class="input-group">
                        <div class="input-group-prepend"> <span class="input-group-text">PKR</span> </div>
                        <input type="number" value={sendForm.recievingAmount} onChange={handleFormChange} name="recievingAmount" readOnly class="form-control" />
                      </div>
                    </div>
                  </div>
                  <p class="text-muted text-center">Deal Vow Fees - <span class="font-weight-700">{sendForm.commission}</span> , it will be charged only <span class="font-weight-500">{commissionPerc}% </span>to keep your money safe.</p>
                </div>

                <div className="form-row">

                  <div className="col-lg-8">
                    <div class="form-group">
                      <label for="youSend">Term Agreement<span className="text-info ml-1 text-1"  ><Tooltip style={{ display: 'inline' }} title="The agreement to be agreed by both buyer and seller." arrow><Icon className="fa fa-question-circle text-3" color="info" /></Tooltip></span></label>

                      <textarea name="termAgreement" rows="1" value={sendForm.termAgreement} onChange={handleFormChange} class="form-control" placeholder="Your Agreement" ></textarea>

                      {simpleValidator.current.message('termAgreement', sendForm.termAgreement, 'min:20|max:200', { className: 'text-danger' })}
                    </div>
                  </div>

                  <div className="col-lg-4">
                    <div class="form-group">
                      <label for="recipientGets">Holding Days<span className="text-info ml-1 text-1"  ><Tooltip style={{ display: 'inline' }} title="The Number of days you want us to keep your payment before releasing to seller once deal is initiated." arrow><Icon className="fa fa-question-circle text-3" color="info" /></Tooltip></span></label>

                      <div class="input-group">
                        <div class="input-group-prepend"> <span class="input-group-text"><MdToday /></span> </div>
                        <input type="number" value={sendForm.holdingDays} onChange={handleFormChange} name="holdingDays" class="form-control" />

                      </div>
                      {simpleValidator.current.message('holdingDays', sendForm.holdingDays, 'required|numeric|min:1,num|max:15,num', { className: 'text-danger' })}
                    </div>
                  </div>
                </div>
                <div className="form-row" style={{ textAlign: 'center' }}>
                  <p style={{ fontWeight: "1200px", fontSize: "24px" }}>Your Details</p>
                  <hr />
                </div>
                {/* Here the multiple payment method section starts */}
                <div className="form-row">
                  <div class="col-lg-6">
                    <div class="form-group">
                      <label for="cardHolderName">Select <span className="text-muted">(Yours)</span> Payment Method<span className="text-info ml-1 text-1"  ><Tooltip style={{ display: 'inline' }} title="Your Payment Method Details will be used to withdraw payment from your account" arrow><Icon className="fa fa-question-circle text-3" color="info" /></Tooltip></span></label>
                      <select className="form-control" onChange={changePaymentMethodBuyer}>
                        <option value="">Please Select Payment Method</option>
                        <option value="jazzCash">JazzCash</option>
                        <option value="easyPaisa">EasyPaisa</option>
                        <option value="card">Card</option>
                      </select>
                      {simpleValidator.current.message('paymentMethodBuyer', sendForm.paymentMethodBuyer, 'required'  , { className: 'text-danger' })}
                    </div>
                  </div>
                  {/* JazzCAsh Div */}
                  {paymentMethodBuyer.jazzCash === "block" && <div class="col-lg-6" >
                    <div class="form-group">
                      <label for="cvvNumber">Mobile Number </label>
                      <input value={sendForm.jazzNumber} onChange={handleFormChange} name="jazzNumber" type="number" class="form-control" required placeholder="JazzCash Account Number" />
                      {simpleValidator.current.message('jazzNumber', sendForm.jazzNumber, 'required|phone|min:11|max:11', { className: 'text-danger' })}
                    </div>
                  </div>}
                  {/* Jazzcash div end */}
                  {/* EasyPaisa Div */}
                  {paymentMethodBuyer.easyPaisa === "block" && <div class="col-lg-6">
                    <div class="form-group">
                      <label for="cvvNumber">Mobile Number </label>
                      <input value={sendForm.easyNumber} onChange={handleFormChange} name="easyNumber" type="number" class="form-control" required placeholder="EasyPaisa Account Number" />
                      {simpleValidator.current.message('easyNumber', sendForm.easyNumber, 'required|phone|min:11|max:11', { className: 'text-danger' })}
                    </div>
                  </div>}
                  {/* Easy Paisa div end */}
                </div>

                {paymentMethodBuyer.card === "block" && <div id="cardMethod" >
                  <div className="form-row">
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="cardHolderName">Card Holder Name</label>
                        <input type="text" name="cardHolderName" value={sendForm.cardHolderName} onChange={handleFormChange} class="form-control" required placeholder="Card Holder Name" />
                        {paymentMethodBuyer.card === "block" ? simpleValidator.current.message('cardHolderName', sendForm.cardHolderName, 'required|alpha|min:3', { className: 'text-danger' }) : null}
                      </div>
                    </div>

                    <div className="col-lg-6">
                      <div class="form-group">
                        <label for="cardNumber">Card Number</label>
                        <div className="input-group">
                          <div className="input-group-prepend"> <span className="input-group-text">{sendForm.cardType}</span> </div>
                          <input type="text" name="cardNumber" value={sendForm.cardNumber} onChange={handleFormChange} class="form-control" required placeholder="Card Number" />
                        </div>
                        {sendForm.cardValidity ? <p className="text-success">Valid Card Number</p> : <p className="text-danger">Invalid Card Number</p>}

                      </div>
                    </div>
                  </div>
                  <div class="form-row">
                    <div class="col-lg-6">
                      <div class="form-row">
                        <div class="col-lg-6">
                          <div class="form-group">
                            <label for="expiryDate">Expiry Month</label>
                            <input type="number" name="cardExpiryMonth" value={sendForm.cardExpiryMonth} onChange={handleFormChange} class="form-control" placeholder="MM/YY" />
                          </div>
                        </div>
                        <div class="col-lg-6">
                          <div class="form-group">
                            <label for="expiryDate">Expiry Year</label>
                            <input type="number" name="cardExpiryYear" value={sendForm.cardExpiryYear} onChange={handleFormChange} class="form-control" placeholder="MM/YY" />
                          </div>
                        </div>
                        {simpleValidator.current.message('cardExpiryMonth', sendForm.cardExpiryMonth, 'required|numeric|min:1,num|max:12,num', { className: 'text-danger' })}
                        {simpleValidator.current.message('cardExpiryYear', sendForm.cardExpiryYear, 'required|numeric|min:21,num|max:25,num', { className: 'text-danger' })}
                      </div>

                    </div>
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label for="cvvNumber">CVV <span className="text-info ml-1 text-1"  ><Tooltip style={{ display: 'inline' }} title="CVV is the three digit number printed on the backside of the card on a white strip." arrow><Icon className="fa fa-question-circle text-3" color="info" /></Tooltip></span></label>
                        <input value={sendForm.cardCvc} onChange={handleFormChange} name="cardCvc" type="password" class="form-control" required placeholder="CVV (3 digits)" />
                        {simpleValidator.current.message('cardCvc', sendForm.cardCvc, 'required|numeric|min:3|max:3', { className: 'text-danger' })}
                      </div>
                    </div>


                  </div>
                </div>}




                {/* Multiple Payments End */}


                <div class="form-row">
                  <div class="col-lg-4">
                    <div className="form-group">
                      <label htmlFor="youSend">Your Phone</label>
                      <div className="input-group">
                        <div className="input-group-prepend"> <span className="input-group-text"><BiPhone /></span> </div>
                        <input disabled={sendForm.authenticUser} type="number" value={sendForm.userPhone} name="userPhone" onChange={handleFormChange} className="form-control" placeholder="Your Phone Number" />
                      </div>
                      {simpleValidator.current.message('userPhone', sendForm.userPhone, 'required|phone|max:11', { className: 'text-danger' })}
                    </div>
                  </div>
                  <div className="col-lg-2">
                    <div className="form-group">
                      <label htmlFor="youSend">Get Your OTP</label>
                      <div className="input-group">
                        <button type="button" disabled={otp || sendForm.OTPvalidity} onClick={sendOTP} className="btn btn-warning btn-md">Send OTP</button>
                        {/* {timer < 60 && <p>{timer}</p>} */}
                        <Countdown ref={timerRef} autoStart={false} date={Date.now() + 15000}  renderer={renderer} />
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-4">
                    <div className="form-group">
                      <label htmlFor="youSend">Enter OTP</label>
                      <div className="input-group">
                        <div className="input-group-prepend"> <span className="input-group-text"><Si1Password /></span> </div>
                        <input type="number" value={sendForm.userOTP} onChange={handleFormChange} className="form-control" placeholder="OTP" name="userOTP" />
                      </div>
                      {sendForm.OTPvalidity ? <p className="text-success">Valid OTP</p> : <p className="text-danger">OTP is wrong or missing</p>}
                    </div>
                  </div>
                  <div className="col-lg-2">
                    <div className="form-group">
                      <label htmlFor="youSend">Validate OTP</label>
                      <div className="input-group">
                        <button type="button" disabled={sendForm.OTPvalidity || !otp} onClick={validateOTP} className="btn btn-success btn-md">Validate</button>
                      </div>
                    </div>
                  </div>
                </div>



                <p class="text-muted text-center">If the recipient does not accept deal <span class="font-weight-700">within 4 working days</span> , it will be transferred back to <span class="font-weight-500">your account</span></p>
                <hr />
                <p class="mb-1">Recieving Amount <span class="text-3 float-right">PKR - {sendForm.recievingAmount}</span></p>
                <hr />
                <p class="mb-1">Total fees<span className="text-info ml-1 text-1"  ><Tooltip style={{ display: 'inline' }} title="Deal Vow charges a small amount of processing fee to process your deals." arrow><Icon className="fa fa-question-circle text-3" color="info" /></Tooltip></span> <span class="text-3 float-right">PKR - {sendForm.commission}</span></p>
                <hr />
                <p class="font-weight-500">Total To Pay <span class="text-3 float-right">PKR - {sendForm.sendingAmount}</span></p>
                <button disabled={!sendForm.OTPvalidity} onClick={submitForm} type="button" class="btn btn-primary btn-block">Continue</button>
              </form>
              {/* Send Money Form end */}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}


// function CardPayment() {
//   return (
//    )
// }