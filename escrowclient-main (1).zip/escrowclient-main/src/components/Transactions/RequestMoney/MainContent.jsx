/* eslint-disable */
import React, { useState, useRef, useEffect } from 'react'
import { useLocation , useHistory } from 'react-router-dom'
import { GoMail } from 'react-icons/go'
import { BiPhone } from 'react-icons/bi'
import { Si1Password } from 'react-icons/si'
import  { MdToday } from 'react-icons/md' 
import { AiOutlineBank } from 'react-icons/ai'
import { BsCalendarFill } from 'react-icons/bs'
import SimpleReactValidator from 'simple-react-validator';
import Tooltip from '@material-ui/core/Tooltip';
import Icon from '@material-ui/core/Icon';
import {isAuthenticUser} from '../../../utils/validateUser';
import { sendOtp } from "../../../store/actions/utils.actions"
import Countdown from "react-countdown";

export default function MainContent() {

  const [otp, setOtp] = useState(null);
  const timerRef = useRef();
  const otpTime= 15;
  

// Renderer callback with condition
const renderer = ({ hours, minutes, seconds, completed }) => {
  
    if(completed){
      setOtp(null)
      return <span>OTP Expired!</span>;
    }
  
    if(seconds > 0){
      if(otpTime != seconds){
        return (
          <span className="text-danger">
            Expires in : 
            {seconds}
          </span>
        )
      }else{
        return ( <span></span> )
      }
      
    }
     
  
};


  const commissionPerc = 1;
  const simpleValidator = useRef(new SimpleReactValidator());
  const locationData = useLocation().state;
  const history = useHistory();

  let stateExists = false;
  if (typeof locationData !== 'undefined') {
    stateExists = true
  }

  useEffect(() => {
    console.log(locationData);
  },[])
  

  const [paymentMethodSeller, setPaymentMethodSeller] = useState({
    jazzCash: "none",
    easyPaisa: "none",
    bank: "none"
  })

  const [error, setError] = useState({
    seller: false,
    buyer: false
  })

  let initialObject = {
    sellerMail: stateExists ? locationData.sellerMail : "",
    buyerMail: stateExists ? locationData.buyerMail : "",
    sendingAmount: stateExists ? locationData.requestAmount : "",
    recievingAmount: stateExists ? locationData.recievingAmount : "",
    userPhone: "",
    userEmail: stateExists ? locationData.requesterMail : "",
    userOTP: "",
    commission: stateExists ? locationData.commission : "",
    OTPvalidity: false,
    submitButton: false,
    render: false,
    holdingDays : "",
    termAgreement : "",
    recIBAN: "",
    accTitle: "",
    dueDate : "",
    paymentMethodSeller: "",
    easyNumberSeller: "",
    jazzNumberSeller: "",
    authenticUser:false,
  }

  const [requestForm, setrequestForm] = useState(initialObject);

  useEffect(() => {
    if(isAuthenticUser()){
      let loggedInUser = JSON.parse(localStorage.getItem('user'));
      setrequestForm(prevValue => {
        return {
          ...prevValue,
          authenticUser:true,
          sellerMail:loggedInUser.email,
          userPhone:loggedInUser.phone,
          seller_id:loggedInUser.user_id
        }
      })
    }
  },[])



  function changePaymentMethodSeller(event) {
    const value = event.target.value;
    let basic = {
      jazzCash: "none",
      easyPaisa: "none",
      bank: "none"
    }
    simpleValidator.current.purgeFields()
    if (value !== "") {
      setPaymentMethodSeller({
        ...basic,
        [value]: "block"
      })
      setrequestForm(prevValue => {
        return {
          ...prevValue,
          paymentMethodSeller: value
        }
      })
    } else {
      setPaymentMethodSeller(basic)
    }

  }

  function handleFormChange(event) {

    const { name, value } = event.target;
    simpleValidator.current.showMessageFor(name)
    setrequestForm(prevValue => {
      if (name === "sendingAmount") {

        let commissionValue = Math.ceil(Number((value / 100) * commissionPerc));
        let recieveMoney = Number(value) - commissionValue;

        return {

          ...prevValue,
          [name]: value,
          recievingAmount: recieveMoney,
          commission: commissionValue

        }

      } else {

        return {
          ...prevValue,
          [name]: value
        }

      }

    })

  }

  const sendOTP = async () => {
    let response = await sendOtp({ email: requestForm.sellerMail })
    if (response.status) {
      setOtp(response.otp);
      timerRef.current.start();
      console.log('otp is, ', response.otp)
    }
    console.log(response);
  }

  //OTP Validation Function
  function validateOTP() {
    //console.log(otp + '  ' + sendForm.userOTP);
    if (otp == requestForm.userOTP) {

      setrequestForm(prevValue => {
        return {
          ...prevValue,
          OTPvalidity: true,
        }
      })
      setOtp(null);
      timerRef.current.pause();
    }else{
      setrequestForm(prevValue => {
        return {
          ...prevValue,
          OTPvalidity: false,
        }
      })
    }
  }

  function submitForm() {
    console.log("submitted");

    //Custom Validation Expression for email or phone
    var mailFormat = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})|([0-9]{10})+$/;
    if (!mailFormat.test(requestForm.buyerMail)) {
      setError(prevValue => {
        return {
          ...prevValue,
          buyer: true
        }

      })
    }
    if (!mailFormat.test(requestForm.sellerMail)) {
      setError(prevValue => {
        return {
          ...prevValue,
          seller: true
        }

      })
    }
    //Custom Validation Check Ends for Email or Phone

    if (simpleValidator.current.allValid() && requestForm.OTPvalidity && mailFormat.test(requestForm.buyerMail) && mailFormat.test(requestForm.sellerMail) ) {
      //alert('You submitted the form and stuff!');

      //Checking Seller Payment account By Payment Method
      let accNumberSeller = "";
      if (requestForm.paymentMethodSeller === "jazzCash") { accNumberSeller = requestForm.jazzNumberSeller }
      if (requestForm.paymentMethodSeller === "easyPaisa") { accNumberSeller = requestForm.easyNumberSeller }
      if (requestForm.paymentMethodSeller === "bank") { accNumberSeller = requestForm.recIBAN }
      let methodArray = ["" , "easyPaisa" , "jazzCash" , "bank" , "card"];

      history.push({
        pathname: "/requestmoneyconfirm",
        data : {
          accountNumberSeller: accNumberSeller,
          paymentMethodSeller : methodArray.indexOf(requestForm.paymentMethodSeller),
          buyerMail : requestForm.buyerMail,
          sendingAmount: requestForm.sendingAmount,
          commission: requestForm.commission,
          termAgreement : requestForm.termAgreement,
          recievingAmount : requestForm.recievingAmount,
          holdingDays: requestForm.holdingDays,
          initiator: "seller",
          sellerMail: requestForm.sellerMail,
          seller_id: requestForm.seller_id,
        }
      })
    } else {

      simpleValidator.current.showMessages();
      setrequestForm(prevValue => {
        return {
          ...prevValue,
          render: true
        }
      })

      // rerender to show messages for the first time
      // you can use the autoForceUpdate option to do this automatically`
      //simpleValidator.forceUpdate();
    }
  }

  useEffect(() => {

  }, [requestForm.render])



  return (
    <div id="content" class="py-4">
      <div class="container">
        <h2 class="font-weight-400 text-center mt-3">Initiate Deal<span className="text-muted">(Seller)</span></h2>
        <p class="text-4 text-center mb-4">Initiate a Deal on anytime, anywhere in  Pakistan.</p>
        <div class="row">
          <div class="col-md-10 col-lg-10 col-xl-10 mx-auto">
            <div class="bg-light shadow-sm rounded p-3 p-sm-4 mb-4">
              <h3 class="text-5 font-weight-400 mb-3">Deal Details</h3>
              {/* Send Money Form
            ============================================= */}
              <form id="form-send-money" >
                <div className="form-row">
                  <div className="col-lg-6">
                    <div class="form-group">
                      <label for="emailID">Seller Email or Phone</label>
                      <div className="input-group">
                        <div className="input-group-prepend"> <span className="input-group-text"><GoMail /></span> </div>
                        <input disabled={requestForm.authenticUser} value={requestForm.sellerMail} onChange={handleFormChange} type="text" className="form-control" placeholder="Seller Email or Phone" name="sellerMail" />

                      </div>
                      {error.seller ? <p className="text-danger">Invalid email or phone</p> : null}
                    </div>
                  </div>
                  <div className="col-lg-6">
                    <div className="form-group">
                      <label htmlFor="youSend">Buyer Email or Phone</label>
                      <div className="input-group">
                        <div className="input-group-prepend"> <span className="input-group-text"><GoMail /></span> </div>
                        <input value={requestForm.buyerMail} onChange={handleFormChange} type="text" className="form-control" placeholder="Buyer Email or Phone" name="buyerMail" />
                      </div>
                      {error.buyer ? <p className="text-danger">Invalid email or phone</p> : null}
                    </div>
                  </div>
                </div>

                

                <div className="form-row">

                  <div className="col-lg-6">
                    <div class="form-group">
                      <label for="youSend">Buyer Sends</label>
                      <div class="input-group">
                        <div class="input-group-prepend"> <span class="input-group-text">PKR</span> </div>
                        <input name="sendingAmount" type="number" value={requestForm.sendingAmount} onChange={handleFormChange} class="form-control" placeholder="" />
                      </div>
                      {simpleValidator.current.message('sendingAmount', requestForm.sendingAmount, 'required|currency|min:4|min:1000,num', { className: 'text-danger' })}
                    </div>
                  </div>

                  <div className="col-lg-6">
                    <div class="form-group">
                      <label for="recipientGets">You Get</label>
                      <div class="input-group">
                        <div class="input-group-prepend"> <span class="input-group-text">PKR</span> </div>
                        <input type="number" value={requestForm.recievingAmount} onChange={handleFormChange} name="recievingAmount" readOnly class="form-control" />
                      </div>
                    </div>
                  </div>
                  <p class="text-muted text-center">Deal Vow Fees - <span class="font-weight-700">{requestForm.commission}</span> , it will be charged only <span class="font-weight-500">{commissionPerc}% </span>to keep your money safe.</p>
                </div>

                <div className="form-row">

                  <div className="col-lg-8">
                    <div class="form-group">
                      <label for="youSend">Term Agreement<span className="text-info ml-1 text-1"  ><Tooltip style={{display:'inline'}}  title="The agreement to be agreed by both buyer and seller.." arrow><Icon className="fa fa-question-circle text-3" color="info" /></Tooltip></span></label>

                      <textarea name="termAgreement" rows="1"  value={requestForm.termAgreement} onChange={handleFormChange} class="form-control" placeholder="Your Agreement" ></textarea>

                      {simpleValidator.current.message('termAgreement', requestForm.termAgreement, 'min:20|max:200', { className: 'text-danger' })}
                    </div>
                  </div>

                  <div className="col-lg-4">
                    <div class="form-group">
                      <label for="recipientGets">Holding Days<span className="text-info ml-1 text-1"  ><Tooltip style={{display:'inline'}}  title="The Number of days it will take your buyer to confirm successfull delivery." arrow><Icon className="fa fa-question-circle text-3" color="info" /></Tooltip></span></label>
                      <div class="input-group">
                        <div class="input-group-prepend"> <span class="input-group-text"><MdToday /></span> </div>
                        <input type="number" value={requestForm.holdingDays} onChange={handleFormChange} name="holdingDays"  class="form-control" />

                      </div>
                      {simpleValidator.current.message('holdingDays', requestForm.holdingDays, 'required|numeric|min:1,num|max:15,num', { className: 'text-danger' })}
                    </div>
                  </div>
                </div>
              <div className="form-row" style={{textAlign: 'center'}}>
                <p style={{fontWeight: "1200px" , fontSize: "24px"}}>Your Details</p>
                <hr />
              </div>

              {/* Payment Method for seller */}
              <div className="form-row">
                  <div class="col-lg-6">
                    <div class="form-group">
                      <label for="cardHolderName">Select Seller<span className="text-muted">(Reciever)</span> Payment Method</label>
                      <select className="form-control" onChange={changePaymentMethodSeller}>
                        <option value="">Please Select Payment Method</option>
                        <option value="jazzCash">JazzCash</option>
                        <option value="easyPaisa">EasyPaisa</option>
                        <option value="bank">Bank</option>
                      </select>
                      {simpleValidator.current.message('paymentMethodSeller', requestForm.paymentMethodSeller, 'required')}
                    </div>
                  </div>
                  {/* JazzCAsh Div */}
                  {paymentMethodSeller.jazzCash === "block" && <div class="col-lg-6" >
                    <div class="form-group">
                      <label for="cvvNumber">Mobile Number </label>
                      <input value={requestForm.jazzNumberSeller} onChange={handleFormChange} name="jazzNumberSeller" type="text" class="form-control" required placeholder="JazzCash Account Number" />
                      {simpleValidator.current.message('jazzNumberSeller', requestForm.jazzNumberSeller, 'required|phone|min:11|max:11', { className: 'text-danger' })}
                      {/* { simpleValidator.current.message('jazzNumberSeller', sendForm.jazzNumberSeller, 'required|phone|min:11|max:11', { className: 'text-danger' } ) } */}
                    </div>
                  </div>}
                  {/* Jazzcash div end */}
                  {/* EasyPaisa Div */}
                  {paymentMethodSeller.easyPaisa === "block" && <div class="col-lg-6">
                    <div class="form-group">
                      <label for="cvvNumber">Mobile Number </label>
                      <input value={requestForm.easyNumberSeller} onChange={handleFormChange} name="easyNumberSeller" type="text" class="form-control" required placeholder="EasyPaisa Account Number" />
                      {simpleValidator.current.message('easyNumberSeller', requestForm.easyNumberSeller, 'required|phone|min:11|max:11', { className: 'text-danger' })}
                    </div>
                  </div>}
                  {/* Easy Paisa div end */}
                </div>

                {paymentMethodSeller.bank === "block" && <div id="bank-method-div" className="form-row">
                  <div className="col-lg-4">
                    <div class="form-group">
                      <label for="emailID">Recipient Account Title</label>
                      <div className="input-group">
                        <div className="input-group-prepend"> <span className="input-group-text">Title</span> </div>
                        <input value={requestForm.accTitle} onChange={handleFormChange} type="text" className="form-control" placeholder="Reciepient Account Title" name="accTitle" />

                      </div>
                      {simpleValidator.current.message('accTitle', requestForm.accTitle, 'required|max:24', { className: 'text-danger' })}
                    </div>
                  </div>
                  <div className="col-lg-8">
                    <div className="form-group">
                      <label htmlFor="youSend">Recipient IBAN</label>
                      <div className="input-group">
                        <div className="input-group-prepend"> <span className="input-group-text"><AiOutlineBank /></span> </div>
                        <input value={requestForm.recIBAN} onChange={handleFormChange} type="text" className="form-control" placeholder="Recipient Bank IBAN Number" name="recIBAN" />
                      </div>
                      {simpleValidator.current.message('recIBAN', requestForm.recIBAN, 'required|min:20|max:24', { className: 'text-danger' })}
                    </div>
                  </div>
                </div> }
                {/* Payment Method for seller Ends */}

                <div class="form-row">
                  
                
                  <div class="col-lg-4">
                    <div className="form-group">
                      <label htmlFor="youSend">Your Phone</label>
                      <div className="input-group">
                        <div className="input-group-prepend"> <span className="input-group-text"><BiPhone /></span> </div>
                        <input disabled={requestForm.authenticUser} type="text" value={requestForm.userPhone} name="userPhone" onChange={handleFormChange} className="form-control" placeholder="Your Phone Number" />
                      </div>
                      {simpleValidator.current.message('userPhone', requestForm.userPhone, 'required|phone|max:11', { className: 'text-danger' })}
                    </div>
                  </div>
                  <div className="col-lg-2">
                    <div className="form-group">
                      <label htmlFor="youSend">Get Your OTP</label>
                      <div className="input-group">
                      <button type="button" disabled={otp || requestForm.OTPvalidity} onClick={sendOTP} className="btn btn-warning btn-md">Send OTP</button>
                        {/* {timer < 60 && <p>{timer}</p>} */}
                        <Countdown ref={timerRef} autoStart={false} date={Date.now() + 15000}  renderer={renderer} />
                      </div>
                    </div>
                  </div>
                </div>

                <div class="form-row">
                <div class="col-lg-5">
                    <div className="form-group">
                      <label htmlFor="youSend">Due Acceptance Date<span className="text-info ml-1 text-1"  ><Tooltip style={{display:'inline'}}  title="Due date of acceptance of payment request by the Buyer." arrow><Icon className="fa fa-question-circle text-3" color="info" /></Tooltip></span></label>
                      <div className="input-group">
                        <div className="input-group-prepend"> <span className="input-group-text"><BsCalendarFill /></span> </div>
                        <input type="date" value={requestForm.dueDate} onChange={handleFormChange} className="form-control" placeholder="Due Date" name="dueDate" />
                      </div>
                      {simpleValidator.current.message('dueDate', requestForm.dueDate, 'required', { className: 'text-danger' })}
                    </div>
                  </div>
                  <div class="col-lg-5">
                    <div className="form-group">
                      <label htmlFor="youSend">Enter OTP</label>
                      <div className="input-group">
                        <div className="input-group-prepend"> <span className="input-group-text"><Si1Password /></span> </div>
                        <input type="number" value={requestForm.userOTP} onChange={handleFormChange} className="form-control" placeholder="OTP" name="userOTP" />
                      </div>
                      {requestForm.OTPvalidity ? <p className="text-success">Valid OTP</p> : <p className="text-danger">OTP is required</p>}
                    </div>
                  </div>
                  <div className="col-lg-2">
                    <div className="form-group">
                      <label htmlFor="youSend">Validate OTP</label>
                      <div className="input-group">
                        <button type="button" disabled={requestForm.OTPvalidity || !otp} onClick={validateOTP} className="btn btn-success btn-md">Validate</button>
                      </div>
                    </div>
                  </div>
                </div>



                <p class="text-muted text-center">If the recipient does not withdraw payment <span class="font-weight-700">within 4 working days</span> , it will be transferred back to <span class="font-weight-500">your account</span></p>
                <hr />
                <p class="mb-1">Recieving Amount <span class="text-3 float-right">PKR - {requestForm.recievingAmount}</span></p>
                <hr />
                <p class="mb-1">Total fees<span className="text-info ml-1 text-1"  ><Tooltip style={{display:'inline'}}  title="Deal Vow charges a small amount of processing fee to process your deals." arrow><Icon className="fa fa-question-circle text-3" color="info" /></Tooltip></span> <span class="text-3 float-right">PKR - {requestForm.commission}</span></p>
                <hr />
                <p class="font-weight-500">Total To Pay <span class="text-3 float-right">PKR - {requestForm.sendingAmount}</span></p>
                <button disabled={!requestForm.OTPvalidity} onClick={submitForm} type="button" class="btn btn-primary btn-block">Continue</button>
              </form>
              {/* Send Money Form end */}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
