import React from 'react'
import { useHistory, useLocation, Redirect } from 'react-router-dom'
export default function MainContent() {
  const locationData = useLocation().data;
  const history = useHistory();
  let locNotSet = true;
  if (typeof locationData !== 'undefined') {
    console.log(locationData);
    locNotSet = false;
  }
  function sendAgain() {
    history.push({ pathname: '/dealpage' })
  }

  if (locNotSet) {
    return (
      <Redirect to="/requestmoney" />
    )
  } else {
    return (
      <div id="content" className="py-4">
        <div className="container">
          <h2 className="font-weight-400 text-center mt-3 mb-4">Initiate Deal</h2>
          <div className="row">
            <div className="col-md-8 col-lg-6 col-xl-5 mx-auto">
              {/*} Send Money Success
          ============================================= */}
              <div className="bg-light shadow-sm rounded p-3 p-sm-4 mb-4">
                <div className="text-center my-5">
                  <p className="text-center text-success text-20 line-height-07"><i className="fas fa-check-circle"></i></p>
                  <p className="text-center text-success text-8 line-height-07">Success!</p>
                  <p className="text-center text-4">Deal Initiated</p>
                </div>
                <p className="text-center text-3 mb-4">You've Succesfully sent <span className="text-4 font-weight-500">PKR - {locationData.recievingAmount}</span> to <span className="font-weight-500">{locationData.recEmail}</span>, See transaction details in the email sent to you</p>
                <button onClick={sendAgain} type="button" className="btn btn-primary btn-block">Go to Deal Page</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

}
