import React from 'react'
import { useLocation, useHistory, Redirect } from 'react-router-dom'
import { initiateDeal } from "../../../store/actions/deal.actions"


export default function MainContent() {
    let methodArray = ["" , "easyPaisa" , "jazzCash" , "bank" , "card"];
    const locationData = useLocation().data;
    const history = useHistory();
    let locNotSet = true;
    if (typeof locationData !== 'undefined') {
        console.log(locationData);
        locNotSet = false;
    }

    async function confirmTransaction() {
        console.log("triggering");
        

        let response = await initiateDeal(locationData);
        let status = response.status;
        console.log(response);
        if (status) {
            history.push({
                pathname: "/requestmoneysuccess",
                data: {
                    recievingAmount: locationData.sendingAmount,
                    buyerMail: locationData.buyerMail
                }
            })
        } else {
          console.log("Bad Request")
        }
        
        
    }
    if (locNotSet) {
        return (
            <Redirect to="/requestmoney" />
        )
    } else {
        return (
            <div id="content" className="py-4">
                <div className="container">
                    <h2 className="font-weight-400 text-center mt-3">Initiate Deal</h2>
                    <p className="text-4 text-center mb-4">You are initiating deal with <span className="font-weight-500">{locationData.buyerMail}</span></p>
                    <div className="row">
                        <div className="col-md-8 col-lg-6 col-xl-5 mx-auto">
                            <div className="bg-light shadow-sm rounded p-3 p-sm-4 mb-4">

                                {/* Send Money Confirm
                ============================================= */ }
                                <form id="form-send-money" >
                                    <div className="form-group">
                                        <label for="description">Term Agreement</label>
                                        <textarea className="form-control" readOnly rows="2" id="description" required placeholder="Agreement Details">{locationData.termAgreement}</textarea>
                                    </div>
                                    <h3 className="text-5 font-weight-400 mb-3">Details</h3>
                                    <div className=""><p className="mb-1">Your Account <span className="text-3 float-right">{methodArray[locationData.paymentMethodSeller]} - {locationData.accountNumberSeller}</span></p>
                                    </div>
                                    <hr />
                                    <div className=""><p className="mb-1">Payer <span className="text-3 float-right">{locationData.buyerMail}</span></p>
                                    </div>
                                    <hr />
                                    <h3 className="text-5 font-weight-400 mb-3">Payment Details</h3>
                                    <p className="mb-1">Requested Amount <span className="text-3 float-right">PKR - {locationData.recievingAmount}</span></p>
                                    <hr />
                                    <p className="mb-1">Service Fee <span className="text-3 float-right">PKR - {locationData.commission}</span></p>
                                    <hr />
                                    <hr />
                                    <p className="font-weight-500">Total<span className="text-3 float-right">PKR - {locationData.sendingAmount}</span></p>
                                    <button onClick={confirmTransaction} type="button" className="btn btn-primary btn-block">Confirm Deal</button>
                                </form>
                                {/* Send Money Confirm end */}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }

}
