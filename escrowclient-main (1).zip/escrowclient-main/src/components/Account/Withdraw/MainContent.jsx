import React , {useState , useEffect , useRef} from 'react'
import {useHistory} from "react-router-dom"
import {   withdrawMoney , getUserAccounts } from "../../../store/actions/user.actions"
export default function MainContent() {
  let loggedInUser = JSON.parse(localStorage.getItem('user'));
  let history = useHistory();
    const acc_id = useRef();
    //const card_cvc = useRef();
    const amount = useRef();
    let [accounts, setaccounts] = useState([])

    async function fetchAccounts() {
      let res = await getUserAccounts(loggedInUser.user_id);
      if(res !== undefined){
        setaccounts(res.data);
      }
      
  
    }
  
    useEffect(() => {
      fetchAccounts();
    }, [])


    async function submitWithdraw (e){
      e.preventDefault();
      let res=  await withdrawMoney({
        user_id: loggedInUser.user_id,
        method_id:3,
        amount:Number(amount.current.value),
        acc_id:Number(acc_id.current.value),
      })
      console.log(res)
      if(res.status === 200){
        history.push({pathname:"/profile"})
      }
    }
    return (
        <div id="content" class="py-4">
    <div class="container">
      <h2 class="font-weight-400 text-center mt-3 mb-4">Withdraw Money</h2>
      <div class="row">
        <div class="col-md-8 col-lg-6 col-xl-5 mx-auto">              
          <div class="bg-light shadow-sm rounded p-3 p-sm-4 mb-4"> 
            
            {/* Deposit Money Form
            ============================================= */}
            <form id="form-send-money" onSubmit={submitWithdraw}>
              <div class="form-group">
                <label for="youSend">Amount</label>
                <div class="input-group">
                  <div class="input-group-prepend"> <span class="input-group-text">$</span> </div>
                  <input type="number" ref={amount} class="form-control" data-bv-field="youSend" id="youSend"  placeholder="" />
                </div>
              </div>
              <div class="form-group">
                <label for="paymentMethod">Payment Method</label>
                <select id="cardType" class="custom-select" required ref={acc_id}>
                  <option value="">Select Bank Account</option>
                  {accounts.map(acc=><option value={acc.acc_id}>{acc.bank_name} -XXXXXXXXXXXX-{acc.acc_number.substring(acc.acc_number.length - 6)}</option>)}
                </select>
              </div>
              
              {/* <p class="text-muted mt-4">Transactions fees <span class="float-right d-flex align-items-center"><del>1.00 USD</del> <span class="bg-success text-1 text-white font-weight-500 rounded d-inline-block px-2 line-height-4 ml-2">Free</span></span></p>
              <hr />
              <p class="font-weight-500">You'll withdraw <span class="text-3 float-right">1,000.00 PKR</span></p> */}
              <button class="btn btn-primary btn-block" type="submit">Continue</button>
            </form>
            {/* Deposit Money Form end */} 
          </div>
        </div>
      </div>
    </div>
  </div>
    )
}
