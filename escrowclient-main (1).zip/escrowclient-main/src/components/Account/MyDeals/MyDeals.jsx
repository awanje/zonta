import React , {useEffect , useState} from 'react'
import PreLoader from '../../mini_features/PreLoader.jsx'
import NavBar from '../../menu/NavBarWhite.jsx'
import SecondaryMenu from  '../../SecondaryMenu'
import LeftPanel from '../LeftPanel'
import MiddlePanel from './MiddlePanel'
import Footer from '../../common/Footer'
import $ from 'jquery'
import { getUserProfile } from "../../../store/actions/user.actions"

export default function DashBoard() {
    const [ userDetails, setUserDetails ] = useState({
        full_name: "",
        username: "",
        email: "",
        phone: "",
        address: "",
        profile_img: "",
        user_preference: ""
      });
    useEffect(() => {
        $('[data-loader="circle-side"]').fadeOut() 
              $('#preloader').delay(333).fadeOut('slow')
              $('body').delay(333) 
      })
      useEffect(async () => {
        let response = await getUserProfile(6);
        console.log(response);
        setUserDetails(response.user);
      }, [])
    return (
        <>
            <PreLoader />
            <NavBar />
            <SecondaryMenu />
            <div class="container">
                <div class="row">
                    <LeftPanel
                    user = {userDetails}
                    updateUser={setUserDetails} />
                    <MiddlePanel />
                </div>
            </div>

            <Footer />
        </>
    )
}

