import React, { useState, useEffect } from 'react'
import { getUserDeals } from "../../../store/actions/user.actions"
import { Link, useHistory } from "react-router-dom"
export default function MiddlePanel() {
  let loggedInUser = JSON.parse(localStorage.getItem('user'));
  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "June",
    "July", "Aug", "Sep", "Oct", "Nov", "Dec"
  ];
  const history = useHistory();
  const [userDeals, setUserDeals] = useState([{}])

  useEffect(() => {
    async function fetchData() {
      let response = await getUserDeals(loggedInUser.user_id);
      console.log(response);
      setUserDeals(response.data);
    }
    fetchData();

  }, [])

  function dateParser(date, type) {
    if (type === 'day') {
      let d = new Date(date);
      let n = d.getDay();
      return n;
    }
    if (type === 'month') {
      let d = new Date(date);
      let n = d.getMonth();
      n = monthNames[n];
      return n;
    }
  }

  function redirectDeal(deal_id) {
    history.push({ pathname: "/dealPage", state: { deal_id: deal_id } })
  }

  useEffect(() => {
    console.log(userDeals)

  }, [userDeals])
  return (
    <div class="col-lg-9">



      {/* Recent Activity
          =============================== */}
      <div class="bg-light shadow-sm rounded py-4 mb-4">
        <h3 class="text-5 font-weight-400 d-flex align-items-center px-4 mb-3">My Deals</h3>

        {/* Title
            =============================== */}
        <div class="transaction-title py-2 px-4">
          <div class="row">
            <div class="col-2 col-sm-1 text-center"><span class="">Date</span></div>
            <div class="col col-sm-7">Description</div>
            <div class="col-auto col-sm-2 d-none d-sm-block text-center">Status</div>
            <div class="col-3 col-sm-2 text-right">Amount</div>
          </div>
        </div>
        {/* Title End */}

        {/* Transaction List
            =============================== */}
        <div class="transaction-list">
          {userDeals.map((deal) => <>

            <div class="transaction-item px-4 py-3" >
              {/* <Link
              //onClick={redirectDeal(deal.deal_id)}
              to={{pathname:"/dealPage/33"}}
              > */}
                <div class="row align-items-center flex-row">
                  <div class="col-2 col-sm-1 text-center"> <span class="d-block text-4 font-weight-300">{dateParser(deal.createdAt, "day")}</span> <span class="d-block text-1 font-weight-300 text-uppercase">{dateParser(deal.createdAt, "month")}</span> </div>
                  <div class="col col-sm-7"> <span class="d-block text-4">{deal.buyer_id === loggedInUser.user_id ? deal.buyer_mail : deal.seller_mail}</span> <span class="text-muted">{deal.buyer_id === loggedInUser.user_id ? "You're a Buyer in it" : "You're a Seller in it"}</span> </div>
                  <div class="col-auto col-sm-2 d-none d-sm-block text-center text-3"> <span class="text-warning" data-toggle="tooltip" data-original-title="In Progress"><i class="fas fa-hourglass"></i></span> </div>
                  <div class="col-3 col-sm-2 text-right text-4"> <span class="text-nowrap">{deal.buyer_id === loggedInUser.user_id ? `- ${deal.deal_amount}` : `+ ${deal.deal_amount}`}</span> <span class="text-2 text-uppercase">(PKR)</span> </div>
                </div>
              {/* </Link> */}
            </div>

          </>
          )}

          {/* <div class="transaction-item px-4 py-3" data-toggle="modal" data-target="#transaction-detail">
            <div class="row align-items-center flex-row">
              <div class="col-2 col-sm-1 text-center"> <span class="d-block text-4 font-weight-300">15</span> <span class="d-block text-1 font-weight-300 text-uppercase">APR</span> </div>
              <div class="col col-sm-7"> <span class="d-block text-4">Envato Pty Ltd</span> <span class="text-muted">Payment Received</span> </div>
              <div class="col-auto col-sm-2 d-none d-sm-block text-center text-3"> <span class="text-success" data-toggle="tooltip" data-original-title="Completed"><i class="fas fa-check-circle"></i></span> </div>
              <div class="col-3 col-sm-2 text-right text-4"> <span class="text-nowrap">+ $562</span> <span class="text-2 text-uppercase">(USD)</span> </div>
            </div>
          </div>
          <div class="transaction-item px-4 py-3" data-toggle="modal" data-target="#transaction-detail">
            <div class="row align-items-center flex-row">
              <div class="col-2 col-sm-1 text-center"> <span class="d-block text-4 font-weight-300">28</span> <span class="d-block text-1 font-weight-300 text-uppercase">MAR</span> </div>
              <div class="col col-sm-7"> <span class="d-block text-4">Patrick Cary</span> <span class="text-muted">Payment Sent</span> </div>
              <div class="col-auto col-sm-2 d-none d-sm-block text-center text-3"> <span class="text-danger" data-toggle="tooltip" data-original-title="Cancelled"><i class="fas fa-times-circle"></i></span> </div>
              <div class="col-3 col-sm-2 text-right text-4"> <span class="text-nowrap">- $60</span> <span class="text-2 text-uppercase">(USD)</span> </div>
            </div>
          </div> */}
        </div>
        {/* Transaction List End */}

        {/* Transaction Item Details Modal
            =========================================== */}
        <div id="transaction-detail" class="modal fade" role="dialog" aria-hidden="true">
          <div class="modal-dialog modal-dialog-centered transaction-details" role="document">
            <div class="modal-content">
              <div class="modal-body">
                <div class="row no-gutters">
                  <div class="col-sm-5 d-flex justify-content-center bg-primary rounded-left py-4">
                    <div class="my-auto text-center">
                      <div class="text-17 text-white my-3"><i class="fas fa-building"></i></div>
                      <h3 class="text-4 text-white font-weight-400 my-3">Envato Pty Ltd</h3>
                      <div class="text-8 font-weight-500 text-white my-4">$557.20</div>
                      <p class="text-white">15 March 2019</p>
                    </div>
                  </div>
                  <div class="col-sm-7">
                    <h5 class="text-5 font-weight-400 m-3">Transaction Details
                          <button type="button" class="close font-weight-400" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                    </h5>
                    <hr />
                    <div class="px-3">
                      <ul class="list-unstyled">
                        <li class="mb-2">Payment Amount <span class="float-right text-3">$562.00</span></li>
                        <li class="mb-2">Fee <span class="float-right text-3">-$4.80</span></li>
                      </ul>
                      <hr class="mb-2" />
                      <p class="d-flex align-items-center font-weight-500 mb-4">Total Amount <span class="text-3 ml-auto">$557.20</span></p>
                      <ul class="list-unstyled">
                        <li class="font-weight-500">Paid By:</li>
                        <li class="text-muted">Envato Pty Ltd</li>
                      </ul>
                      <ul class="list-unstyled">
                        <li class="font-weight-500">Transaction ID:</li>
                        <li class="text-muted">26566689645685976589</li>
                      </ul>
                      <ul class="list-unstyled">
                        <li class="font-weight-500">Description:</li>
                        <li class="text-muted">Envato March 2019 Member Payment</li>
                      </ul>
                      <ul class="list-unstyled">
                        <li class="font-weight-500">Status:</li>
                        <li class="text-muted">Completed</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Transaction Item Details Modal End */}

        {/* View all Link
            =============================== */}
        <div class="text-center mt-4"><a href="transactions.html" class="btn-link text-3">View all<i class="fas fa-chevron-right text-2 ml-2"></i></a></div>
        {/* View all Link End */}

      </div>
      {/* Recent Activity End */}
    </div>
  )
}
