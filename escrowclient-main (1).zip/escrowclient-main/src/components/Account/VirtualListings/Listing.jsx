import React from 'react'

export default function Listing(props) {

    return (
        //account-card-primary
        <>
            <div key={props.key} className="col-12 col-sm-6 col-lg-4" >
                <div className="account-card  text-white rounded  mb-4 mb-lg-0" style={{ backgroundColor: "white" }}>
                    <div>
                    <img src={props.imgUrl} style={{ height: "100%", width: "100%", marginBottom: "0px" }} />
                    </div>
                    {/* <div className="p-3">
                <p className="d-flex align-items-center m-0"> <span className="text-uppercase font-weight-500">Smith Rhodes</span>  </p>
                
                </div> */}
                    <div style={{ borderBottom: '1px solid', boxShadow: "2px 2px 2px 2px #C0C2C6", borderRadius: "2px", padding: "5px", marginLeft: "1px", marginRight: "1px", backgroundColor: "white", marginTop: "0px" }}>
                        <p className="text-4 font-weight-500" style={{ color: "black" }}>{props.title}<span className="float-right" style={{ color: "green" }}>Rs.{props.price}</span></p>

                    </div>
                    <div className="account-card-overlay rounded">
                        {/* <a href="#" data-target="#edit-card-details" data-toggle="modal" className="text-light btn-link mx-2"><span className="mr-1"><i className="fas fa-edit"></i></span>Edit</a>  */}
                        <a href="/#" onClick={props.viewSetter(props.listingID)} data-target="#view-listing-details" data-toggle="modal" className="text-light btn-link mx-2"><span className="mr-1"><i className="fas fa-eye"></i></span>View</a>
                        <a href="#" className="text-light btn-link mx-2"><span className="mr-1"><i className="fas fa-minus-circle"></i></span>Delete</a>
                    </div>
                </div>


            </div>
            
        </>

    )
}
