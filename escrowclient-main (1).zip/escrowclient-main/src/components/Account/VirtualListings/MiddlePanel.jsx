import React, { useState, useRef } from 'react'
import Listing from './Listing'
import uuid from 'react-uuid';
import SimpleReactValidator from 'simple-react-validator';
import Select from 'react-select'
import $ from 'jquery'
const options = [
  { value: 'domain', label: 'Domain' },
  { value: 'hosting', label: 'Hosting' },
  { value: 'cloud', label: 'Cloud' }
]

export default function MiddlePanel() {
  const simpleValidator = useRef(new SimpleReactValidator());
  const [viewListing, setViewListing] = useState(1);
  const [listings, setListings] = useState([{
    title: "New Lisitng 1",
    image: "images/gig1.jpg",
    price: 500,
    protectionDays: "",
    details: "",
    id: 0,
    category: "domain"
  }, {
    title: "New Lisitng 2",
    image: "images/gig1.jpg",
    price: 1000,
    protectionDays: "",
    details: "",
    id: 1,
    category: "domain"
  }])

  const [addListingForm, setAddListingForm] = useState({
    title: "",
    price: "",
    protectionDays: "",
    details: "",
    image: "images/gig1.jpg",
    render: false,
    category: ""
  })

  function handleFormChange(event) {
    console.log(event)
    const { name, value } = event.target;
    simpleValidator.current.showMessageFor(name)
    setAddListingForm(prevValue => {
      return {
        ...prevValue,
        [name]: value
      }
    })

  }

  function handleFormSubmit() {
    console.log("submitted");
    if (simpleValidator.current.allValid()) {
      alert('You submitted the form and stuff!');
      setListings(prevValue => {
        return [
          ...prevValue,
          {
            title: addListingForm.title,
            price: addListingForm.price,
            protectionDays: addListingForm.protectionDays,
            details: addListingForm.details,
            image: addListingForm.image
          }
        ]
      })
      $('#close_modal_btn').click();
      setAddListingForm({
        title: "",
        price: "",
        protectionDays: "",
        details: "",
        image: "images/gig1.jpg",
        render: false
      })

    } else {

      simpleValidator.current.showMessages();
      setAddListingForm(prevValue => {
        return {
          ...prevValue,
          render: true
        }
      })

      // rerender to show messages for the first time
      // you can use the autoForceUpdate option to do this automatically`
      //simpleValidator.forceUpdate();
    }
  }

  return (
    <div className="col-lg-9">

      {/* Credit or Debit Cards
          ============================================= */}
      <div className="bg-light shadow-sm rounded p-4 mb-4">
        <h3 className="text-5 font-weight-400 mb-4">Virtual Listings <span className="text-muted text-4">(for payments)</span></h3>
        <div className="row">
          {listings.map(listing => {
            return (<Listing
              imgUrl={listing.image}
              title={listing.title}
              key={uuid()}
              price={listing.price}
              viewSetter={setViewListing}
              listingID={listing.id}
            />)
          })}
          {/* <div className="col-12 col-sm-6 col-lg-4" style={{backgroundImage:"url(images/blue.jpg)"}}>
            
          </div> */}

          <div className="col-12 col-sm-6 col-lg-4"> <a href="" data-target="#add-new-card-details" data-toggle="modal" className="account-card-new d-flex align-items-center rounded h-100 p-3 mb-4 mb-lg-0">
            <p className="w-100 text-center line-height-4 m-0"> <span className="text-3"><i className="fas fa-plus-circle"></i></span> <span className="d-block text-body text-3">Add New Listing</span> </p>
          </a> </div>
        </div>
      </div>
      {/* View Listing Details Modal
          ================================== */}
      <div id="view-listing-details" className="modal fade" role="dialog" aria-hidden="true">
        <div className="modal-dialog modal-dialog-centered" role="document">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title font-weight-400">View Listing </h5>
              <button type="button" className="close font-weight-400" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
            </div>
            <div className="modal-body p-4">
              <img src="images/gig1.jpg" style={{ height: "240px", width: "450px" }} />
              <p className="text-4 font-weight-500" style={{ color: "black" }}>New Listing 1</p>
              <pre>
                Detail listing 1
                              <br />
                              detail listing 2
                              <br />
                              detail listing 3
                              <br />
              </pre>
              <span className="text-4 float-right" style={{ color: "green" }}>Rs.500</span>
            </div>
          </div>
        </div>
      </div>

      {/* Add New Card Details Modal
          ================================== */}
      <div id="add-new-card-details" className="modal fade" role="dialog" aria-hidden="true">
        <div className="modal-dialog modal-dialog-centered" role="document">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title font-weight-400">Add a Listing</h5>
              <button id="close_modal_btn" type="button" className="close font-weight-400" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
            </div>
            <div className="modal-body p-4">
              <form id="addCard" >


                <div className="form-group">
                  <label for="cardNumber">Listing Name</label>
                  <input type="text" onChange={handleFormChange} value={addListingForm.title} name="title" className="form-control" required placeholder="Listing Title" />
                  {simpleValidator.current.message('title', addListingForm.title, 'required|max:30', { className: 'text-danger' })}
                </div>
                <div className="form-group">
                  <label for="cardNumber">Listing Category</label>
                  <Select name="category" onChange={(value, action) => {
                    console.log(value,action)
                    setAddListingForm(prevValue => {
                      
                      return {...prevValue , [action.name]: value.value}
                    })
                  }} options={options} />

                  {simpleValidator.current.message('category', addListingForm.category, 'required', { className: 'text-danger' })}
                </div>
                <div className="form-row">
                  <div className="col-lg-6">
                    <div className="form-group">
                      <label for="expiryDate">Price</label>
                      <input type="number" className="form-control" value={addListingForm.price} name="price" onChange={handleFormChange} required placeholder="Price in PKR" />
                      {simpleValidator.current.message('price', addListingForm.price, 'required|numeric|max:100000,num', { className: 'text-danger' })}
                    </div>
                  </div>
                  <div className="col-lg-6">
                    <div className="form-group">
                      <label for="cvvNumber">Protection Days <span className="text-info ml-1" data-toggle="tooltip" data-original-title="For Visa/Mastercard, the three-digit CVV number is printed on the signature panel on the back of the card immediately after the card's account number. For American Express, the four-digit CVV number is printed on the front of the card above the card account number."><i className="fas fa-question-circle"></i></span></label>
                      <input type="number" className="form-control" value={addListingForm.protectionDays} name="protectionDays" onChange={handleFormChange} required placeholder="Protection Days" />
                      {simpleValidator.current.message('protectionDays', addListingForm.protectionDays, 'required|max:30,num', { className: 'text-danger' })}
                    </div>
                  </div>
                </div>
                <div className="form-group">
                  <label for="cardHolderName">Listing Details</label>
                  <textarea type="text" className="form-control" value={addListingForm.details} name="details" onChange={handleFormChange} required placeholder="Listing Details" ></textarea>
                  {simpleValidator.current.message('protectionDays', addListingForm.protectionDays, 'required|max:400', { className: 'text-danger' })}
                </div>
                <div className="form-group">
                  <label for="cardNumber">Listing Image</label>
                  <input type="file" className="form-control" required value="" placeholder="Listing Title" />
                </div>
                <button className="btn btn-primary btn-block" type="button" onClick={handleFormSubmit}>Add Listing</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      {/* Credit or Debit Cards End */}

    </div>
  )
}
