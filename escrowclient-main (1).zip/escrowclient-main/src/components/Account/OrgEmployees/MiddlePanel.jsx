import React, { useState, useRef, useEffect, Component, Fragment } from 'react'
import SimpleReactValidator from 'simple-react-validator';
import $ from 'jquery'
import Table from '../../common/Table2'
import { addOrgEmployee, listEmployees, updateOrgEmployee, dispatchEmpSalary } from "../../../store/actions/org.actions"
import { MdDelete } from 'react-icons/md'
import { FiEdit } from 'react-icons/fi'
import { GrSend } from 'react-icons/gr'
import { ModalProvider, Modal, useModal, ModalTransition } from 'react-simple-hook-modal';
import 'react-simple-hook-modal/dist/styles.css';
import "./custom.css"

//let listings = 

export default function MiddlePanel() {
  const [records, setRecords] = useState([]);
  const { isModalOpen, openModal, closeModal } = useModal();
  const inputRef = useRef();
  const [editRecord, setEditRecord] = useState({
    user_id: 0,
    full_name: "",
    email: "",
    phone: "",
    salary: "",
    salary_date: "",
    status: ""
  })
  const [checked, setChecked] = useState([]);
  const full_name = useRef();
  const email = useRef();
  const phone = useRef();
  const salary = useRef();
  const salary_date = useRef();
  const editfull_name = useRef();
  const editemail = useRef();
  const editphone = useRef();
  const editsalary = useRef();
  const editsalary_date = useRef();
  const editstatus = useRef();
  let loggedInUser = JSON.parse(localStorage.getItem('user'));


  async function addEmployee(e) {
    e.preventDefault();

    let empSalary = parseInt(salary.current.value);

    let addEmp = {
      full_name: full_name.current.value,
      email: email.current.value,
      phone: phone.current.value,
      salary: empSalary,
      salary_date: salary_date.current.value
    }

    let response = await addOrgEmployee(addEmp);

    if (response.status === 200) {
      alert("Employee Added");
      full_name.current.value = ""
      email.current.value = ""
      phone.current.value = ""
      salary_date.current.value = ""
    } else {
      console.log("There is Error: ", response.message);
    }
    fetchData();
    $("#add_close").click();
  }



  async function fetchData() {

    let response = "";
    if (loggedInUser.user_preference === "Organization") {
      response = await listEmployees();
      if (response.status === 200) {
        console.log("fetchData Called");
      } else {
        console.log("There is Error: ", response.message);
      }
    }
    setRecords(response.data);
  }


  useEffect(() => {
    console.log("hook being called");
    fetchData();
  }, [])


  async function updateEmployee(e) {
    e.preventDefault();

    let empSalary = parseInt(editsalary.current.value);

    let editEmp = {
      user_id: editRecord.user_id,
      full_name: editfull_name.current.value,
      email: editemail.current.value,
      phone: editphone.current.value,
      salary: empSalary,
      salary_date: editsalary_date.current.value,
      status: editstatus.current.value
    }

    // console.log(editEmp);

    let response = await updateOrgEmployee(editEmp);

    if (response.status === 200) {
      alert("Edited Employee");
    } else {
      console.log("There is Error: ", response.message);
    }
    $("#close").click();
    fetchData();
  }

  async function deleteRecord(us_id) {



    let editEmp = {
      user_id: us_id,
      status: "disabled"
    }

    // console.log(editEmp);

    let response = await updateOrgEmployee(editEmp);

    if (response.status === 200) {
      alert("Deleted Employee");
    } else {
      console.log("There is Error: ", response.message);
    }
    fetchData();
  }

  async function dispatchSalary(employees) {
    alert(employees);
    let res = await dispatchEmpSalary(employees);
    if (res.status > 399) {
      alert(res.message)
    } else {
      alert(res.data);
    }
    console.log(res);
  }
  function dispatchAll() {
    let employees = records.map(r => r.user_id);
    dispatchSalary(employees)
    console.log(employees);
  }

  async function handleCheck(id, e) {
    if (e.target.checked) {
      await setChecked(prev => [...prev, id]);
    } else {
      let array = [...checked];

      console.log("arr", array);

      const index = array.indexOf(id);
      if (index > -1) {
        array.splice(index, 1);
      }
      await setChecked(array);

    }

    //console.log(checked, e);
  }
  useEffect(() => {
    console.log(checked);
  }, [checked])


  const EditModel = () => {

    return (
      <>
        <Modal
          id={inputRef}
          isOpen={isModalOpen}
          transition={ModalTransition.BOTTOM_UP}
        >
          <div style={{
            minWidth: '500px',
            backgroundColor: 'white',
            color: 'grey',
            padding: '0px',
            minHeight: '300px',
            borderRadius: "5px",
            maxHeight: '70vh',
            zIndex: '+1'
          }}>
            <div id="edit-employee" role="dialog" >
              <div className="rsm-p-0" role="document">
                <div className="modal-content">
                  <div className="modal-header">
                    <h5 className="modal-title font-weight-400">Update Employee Details</h5>
                    <button type="button" id="close" className="close font-weight-400" onClick={closeModal} data-dismiss="modal" aria-label="Close"> <span aria-hidden="true" >&times;</span> </button>
                  </div>
                  <div className="modal-body p-4">
                    <form id="editEmployeeFrom" method="post" onSubmit={updateEmployee} >
                      <div className="row">
                        <div className="col-12 ">
                          <div className="form-group">
                            <label for="firstName">Full Name</label>
                            <input type="text" ref={editfull_name} defaultValue={editRecord.full_name} name="full_name" className="form-control" data-bv-field="firstName" id="editfirstName" required placeholder="First Name" contentEditable="true" />
                          </div>
                        </div>
                        <div className="col-12 ">
                          <div className="form-group">
                            <label for="email">Email</label>
                            <input type="email" ref={editemail} defaultValue={editRecord.email} name="email" className="form-control" data-bv-field="email" id="editemail" required placeholder="Email" />
                          </div>
                        </div>
                        <div className="col-12">
                          <div className="form-group">
                            <label for="phone">Phone</label>
                            <input type="text" ref={editphone} defaultValue={editRecord.phone} name="phone" className="form-control" data-bv-field="phone" id="editphone" required placeholder="Phone" />
                          </div>
                        </div>
                        <div className="col-12">
                          <div className="form-group">
                            <label for="salary">Salary</label>
                            <input type="number" ref={editsalary} defaultValue={editRecord.salary} name="salary" className="form-control" data-bv-field="salary" id="editsalary" required placeholder="Salary" />
                          </div>
                        </div>
                        <div className="col-12">
                          <div className="form-group">
                            <label for="salary">Salary date</label>
                            <input type="number" ref={editsalary_date} defaultValue={editRecord.salary_date} name="salary_date" className="form-control" data-bv-field="salary-date" id="editsalary-date" required placeholder="Month date " max="31" min="1" maxLength="2" />
                          </div>
                        </div>
                        <div className="col-12">
                          <div className="form-group">
                            <label for="status">Status</label>
                            {/* <input type="number" ref={editstatus} value={editRecord.status} name="status" className="form-control" data-bv-field="status" id="editstatus" required placeholder="Status" /> */}
                            <select id="status" name="status" className="form-control" ref={editstatus} defaultValue={editRecord.status} required>
                              <option value="active">active</option>
                              <option value="disabled">disabled</option>
                              <option value="pending">pending</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <button className="btn btn-primary btn-block mt-2" type="submit" >Update Employee</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Modal>
      </>
    )
  }


  var columns = [
    {
      key: "check",
      text: "  ",
      cell: (record, index) => {
        return (
          <Fragment >
            <input style={{ marginLeft: '2px', transform: 'scale(1.3)' }} class="form-check-input chkb" type="checkbox" value="" onClick={(e) => { handleCheck(records[index].user_id, e) }} />
          </Fragment>
        );
      }
    },
    {
      key: "full_name",
      text: "Name",
      className: "fonty",
      sortable: true
    },
    {
      key: "email",
      text: "Email",
      sortable: true
    },
    {
      key: "phone",
      text: "Phone",
      sortable: true
    },
    {
      key: "salary",
      text: "Salary",
      className: "salary",
      sortable: true
    },
    {
      key: "status",
      text: "Status",
      sortable: true
    },
    {
      key: "salary_date",
      text: "Salary Date",
      className: "salary",
      sortable: true
    },
    {
      key: "action",
      text: "Action",
      cell: (record, index) => {
        return (
          <Fragment>
            <button
              className="btn btn-primary btn-sm"
              onClick={() => {
                setEditRecord(records[index]);
                openModal()
              }}
              style={{ marginRight: '5px' }}>
              <FiEdit />
            </button>
            <button
              className="btn btn-danger btn-sm"
              onClick={() => {
                deleteRecord(records[index].user_id)
              }}
              style={{ marginRight: '5px' }}
            >
              <MdDelete />
            </button>

          </Fragment>
        );
      }
    }
  ];

  return (
    <>
      <div className="col-lg-12">

        {/* Add Employee Modal
          ============================================= */}


        <div className="bg-light shadow-sm rounded p-4 mb-4">

          <div id="add-employee" className="modal fade " role="dialog" aria-hidden="true">
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title font-weight-400">Employee Details</h5>
                  <button type="button" id="add_close" className="close font-weight-400" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                </div>
                <div className="modal-body p-4">
                  <form id="addEmployeeFrom" method="post" onSubmit={addEmployee} >
                    <div className="row">

                      <div className="col-12 ">
                        <div className="form-group">
                          <label for="firstName">Full Name</label>
                          <input type="text" ref={full_name} name="full_name" className="form-control" data-bv-field="firstName" id="firstName" required placeholder="First Name" />
                        </div>
                      </div>
                      <div className="col-12 ">
                        <div className="form-group">
                          <label for="email">Email</label>
                          <input type="email" ref={email} name="email" className="form-control" data-bv-field="email" id="email" required placeholder="Email" />
                        </div>
                      </div>
                      <div className="col-12">
                        <div className="form-group">
                          <label for="phone">Phone</label>
                          <input type="text" ref={phone} name="phone" className="form-control" data-bv-field="phone" id="phone" required placeholder="Phone" />
                        </div>
                      </div>
                      <div className="col-12">
                        <div className="form-group">
                          <label for="salary">Salary</label>
                          <input type="number" ref={salary} name="salary" className="form-control" data-bv-field="salary" id="salary" required placeholder="Salary" />
                        </div>
                      </div>
                      <div className="col-12">
                        <div className="form-group">
                          <label for="salary">Salary date</label>
                          <input type="number" ref={salary_date} name="salary_date" className="form-control" data-bv-field="salary-date" id="salary-date" required placeholder="Month date " max="31" min="1" maxLength="2" />
                        </div>
                      </div>

                    </div>
                    <button className="btn btn-primary btn-block mt-2" type="submit" >Add Employee</button>
                  </form>
                </div>
              </div>
            </div>
          </div>

          <div className="row p-0 m-0">
            <div className=" col-lg-12 col-md-12 col-sm-12 row p-0 m-0">
              <div className="col-lg-3 col-md-5 col-sm-8">
                <h3 className="text-5 font-weight-400 mb-4">Employee<span className="text-muted text-4">(for checking)</span></h3>
              </div>
              <div className="col-lg-3 col-md-4 col-sm-5">
                <a href="#add-employee" data-toggle="modal" className="btn btn-outline-primary btn-sm-block shadow-none text-uppercase mb-4 p-2">Add employee</a>
              </div>
            </div>
          </div>
          <div className="container">
            <div className="row" style={{ marginBottom: "7px", padding: "5px" }}>
              <button className="btn btn-md btn-warning" onClick={() => { dispatchAll() }} style={{ float: 'right', marginRight: '10px' }}>Dispatch All</button>
              <button className="btn btn-md btn-primary" onClick={() => {
                dispatchSalary(checked)
                $(".chkb").prop("checked", false);
                setChecked([]);
              }} style={{ float: 'right' }}>Dispatch Selected</button>
            </div>
            <div className="table-responsive">

              <Table
                columns={columns}
                records={records}
              />


            </div>
            <ModalProvider style={{ zIndex: +1 }}>
              <EditModel />
            </ModalProvider>
          </div>
        </div>


      </div>
    </>
  )
}
