import React, { useState, useEffect } from 'react'
import { updateUserProfile } from "../../../store/actions/user.actions"
import { updateOrgProfile } from "../../../store/actions/org.actions"
import $ from 'jquery'

export default function MiddlePanel(props) {
  const userDetails = props.user;

  const [profileForm, setProfileForm] = useState({
    full_name: userDetails !== undefined ? userDetails.full_name : "",
    email: userDetails !== undefined ? userDetails.email : "",
    phone: userDetails !== undefined ? userDetails.phone : "",
    address: userDetails !== undefined ? userDetails.address : "",
    old_password: "",
    new_password: "",
    new_password_confirm: "",
    passValid: true,
    old_pass: true
  })

  function changeHandler(event) {
    const { name, value } = event.target;
    setProfileForm((prevValue) => {
      return {
        ...prevValue,
        [name]: value
      }
    })
  }
  useEffect(() => {
    setProfileForm((prevValue) => {
      return {
        ...userDetails,
        passValid: true,
        old_pass: true,
        old_password: "",
        new_password: "",
        new_password_confirm: "",
      }
    })
  }, [userDetails])


  async function changePassword() {
    //console.log("pass change function called");
    let oldValid = true;
    let newValid = true;
    if (profileForm.new_password !== profileForm.new_password_confirm || profileForm.new_password == "" || profileForm.new_password_confirm == "") {
      setProfileForm((prevValue) => {
        return {
          ...prevValue,
          passValid: false
        }
      })
      newValid = false;
    } else {
      setProfileForm((prevValue) => {
        return {
          ...prevValue,
          passValid: true
        }
      })
    }

    if (profileForm.old_password == "") {
      setProfileForm((prevValue) => {
        return {
          ...prevValue,
          old_pass: false
        }
      })
      oldValid = false;
      //console.log("true condition");
    } else {
      setProfileForm((prevValue) => {
        return {
          ...prevValue,
          old_pass: true
        }
      })
    }
    //console.log(oldValid);
    //console.log(newValid);
    if (oldValid && newValid) {
      let update_object = {
        old_password: profileForm.old_password,
        new_password: profileForm.new_password
      };
      update_object.id = userDetails.user_id;
      //console.log(update_object);
      let updateResponse = "";
      if ( userDetails.user_preference === "Organization" ) {
        updateResponse = await updateOrgProfile(update_object);
      } else {
        updateResponse = await updateUserProfile(update_object);
      }
      //console.log(updateResponse);
      if (updateResponse.message !== undefined) { alert(updateResponse.message) }
      if (updateResponse.status == 200) { alert("Password updated successfully") }
      $("#pass_close").click();
    }
  }


  async function changeUserProfile() {
    console.log("function called");
    let update_object = { ...profileForm };
    delete update_object.old_password;
    delete update_object.new_password;
    delete update_object.new_password_confirm;
    update_object.id = parseInt(userDetails.user_id);
    console.log(userDetails);
    let updateResponse = "";
    if (userDetails.user_preference === "Organization") {
      delete update_object.profile_img;
      updateResponse = await updateOrgProfile(update_object);
    } else {
      updateResponse = await updateUserProfile(update_object);
    }
    let user = updateResponse.data;
    props.updateUser((prevValue) => {
      return {
        balance: prevValue.balance,
        ...user
      }
    })

    setProfileForm({
      ...user
    })
    $("#email_close").click();
    $("#name_close").click();
    $("#phone_close").click();
    console.log(updateResponse);
  }


  return (
    <div className="col-lg-9">

      {/* <!-- Personal Details
          ============================================= --> */}
      <div className="bg-light shadow-sm rounded p-4 mb-4">
        <h3 className="text-5 font-weight-400 mb-3">Personal Details <a href="#edit-personal-details" data-toggle="modal" className="float-right text-1 text-uppercase text-muted btn-link"><i className="fas fa-edit mr-1"></i>Edit</a></h3>
        <div className="row">
          <p className="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">Name</p>
          <p className="col-sm-9">{userDetails.full_name}</p>
        </div>

        <div className="row">
          <p className="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">Address</p>
          <p className="col-sm-9">{userDetails.address}</p>
        </div>
      </div>
      {/* <!-- Edit Details Modal
          ================================== --> */}
      <div id="edit-personal-details" className="modal fade " role="dialog" aria-hidden="true">
        <div className="modal-dialog modal-dialog-centered" role="document">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title font-weight-400">Personal Details</h5>
              <button type="button" id="name_close" className="close font-weight-400" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
            </div>
            <div className="modal-body p-4">
              <form id="personaldetails" >
                <div className="row">
                  <div className="col-12 ">
                    <div className="form-group">
                      <label for="firstName">Full Name</label>
                      <input type="text" value={profileForm.full_name} name="full_name" onChange={changeHandler} className="form-control" data-bv-field="firstName" id="firstName" required placeholder="First Name" />
                    </div>
                  </div>


                  <div className="col-12">
                    <h3 className="text-5 font-weight-400 mt-3">Address</h3>
                    <hr />
                  </div>
                  <div className="col-12">
                    <div className="form-group">
                      <label for="address">Address</label>
                      <input type="text" value={profileForm.address} name="address" onChange={changeHandler} className="form-control" data-bv-field="address" id="address" required placeholder="Address 1" />
                    </div>
                  </div>



                </div>
                <button className="btn btn-primary btn-block mt-2" type="button" onClick={changeUserProfile}>Save Changes</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Personal Details End -->
          
          
          <!-- Email Addresses
          ============================================= --> */}
      <div className="bg-light shadow-sm rounded p-4 mb-4">
        <h3 className="text-5 font-weight-400 mb-3">Email Addresses <a href="#edit-email" data-toggle="modal" className="float-right text-1 text-uppercase text-muted btn-link"><i className="fas fa-edit mr-1"></i>Edit</a></h3>
        <div className="row">
          <p className="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">Email ID <span className="text-muted font-weight-500">(Primary)</span></p>
          <p className="col-sm-9">{userDetails.email}</p>
        </div>
      </div>
      {/* <!-- Edit Details Modal
          ================================== --> */}
      <div id="edit-email" className="modal fade " role="dialog" aria-hidden="true">
        <div className="modal-dialog modal-dialog-centered" role="document">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title font-weight-400">Email Addresses</h5>
              <button type="button" id="email_close" className="close font-weight-400" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
            </div>
            <div className="modal-body p-4">
              <form id="emailAddresses" >
                <div className="row">
                  <div className="col-12">
                    <div className="form-group">
                      <label for="emailID">Email ID <span className="text-muted font-weight-500">(Primary)</span></label>
                      <input type="email" value={profileForm.email} name="email" onChange={changeHandler} className="form-control" data-bv-field="emailid" id="emailID" required placeholder="Email ID" />
                    </div>
                  </div>
                </div>
                <button className="btn btn-primary btn-block" type="button" onClick={changeUserProfile}>Save Changes</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Email Addresses End -->
          
          <!-- Phone
          ============================================= --> */}
      <div className="bg-light shadow-sm rounded p-4 mb-4">
        <h3 className="text-5 font-weight-400 mb-3">Phone <a href="#edit-phone" data-toggle="modal" className="float-right text-1 text-uppercase text-muted btn-link"><i className="fas fa-edit mr-1"></i>Edit</a></h3>
        <div className="row">
          <p className="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">Mobile <span className="text-muted font-weight-500">(Primary)</span></p>
          <p className="col-sm-9">{userDetails.phone}</p>
        </div>
      </div>
      {/* <!-- Edit Details Modal
          ================================== --> */}
      <div id="edit-phone" className="modal fade " role="dialog" aria-hidden="true">
        <div className="modal-dialog modal-dialog-centered" role="document">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title font-weight-400">Phone</h5>
              <button type="button" id="phone_close" className="close font-weight-400" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
            </div>
            <div className="modal-body p-4">
              <form id="phone" >
                <div className="row">
                  <div className="col-12">
                    <div className="form-group">
                      <label for="mobileNumber">Mobile <span className="text-muted font-weight-500">(Primary)</span></label>
                      <input type="number" value={profileForm.phone} onChange={changeHandler} name="phone" className="form-control" data-bv-field="mobilenumber" id="mobileNumber" required placeholder="Mobile Number" />
                    </div>
                  </div>
                </div>
                <button className="btn btn-primary btn-block" type="button" onClick={changeUserProfile}>Save Changes</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Phone End -->
          
          <!-- Security
          ============================================= --> */}
      <div className="bg-light shadow-sm rounded p-4">
        <h3 className="text-5 font-weight-400 mb-3">Security <a href="#change-password" data-toggle="modal" className="float-right text-1 text-uppercase text-muted btn-link"><i className="fas fa-edit mr-1"></i>Edit</a></h3>
        <div className="row">
          <p className="col-sm-3 text-muted text-sm-right mb-0 mb-sm-3">
            <label className="col-form-label">Password</label>
          </p>
          <p className="col-sm-9">
            <input type="password" className="form-control-plaintext" data-bv-field="password" id="password" value="EnterPassword" />
          </p>
        </div>
      </div>
      {/* <!-- Edit Details Modal
          ================================== --> */}
      <div id="change-password" className="modal fade " role="dialog" aria-hidden="true">
        <div className="modal-dialog modal-dialog-centered" role="document">
          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title font-weight-400">Change Password</h5>
              <button type="button" id="pass_close" className="close font-weight-400" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
            </div>
            <div className="modal-body p-4">
              <form id="changePassword">
                <div className="form-group">
                  <label for="existingPassword">Confirm Current Password</label>
                  <input type="text" name="old_password" value={profileForm.old_password} onChange={changeHandler} className="form-control" data-bv-field="existingpassword" id="existingPassword" required placeholder="Enter Current Password" />
                  {!profileForm.old_pass && <p className="text-danger">Old password is required</p>}
                </div>
                <div className="form-group">
                  <label for="newPassword">New Password</label>
                  <input type="text" name="new_password" value={profileForm.new_password} onChange={changeHandler} className="form-control" data-bv-field="newpassword" id="newPassword" required placeholder="Enter New Password" />
                </div>
                <div className="form-group">
                  <label for="confirmPassword">Confirm New Password</label>
                  <input type="text" name="new_password_confirm" value={profileForm.new_password_confirm} onChange={changeHandler} className="form-control" data-bv-field="confirmgpassword" id="confirmPassword" required placeholder="Enter Confirm New Password" />
                  {!profileForm.passValid && <p className="text-danger">Both Passwords do not match</p>}
                </div>
                <button className="btn btn-primary btn-block mt-4" type="button" onClick={changePassword}>Update Password</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      {/* <!-- Security End --> */}

    </div>
  )
}
