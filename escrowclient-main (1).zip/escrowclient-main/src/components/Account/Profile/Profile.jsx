import React, { useEffect, useState } from 'react'
import PreLoader from '../../mini_features/PreLoader.jsx'
import NavBar from '../../menu/NavBarWhite.jsx'
import SecondaryMenu from '../../SecondaryMenu'
import LeftPanel from '../LeftPanel'
import MiddlePanel from './MiddlePanel'
import Footer from '../../common/Footer' 
import $ from 'jquery'
import { getUserProfile } from "../../../store/actions/user.actions"
import { getOrgProfile } from "../../../store/actions/org.actions"
import { isAuthenticUser } from '../../../utils/validateUser';

export default function Profile() {
    let loggedInUser = JSON.parse(localStorage.getItem('user'));
    const [userDetails, setUserDetails] = useState({
        full_name: "",
        username: "",
        email: "",
        phone: "",
        address: "",
        profile_img: "",
        user_preference: ""
    });
    useEffect(() => {
        $('[data-loader="circle-side"]').fadeOut()
        $('#preloader').delay(333).fadeOut('slow')
        $('body').delay(333)
    })
    useEffect( () => {
        async function fetchData(){
            if (isAuthenticUser()) {
              let response = "";
              if(loggedInUser.user_preference === "Organization"){
                response = await getOrgProfile(loggedInUser.user_id)
                response.user.user_id = loggedInUser.user_id;
              }else{
                response = await getUserProfile(loggedInUser.user_id);
                response.user.user_id = loggedInUser.user_id;
              }
            //   console.log("Profile Log: " , response);
              setUserDetails(response.user);
            }
          }
          
          fetchData();
    }, [])

    return (
        <>
            <PreLoader />
            <NavBar />
            <SecondaryMenu />
            <div class="container">
                <div class="row">
                    <LeftPanel
                     />
                    <MiddlePanel
                        user={userDetails}
                        updateUser={setUserDetails} />
                </div>
            </div>

            <Footer />
        </>
    )


}
