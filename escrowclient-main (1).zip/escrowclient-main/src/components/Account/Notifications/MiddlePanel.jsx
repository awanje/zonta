import React from 'react'

export default function MiddlePanel() {
    return (
        <div class="col-lg-9">
          
          {/* Notifications
          ============================================= */}
          <div class="bg-light shadow-sm rounded p-4 mb-4">
            <h3 class="text-5 font-weight-400">Notifications</h3>
            <p class="text-muted">Select subscriptions to be delivered to <span class="text-body">smithrhodes1982@gmail.com</span></p>
            <hr class="mx-n4" />
            <form id="notifications" method="post">
              <div class="form-check custom-control custom-checkbox">
                <input id="announcements" name="notifications" class="custom-control-input" type="checkbox" />
                <label class="custom-control-label text-3" for="announcements">Announcements</label>
                <p class="text-muted line-height-3 mt-2">Be the first to know about new features and other news.</p>
              </div>
              <hr class="mx-n4" />
              <div class="form-check custom-control custom-checkbox">
                <input id="sendPayment" name="notifications" class="custom-control-input" type="checkbox" />
                <label class="custom-control-label text-3" for="sendPayment">Send payment</label>
                <p class="text-muted line-height-3 mt-2">Send an email when I send a payment.</p>
              </div>
              <hr class="mx-n4" />
              <div class="form-check custom-control custom-checkbox">
                <input id="receiveApayment" name="notifications" class="custom-control-input" type="checkbox" />
                <label class="custom-control-label text-3" for="receiveApayment">Receive a payment</label>
                <p class="text-muted line-height-3 mt-2">Send me an email when I receive a payment.</p>
              </div>
              <hr class="mx-n4" />
              <div class="form-check custom-control custom-checkbox">
                <input id="requestPayment" name="notifications" class="custom-control-input" type="checkbox" />
                <label class="custom-control-label text-3" for="requestPayment">Request payment</label>
                <p class="text-muted line-height-3 mt-2">Send me an email when i request payment.</p>
              </div>
              <hr class="mx-n4" />
              <div class="form-check custom-control custom-checkbox">
                <input id="problemWithPayment" name="notifications" class="custom-control-input" type="checkbox" />
                <label class="custom-control-label text-3" for="problemWithPayment">Have a problem with a payment</label>
                <p class="text-muted line-height-3 mt-2">Send me an email when have a problem with a payment.</p>
              </div>
              <hr class="mx-n4" />
              <div class="form-check custom-control custom-checkbox">
                <input id="specialOffers" name="notifications" class="custom-control-input" type="checkbox" />
                <label class="custom-control-label text-3" for="specialOffers">Special Offers</label>
                <p class="text-muted line-height-3 mt-2">Receive last-minute offers from us.</p>
              </div>
              <hr class="mx-n4" />
              <div class="form-check custom-control custom-checkbox">
                <input id="reviewSurveys" name="notifications" class="custom-control-input" type="checkbox" />
                <label class="custom-control-label text-3" for="reviewSurveys">Review Surveys</label>
                <p class="text-muted line-height-3 mt-2">Share your payment experience to better inform users.</p>
              </div>
              <hr class="mx-n4" />
              <button class="btn btn-primary mt-1" type="submit">Save Changes</button>
            </form>
          </div>
          {/* Notifications End */} 
          
        </div>
    )
}
