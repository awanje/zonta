import React from 'react'
import { useHistory, useLocation, Redirect } from 'react-router-dom'
export default function MainContent() {
  const locationData = useLocation().data;
  const history = useHistory();
  let locNotSet = false;
  // if (typeof locationData !== 'undefined') {
  //   console.log(locationData);
  //   locNotSet = false;
  // }
  function sendAgain() {
    history.push({ pathname: '/sendmoney' })
  }

  if (locNotSet) {
    return (
      <Redirect to="/requestmoney" />
    )
  } else {
    return (
      <div className="py-4">
        <div className="container">
          <h2 className="font-weight-400 text-center mt-3 mb-4">Dispute Alert</h2>
          <div className="row">
            <div className="col-md-8 col-lg-6 col-xl-5 mx-auto">
              {/*} Send Money Success
          ============================================= */}
              <div className="bg-light shadow-sm rounded p-3 p-sm-4 mb-4">
                <div className="text-center my-5">
                  <p className="text-center text-warning text-20 line-height-07"><i className="fas fa-exclamation-triangle"></i></p>
                  <p className="text-center text-danger text-8 line-height-07">Dispute!</p>
                  <p className="text-center text-4">A Dispute has been filed against you for the deal #ZPX1357</p>
                </div>
                <hr />
                <h3 className="text-center ">Buyer Proposal</h3>
                <div id="buyer-proposal row">
                  <div class="transaction-title py-2 px-4">
                    <div class="row">
                      <div class="col-2 col-sm-1 text-center"><span class="">Date</span></div>
                      <div class="col col-sm-7">Description</div>
                      <div class="col-auto col-sm-2 d-none d-sm-block text-center">Status</div>
                      <div class="col-3 col-sm-2 text-right">Amount</div>
                    </div>
                  </div>
                  <div className="row transaction-item px-4 py-3">
                    <div class="row align-items-center flex-row">
                      <div class="col-2 col-sm-1 text-center"> <span class="d-block text-4 font-weight-300">16</span> <span class="d-block text-1 font-weight-300 text-uppercase">APR</span> </div>
                      <div class="col col-sm-7"> <span class="d-block text-4">Fraud</span> <span class="text-muted">Withdraw to Bank account</span> </div>
                      <div class="col-auto col-sm-2 d-none d-sm-block text-center text-3"> <span class="text-warning" data-toggle="tooltip" data-original-title="In Progress"><i class="fas fa-clock-o"></i></span> </div>
                      <div class="col-3 col-sm-2 text-right text-4"> <span class="text-nowrap">-562</span> <span class="text-2 text-uppercase">(PKR)</span> </div>
                    </div>
                  </div>
                </div>
                <button onClick={sendAgain} type="button" className="btn btn-primary btn-block">Accept Proposal</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }

}
