import React from 'react'

export default function FeeCard(props) {
    return (
        <div class="col-md-6 mb-5">
            <div class="bg-white shadow-sm rounded p-4 text-center">
                <div class="featured-box style-4 py-2">
                    <div class="featured-box-icon text-light border rounded-circle shadow-none"> <i class={`fas ${props.icon}`}></i> </div>
                    <h3 class="text-body text-7 mb-3">{props.title}</h3>
                    <p class="text-4 line-height-4">{props.description}</p>
                    <div class="text-primary text-10 pt-3 pb-4 mb-2">{props.charges}</div>
                    <a href="#" class="text-muted btn-link text-4">Learn more<i class="fas fa-chevron-right text-2 ml-2"></i></a> </div>
            </div>
        </div>
    )
}
