import React from 'react'
import FeeCard from './FeeCard'
export default function FeeDetails() {
    return (
        <section className="section pt-5 pb-0">
      <div className="container">
        <div className="row">
        
            <FeeCard 
              title="Withdrawal Funds"
              description="You can easily withdraw funds to your local bank account in local currency at excellent rates."
              charges="up to 1.5%"
              icon="fa-download"
            />
            <FeeCard 
              title="Deposit Funds"
              description="With a wide variety of options for deposit your account. There is always an option that is right for you."
              charges="up to 1.0%"
              icon="fa-upload"
            />
            <FeeCard 
              title="Receive Money"
              description="Receiving money is always free of charge"
              charges="Free"
              icon="fa-hand-holding-usd"
            />
            <FeeCard 
              title="Send Money"
              description="You can easily make payments at excellent rates."
              charges="up to 1.0%"
              icon="fa-file-invoice-dollar"
            />
          
        </div>
      </div>
    </section>
    )
}
