import React from 'react'

export default function HeroSection() {
    return (
        <section class="hero-wrap section">
    <div class="hero-bg hero-bg-scroll" style={{backgroundImage:"url('./images/bg/image-3.jpg')"}}></div>
    <div class="hero-content">
      <div class="container">
        <div class="row">
          <div class="col-12 col-lg-7 col-xl-6 text-center text-lg-left">
            <h1 class="text-11 text-white mb-4">We Promise Low Fees<br />
              and No Extra Charges</h1>
            <p class="text-5 text-white line-height-4 mb-4">Signing up to a Payyed account is FREE of charge.
              Create your account today and start!</p>
            <a href="/#" class="btn btn-primary my-2 mr-2">Open a Free Account</a> <a class="btn btn-link text-light video-btn my-2" href="/#" data-src="https://www.youtube.com/embed/7e90gBu4pas" data-toggle="modal" data-target="#videoModal"><span class="mr-2"><i class="fas fa-play-circle"></i></span>See How it Works</a> </div>
        </div>
      </div>
    </div>
  </section>
    )
}
