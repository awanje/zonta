import React from 'react'

function PreLoader() {
    return (
        <div id="preloader">
          <div data-loader="dual-ring"></div>
        </div>
    )
}

export default PreLoader;