import React from 'react'
import NavBarLinks from './NavBarLinks'
import { Link , useHistory} from "react-router-dom"
import MyAccountDrop from './MyAccountDrop'
import { isAuthenticUser } from '../../utils/validateUser';
import jsCookie from 'js-cookie';
export default function NavBar2() {
    const history = useHistory();
    function logout (e) {
        e.preventDefault();
        jsCookie.remove('login');
        jsCookie.remove('access');
        sessionStorage.clear();
        localStorage.clear();
        history.push('/login');
    }
    return (
        <header id="header">
            <div className="container">
                <div className="header-row">
                    <div className="header-column justify-content-start">

                        <div className="logo"> <Link className="d-flex" to="/" title="Payyed - HTML Template"><img src="images/logo.png" alt="Payyed" /></Link> </div>

                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#header-nav"> <span></span> <span></span> <span></span> </button>

                        <nav className="primary-menu navbar navbar-expand-lg">
                            <div id="header-nav" className="collapse navbar-collapse">
                                <NavBarLinks />
                            </div>
                        </nav>

                    </div>
                    <div className="header-column justify-content-end">

                        {isAuthenticUser() && <nav className="login-signup navbar navbar-expand">
                            <ul className="navbar-nav">
                                <MyAccountDrop />
                                <li className="align-items-center h-auto ml-sm-3"><Link className="btn btn-outline-primary shadow-none d-none d-sm-block" onClick={logout} >Sign out</Link></li>
                            </ul>
                        </nav>}

                        {!isAuthenticUser() && <nav className="login-signup navbar navbar-expand">
                            <ul className="navbar-nav">
                                <li><Link to="/login">Login</Link> </li>
                                <li className="align-items-center h-auto ml-sm-3"><Link className="btn btn-primary d-none d-sm-block" to="/signup">Sign Up</Link></li>
                            </ul>
                        </nav>}

                    </div>
                </div>
            </div>
        </header>
    )
}
