import React from 'react'
import DropDown from './DropDown.jsx'
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link,
    useRouteMatch,
    useParams
} from "react-router-dom";
export default function NavBar2() {
    return (
        <header id="header">
            <div className="container">
                <div className="header-row">
                    <div className="header-column justify-content-start">

                        <div className="logo"> <a className="d-flex" href="index.html" title="Payyed - HTML Template"><img src="images/logo.png" alt="Payyed" /></a> </div>

                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#header-nav"> <span></span> <span></span> <span></span> </button>

                        <nav className="primary-menu navbar navbar-expand-lg">
                            <div id="header-nav" className="collapse navbar-collapse">
                                <ul className="navbar-nav mr-auto">
                                    <li><Link to="/">Home</Link></li>
                                    <li><a href="transactions.html">Transactions</a></li>
                                    <li className="active"><a href="send-money.html">Send/Request</a></li>
                                    <li><a href="help.html">Help</a></li>
                                    <li><Link to="/send">Send</Link></li>
                                    <DropDown
                                        text="Features"
                                        items={[
                                            { itemName: "Header", itemLink: "header.html" },
                                            { itemName: "Footer", itemLink: "footer.html" },
                                            { itemName: "Layout", itemLink: "layout.html" }
                                        ]}
                                    />
                                    <DropDown
                                        text="Pages"
                                        items={[
                                            { itemName: "Page1", itemLink: "header.html" },
                                            { itemName: "Page2", itemLink: "footer.html" },
                                            { itemName: "Page3", itemLink: "layout.html" }
                                        ]}
                                    />
                                </ul>
                            </div>
                        </nav>

                    </div>
                    <div className="header-column justify-content-end">

                        <nav className="login-signup navbar navbar-expand">
                            <ul className="navbar-nav">
                                <li><a href="profile.html">Settings</a> </li>
                                <li className="align-items-center h-auto ml-sm-3"><a className="btn btn-outline-primary shadow-none d-none d-sm-block" href="">Sign out</a></li>
                            </ul>
                        </nav>

                    </div>
                </div>
            </div>
        </header>
    )
}
