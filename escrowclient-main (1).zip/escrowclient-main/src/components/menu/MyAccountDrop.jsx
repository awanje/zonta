import React from 'react'
import DropDown from './DropDown.jsx'

export default function MyAccountDrop() {
    //console.log(JSON.parse(localStorage.getItem('user')));
    let user = JSON.parse(localStorage.getItem('user')).full_name.split(' ')[0];
    return (
        <>
            <DropDown
                text={user}
                items={[
                    { itemName: "My Profile", itemLink: "/profile" },
                    { itemName: "Cards & Bank Accounts", itemLink: "/bankCards" },
                    { itemName: "Notifications", itemLink: "/notifications" },
                    { itemName: "Dashboard", itemLink: "/dashboard" },
                    { itemName: "My Deals", itemLink: "/mydeals" },
                    { itemName: "Transactions", itemLink: "/transactions" },
                    { itemName: "Deposit Money", itemLink: "/deposit" },
                    { itemName: "Withdraw Money", itemLink: "/withdraw" },
                    { itemName: "Virtual Listings", itemLink: "/virtualListings" },
                ]}
            />

            
        </>
    )
}
