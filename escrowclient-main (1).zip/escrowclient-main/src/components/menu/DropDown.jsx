import React from 'react';
import uuid from 'react-uuid';
function DropDown(props) {
    const [featureClass, setFeatureClass] = React.useState("dropdown-menu");

    function handleFeatureHover() {
        setFeatureClass((prevValue) => {
            return prevValue === "dropdown-menu" ? "dropdown-menu show" : "dropdown-menu";
        });
    }

    function renderListItem(item) {
        return (
            <li key={uuid()}><a className="dropdown-item" href={item.itemLink}>{item.itemName}</a></li>
        )
    }
    return (
        <li key={uuid()} className="dropdown"> <a className="dropdown-toggle" onMouseEnter={handleFeatureHover} onMouseLeave={handleFeatureHover} href="/#">{props.text}</a>
            <ul className={featureClass} onMouseEnter={handleFeatureHover} onMouseLeave={handleFeatureHover}>
                {props.items.map(item => renderListItem(item))}
            </ul>
        </li>
    )
}
export default DropDown;