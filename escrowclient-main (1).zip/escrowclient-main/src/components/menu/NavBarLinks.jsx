import React from 'react'
import DropDown from './DropDown.jsx'
import {Link} from "react-router-dom";

export default function NavBarLinks() {
    return (
        <ul className="navbar-nav mr-auto">
            <li><Link to="/send">Buyer</Link></li>
            <li><Link to="/recieve">Seller</Link></li>
            <li><Link to="/about">About Us</Link></li>
            <li><Link to="/fees">Fees</Link></li>
            <li><Link to="/help">Help</Link></li>
            <li><Link to="/contact">Contact Us</Link></li>
            <DropDown
                text="Pages"
                items={[
                    { itemName: "SignUp Org", itemLink: "/signuporg" },
                    { itemName: "Deal Page", itemLink: "/dealpage" },
                    { itemName: "Open Dispute", itemLink: "/opendispute" },
                    { itemName: "Seller Dispute", itemLink: "/sellerdispute" },
                    { itemName: "View Listings", itemLink: "/viewListings" },
                    { itemName: "Listing Details", itemLink: "/listingDetail" }
                ]}
            />
            
             </ul>

    )
}
