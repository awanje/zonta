import React from 'react'

export default function MobileApp() {
    return (
        <section className="section pt-5 pb-0">
            <div className="container">
                <div className="row">
                    <div className="col-md-12 col-lg-9 col-xl-8 mx-auto">
                        <div className="row">
                            <div className="col-sm-5 col-md-5 text-center align-bottom order-1 order-sm-0"> <img className="img-fluid" alt="" src="images/app-mobile.png" /> </div>
                            <div className="col-sm-7 col-md-7 my-auto order-0 order-sm-1 text-center text-sm-left">
                                <h2 className="text-8 font-weight-400 text-uppercase mb-3">Get the app</h2>
                                <p className="text-4">Download our app for the fastest, most convenient way to send & get Payment.</p>
                                <div className="pt-2 mb-4 mb-sm-0"> <a className="mr-3" href="/#"><img className="img-fluid" alt="" src="images/app-store.png" /></a><a href="/#"><img className="img-fluid" alt="" src="images/google-play-store.png" /></a> </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}
