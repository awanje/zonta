import React from 'react'

export default function CustomersSayVideo() {
    return (
        <section className="hero-wrap section shadow-md">
            <div className="hero-mask opacity-3 bg-dark"></div>
            <div className="hero-bg hero-bg-scrll" style={{backgroundImage:"url('images/bg/image-4.jpg')"}}></div>
            <div className="hero-content py-0 py-lg-5 my-0 my-lg-5">
                <div className="container text-center">
                    <h2 className="text-9 text-white font-weight-400 text-uppercase mb-5">What our customers say</h2>
                    <a className="video-btn d-flex" href="#" data-src="https://www.youtube.com/embed/7e90gBu4pas" data-toggle="modal" data-target="#videoModal"> <span className="btn-video-play bg-white shadow-md rounded-circle m-auto"><i className="fas fa-play"></i></span> </a> </div>
            </div>
        </section>
    )
}
