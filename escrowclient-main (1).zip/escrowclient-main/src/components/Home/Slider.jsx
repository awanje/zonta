import React from 'react'
import SendRequestForm from './SendRequestForm'
import Animation from './Animation'
export default function Slider() {
    return (
        <section className="hero-wrap section shadow-md pb-4">
      <div className="hero-mask opacity-7 bg-dark"></div>
      <div className="hero-bg" style={{backgroundImage:"url('images/bg/image-5.jpg')"}}></div>
      <div className="hero-content py-5">
      <div className="container">
        <div className="row"  >
          
          
          <Animation />
          <SendRequestForm />
        
          
        </div>
        </div>
      </div>
      
    </section>
    )
}
