/* eslint-disable */
import React, { useState, useEffect } from 'react'
import { GoMail } from "react-icons/go"
import { Redirect } from "react-router-dom";

export default function SendRequestForm() {

    //const history = useHistory();
    const [error, setError] = useState({
        seller: false,
        buyer: false
    })
    const [redirect, setRedirect] = useState({
        redirect: false,
        path: '',
        props: {},
        from: ""
    })

    const [sendForm, setSendForm] = useState({
        buyerMail: "",
        sellerMail: "",
        youAre: "Buyer",
        render: false
    })

    function handleSendChange(event) {
        const { name, value } = event.target;
        setSendForm(prevValue => {

            return {
                ...prevValue,
                [name]: value
            }

        })
    }


    function handleFormSubmit(event) {
        console.log("triggered");
        event.preventDefault();
        var mailFormat = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})|([0-9]{10})+$/;

        if (!mailFormat.test(sendForm.buyerMail)) {
            setError(prevValue => {
                return {
                    ...prevValue,
                    buyer: true
                }

            })
        }else{
            setError(prevValue => {
                return {
                    ...prevValue,
                    buyer: false
                }

            })
        }

        if (!mailFormat.test(sendForm.sellerMail)) {
            setError(prevValue => {
                return {
                    ...prevValue,
                    seller: true
                }

            })
        }else{
            setError(prevValue => {
                return {
                    ...prevValue,
                    seller: false
                }

            })
        }
        if (mailFormat.test(sendForm.buyerMail) && mailFormat.test(sendForm.sellerMail)) {
            let path = ""
            console.log("found alright");
            if(sendForm.youAre === "Buyer"){path = "/sendmoney"}
            if(sendForm.youAre === "Seller"){path = "/requestmoney"}
            // if(sendForm.youAre === "Broaker"){path = "/broakerDeal"}
            console.log(path);
            setRedirect({
                redirect: true,
                path: path,
                props: { ...sendForm, from: "home" }
            })

        }

    }

    useEffect(() => {

    }, [sendForm.render])
    return (
        <>
            {redirect.redirect ? <Redirect
                strict
                sensitive
                from="/home"
                to={{
                    pathname: redirect.path,
                    state: redirect.props
                }
                } /> : ""
            }
            <div className="col-lg-6 col-xl-5 " style={{ display: "inline" }}>
                <ul className="nav nav-tabs nav-justified bg-white style-5 rounded-top" id="myTab" role="tablist">
                    <li className="nav-item"> <a className="nav-link active" id="send-money-tab" data-toggle="tab" href="#send-money" role="tab" aria-controls="send-money" aria-selected="true">Initiate Deal</a> </li>
                    <hr />
                </ul>

                <div className="tab-content p-4 bg-white rounded-bottom" id="myTabContent">

                    <div className="tab-pane fade show active" id="send-money" role="tabpanel" aria-labelledby="send-money-tab">
                        <form id="form-send-money" >
                            <div className="form-group">
                                <label htmlFor="youSend">Seller Email or phone</label>
                                <div className="input-group">
                                    <div className="input-group-prepend"> <span className="input-group-text"><GoMail /></span> </div>
                                    <input type="text" className="form-control" placeholder="Seller Email or phone" name="sellerMail" onChange={handleSendChange} value={sendForm.sellerMail} />

                                </div>
                                {error.seller ? <p className="text-danger">Invalid email or phone</p> : null}
                            </div>

                            <div className="form-group">
                                <label htmlFor="youSend">Buyer Email or phone</label>
                                <div className="input-group">
                                    <div className="input-group-prepend"> <span className="input-group-text"><GoMail /></span> </div>
                                    <input type="text" className="form-control" placeholder="Buyer Email or phone" name="buyerMail" onChange={handleSendChange} value={sendForm.buyerMail} />

                                </div>
                                {error.buyer ? <p className="text-danger">Invalid email or phone</p> : null}
                            </div>
                            <div className="form-group mb-4">
                                <label htmlFor="youSend">You Are a?</label>
                                <select required className="form-control" onChange={handleSendChange} name="youAre" >
                                <option>Buyer</option>
                                <option>Seller</option>
                                {/* <option>Broaker</option> */}
                                </select>
                            </div>
                            <button name="send" className="btn btn-primary btn-block" onClick={handleFormSubmit}>Continue</button>
                        </form>
                    </div>

                </div>
            </div>
        </>
    )
}
