
import React, { useState, useEffect } from 'react'
import { AnimateOnChange } from "react-animation";

const text = [
  <div id="slider-content-div1"><h2 className="text-14 font-weight-400 text-white mb-4 bg-text" >The Secure,<br className="d-none d-xl-block" />
  easiest and fastest <br className="d-none d-xl-block" />
  way to transfer money.</h2>
       <p className="text-4 text-white mb-4">Send & Receive money to your loved ones in minutes with great rates and low
  fees. Over 180 countries and 30 currencies supported.</p>
       <a href="/#" className="btn-link text-4">See more details<i className="fas fa-chevron-right text-2 ml-2"></i></a></div>
       ,
       <div id="slider-content-div1"><h2 className="text-14 font-weight-400 text-white mb-4 bg-text" >The Second,<br className="d-none d-xl-block" />
   easiest and fastest <br className="d-none d-xl-block" />
   way to transfer money.</h2>
        <p className="text-4 text-white mb-4">Send & Receive money to your loved ones in minutes with great rates and low
   fees. Over 180 countries and 30 currencies supported.</p>
        <a href="/#" className="btn-link text-4">See more details<i className="fas fa-chevron-right text-2 ml-2"></i></a></div>
        ,
        <div id="slider-content-div1"><h2 className="text-14 font-weight-400 text-white mb-4 bg-text" >The Third,<br className="d-none d-xl-block" />
   easiest and fastest <br className="d-none d-xl-block" />
   way to transfer money.</h2>
        <p className="text-4 text-white mb-4">Send & Receive money to your loved ones in minutes with great rates and low
   fees. Over 180 countries and 30 currencies supported.</p>
        <a href="/#" className="btn-link text-4">See more details<i className="fas fa-chevron-right text-2 ml-2"></i></a></div>
]

export default function Animation() {
  const [wordIndex, setWord] = useState(0);
  

  useEffect(() => {
    const interval = setInterval(() => {
      setWord((prevValue) => (prevValue === 2 ? 0 : prevValue + 1));
    }, 4000);
    return () => clearInterval(interval);
  }, []);
  return (
    <div className="col-lg-6 col-xl-7  text-center text-lg-left pb-4 pb-lg-0 cnt" id="content-container" >
      <AnimateOnChange durationOut="1000">{text[wordIndex]}</AnimateOnChange>
    </div>
  )

}



