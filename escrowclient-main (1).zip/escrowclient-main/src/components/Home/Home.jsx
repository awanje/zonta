import React ,{useEffect} from 'react'
import PreLoader from '../mini_features/PreLoader.jsx'
import NavBar from '../menu/NavBar.jsx'
import Slider from './Slider.jsx' 
import WhyChooseUs from './WhyChooseUs'
import HowItWorks from './HowItWorks'
import WhatCanYouDo from './WhatCanYouDo'
import CustomersSayVideo from './CustomersSayVideo'
import { ToastContainer, toast } from 'react-toastify';
import MobileApp from './MobileApp'
import Footer from '../common/Footer'
import $ from 'jquery'
import 'react-toastify/dist/ReactToastify.css';
function Home() {
  useEffect(() => {
    $('[data-loader="circle-side"]').fadeOut() 
          $('#preloader').delay(333).fadeOut('slow')
          $('body').delay(333) 
          
  })
  useEffect(()=>{toast.success("Wow so easy!");},[])
  return (
    <div>
      <PreLoader />
      <div id="main-wrapper">
      <NavBar />
      <div id="content">
      <Slider />
      <WhyChooseUs />
      <HowItWorks />
      <WhatCanYouDo />
      <CustomersSayVideo />
      <MobileApp />
      </div>
      <ToastContainer
                position="top-right"
                autoClose={5000}
                hideProgressBar={false}
                newestOnTop={false}
                closeOnClick
                rtl={false}
                pauseOnFocusLoss
                draggable
                pauseOnHover
            />
      <Footer />
      </div>
    </div>
  )
}

export default Home;
