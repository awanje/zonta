import React from 'react'

export default function HeroSection() {
    return (
        <section className="page-header page-header-text-light bg-dark-3 py-5">
  <div className="container">
    <div className="row text-center">
      <div className="col-12">
        <ul className="breadcrumb mb-0">
          <li><a href="index.html">Home</a></li>
          <li className="active">Contact Us</li>
        </ul>
      </div>
      <div className="col-12">
        <h1>Contact Us</h1>
      </div>
    </div>
  </div>
</section>
    )
}
