import React from 'react'

export default function CustomerSupportBanner() {
    return (
        <section className="hero-wrap section shadow-md">
      <div className="hero-mask opacity-9 bg-primary"></div>
      <div className="hero-bg" style={{backgroundImage:"url('images/bg/image-2.jpg')"}}></div>
      <div className="hero-content">
        <div className="container text-center">
          <h2 className="text-9 text-white">Awesome Customer Support</h2>
          <p className="text-4 text-white mb-4">Have you any query? Don't worry. We have great people ready to help you whenever you need it.</p>
          <a href="#" className="btn btn-light">Find out more</a> </div>
      </div>
    </section>
    )
}
