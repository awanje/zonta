import React,{useEffect} from 'react'
import Routes from './Routes'
import { ToastContainer, toast } from 'react-toastify';
import {
    BrowserRouter as Router,

} from "react-router-dom";

export default function App() {
    
    return (
        <Router>

            <Routes />
            
        </Router>

    )
}
