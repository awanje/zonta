import React , {useEffect} from 'react'
import PreLoader from '../mini_features/PreLoader.jsx'
import NavBar from '../menu/NavBarWhite.jsx'
import Hero from './HeroSection'
import RecieveSteps from './RecieveSteps'
import WhyChooseUs from '../common/WhyChooseUs'
import Faq from '../Send/Faq.jsx'
import SignupOffer from '../common/SignupOffer.jsx'
import Footer from '../common/Footer'
import SendMoneyTestimonial from '../common/Testimonial'
import $ from 'jquery'

export default function Recieve() {
    useEffect(() => {
        $('[data-loader="circle-side"]').fadeOut() 
              $('#preloader').delay(333).fadeOut('slow')
              $('body').delay(333) 
      })
    return (
        <>
            <PreLoader />
            <NavBar />
            <Hero />
            <RecieveSteps />
            <WhyChooseUs />
            <SendMoneyTestimonial />
            <Faq />
            <SignupOffer />
            <Footer />
        </>
    )
}
