import React from 'react'

export default function HeroSection() {
    return (
        <section className="hero-wrap section">
      <div className="hero-mask opacity-9 bg-primary"></div>
      <div className="hero-bg" style={{backgroundImage:"url('images/bg/image-5.jpg')"}}></div>
      <div className="hero-content py-2 py-lg-5">
        <div className="container text-center">
          <h2 className="text-14 text-white">Sell Products all over the Pakistan with Deal Vow.</h2>
          <p className="text-5 text-white mb-4">Quickly and easily receive and request money online with Deal Vow.<br className="d-none d-lg-block" />
            Over 4 payment methods supported.</p>
          <a className="btn btn-light video-btn" href="/#" data-src="https://www.youtube.com/embed/7e90gBu4pas" data-toggle="modal" data-target="#videoModal"><span className="text-2 mr-3"><i className="fas fa-play"></i></span>See How it Works</a> </div>
      </div>
    </section>
    )
}
