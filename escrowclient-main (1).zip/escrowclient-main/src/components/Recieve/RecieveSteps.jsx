import React from 'react'

export default function RecieveSteps() {
    return (
        <section className="section bg-white">
      <div className="container">
        <div className="row">
          <div className="col-xl-10 mx-auto">
            <div className="row">
              <div className="col-md-5 col-lg-6 text-center my-auto order-2 order-md-1"> <img className="img-fluid shadow" src="images/request-money.png" alt="" /> </div>
              <div className="col-md-7 col-lg-6 order-1 order-md-2">
                <h2 className="text-9"> The simple way to Sell Something</h2>
                <p className="text-3 mb-4">The modern way to sell products with a payment protection service.</p>
                <div className="row">
                  <div className="col-12 mb-4">
                    <div className="featured-box style-3">
                      <div className="featured-box-icon text-light"><span className="w-100 text-20 font-weight-500">1</span></div>
                      <h3>Sign Up Your Account</h3>
                      <p>Become a register user first, then log in to your account and enter your card or bank details that is required for you.</p>
                    </div>
                  </div>
                  <div className="col-12 mb-4">
                    <div className="featured-box style-3">
                      <div className="featured-box-icon text-light"><span className="w-100 text-20 font-weight-500">2</span></div>
                      <h3>Enter Buyer Details</h3>
                      <p>Enter your buyer name, email address then add an amount with currency to request payment.</p>
                    </div>
                  </div>
                  <div className="col-12 mb-4 mb-sm-0">
                    <div className="featured-box style-3">
                      <div className="featured-box-icon text-light"><span className="w-100 text-20 font-weight-500">3</span></div>
                      <h3>Receive Money</h3>
                      <p>After the request payment, the buyer will be notified via an email for payment.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    )
}
