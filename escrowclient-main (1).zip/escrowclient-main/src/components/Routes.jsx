import React from 'react'
import { 
    Switch,
    Route
} from "react-router-dom";
import ProtectedRoute from "./protectedRouter";
import {isAuthenticUser} from '../utils/validateUser';
import Home from './Home/Home'
import Send from './Send/Send'
import Recieve from './Recieve/Recieve'
import About from './About/About'
import Fees from './Fees/Fees'
import Help from './Help/Help'
import Contact from './Contact/Contact'
import Login from './LoginSignUp/Login'
import SignUp from './LoginSignUp/SignUp'
import ForgotPassword from './LoginSignUp/forgotPassword'
import ForgotPasswordOrg from './LoginSignUp/forgotOrgPassword'
import ResetPassword from './LoginSignUp/ResetPassword'
import ResetPasswordOrg from './LoginSignUp/ResetPassword'
import CreateOrg from './LoginSignUp/ResetPassword'
import SignUpOrg from './LoginSignUp/SignUpOrg'
import Profile from './Account/Profile/Profile'
import BankCards from './Account/BankCards/BankCards'
import Notifications from './Account/Notifications/Notifications'
import DashBoard from './Account/DashBoard/DashBoard'
import DealPage from './DealPage/DealPage'
import Transactions from './Account/Transactions/Transactions'
import SendMoney from './Transactions/SendMoney/SendMoney'
import SendMoneyConfirm from './Transactions/SendMoneyConfirm/SendMoneyConfirm'
import SendMoneySuccess from './Transactions/SendMoneySuccess/SendMoneySuccess'
import RequestMoney from './Transactions/RequestMoney/RequestMoney'
import RequestMoneyConfirm from './Transactions/RequestMoneyConfirm/RequestMoneyConfirm'
import RequestMoneySuccess from './Transactions/RequestMoneySuccess/RequestMoneySuccess'
import Deposit from './Account/Deposit/Deposit'
import Withdraw from './Account/Withdraw/Withdraw'
import VirtualListings from './Account/VirtualListings/VirtualListings'
import MyDeals from './Account/MyDeals/MyDeals'
import OrgEmployees from './Account/OrgEmployees/OrgEmployees'
import OpenDispute from './OpenDispute/OpenDispute'
import SellerDispute from './SellerDispute/SellerDispute'
import ViewListings from './ViewListings/ViewListings'
import ListingDetail from './ListingDetail/ListingDetail'
import BroakerDeal from './Transactions/BroakerDeal/BroakerDeal'
export default function Routes() {
    let authentic = isAuthenticUser();
    return (
        <Switch>
                <Route exact path="/send" component={Send} />
                    
                
                <Route exact path="/recieve">
                    <Recieve />
                </Route>
                <Route exact path="/about">
                    <About />
                </Route>
                <Route exact path="/fees">
                    <Fees />
                </Route>
                <Route exact path="/help">
                    <Help />
                </Route>
                <Route exact path="/contact">
                    <Contact />
                </Route>
                <Route exact path="/login">
                    <Login />
                </Route>
                <Route exact path="/loginOrg">
                    <Login type = "org"/>
                </Route>
                <Route exact path="/signup">
                    <SignUp />
                </Route>
                <Route exact path="/reset">
                    <ResetPassword />
                </Route>
                <Route exact path="/resetOrg">
                    <ResetPasswordOrg />
                </Route>
                <Route exact path="/createOrg">
                    <CreateOrg />
                </Route>
                <Route exact path="/forgot">
                    <ForgotPassword/>
                </Route>
                <Route exact path="/forgotOrg">
                    <ForgotPasswordOrg/>
                </Route>
                <Route exact path="/signuporg">
                    <SignUpOrg />
                </Route>
                <ProtectedRoute  exact path="/profile" component={Profile} />
                <ProtectedRoute  exact path="/bankCards" component={BankCards} /> 
                <ProtectedRoute  exact path="/virtualListings" component={VirtualListings} />
                    
                <Route exact path="/viewListings">
                    <ViewListings />
                </Route>
                <Route exact path="/listingDetail">
                    <ListingDetail />
                </Route>
                <Route exact path="/broakerDeal">
                    <BroakerDeal />
                </Route>
                <ProtectedRoute authed={authentic} exact path="/dashboard" component={DashBoard} />
                <ProtectedRoute authed={authentic} exact path="/transactions" component={Transactions} />
                
                
                <Route exact path="/dealpage">
                    <DealPage />
                </Route>
                
                <Route exact path="/sendmoney">
                    <SendMoney />
                </Route>
                <Route exact path="/sendmoneyconfirm">
                    <SendMoneyConfirm />
                </Route>
                <Route exact path="/sendmoneysuccess">
                    <SendMoneySuccess />
                </Route>
                <Route exact path="/requestmoney">
                    <RequestMoney />
                </Route>
                <Route exact path="/requestmoneyconfirm">
                    <RequestMoneyConfirm />
                </Route>
                <Route exact path="/opendispute">
                    <OpenDispute />
                </Route>
                <Route exact path="/sellerdispute">
                    <SellerDispute />
                </Route>
                <ProtectedRoute authed={authentic} exact path="/notifications" component={Notifications} />
                <ProtectedRoute authed={authentic} exact path="/mydeals" component={MyDeals} />
                <ProtectedRoute authed={authentic} exact path="/orgemployees" component={OrgEmployees} />
                
                <Route exact path="/requestmoneysuccess">
                    <RequestMoneySuccess />
                </Route>

                <ProtectedRoute authed={authentic} exact path="/deposit" component={Deposit} />
                <ProtectedRoute authed={authentic} exact path="/withdraw" component={Withdraw} />
                
                

                <Route path="/">
                    <Home />
                </Route>
            </Switch>
    )
}
