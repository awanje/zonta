import React from 'react'

export default function ServiceCountBanner() {
    return (
        <section className="section bg-primary py-5">
      <div className="container text-center">
        <div className="row">
          <div className="col-sm-6 col-md-3">
            <div className="featured-box text-center">
              <div className="featured-box-icon text-light mb-2"> <i className="fas fa-globe"></i> </div>
              <h4 className="text-12 text-white mb-0">180+</h4>
              <p className="text-4 text-white mb-0">Countries</p>
            </div>
          </div>
          <div className="col-sm-6 col-md-3">
            <div className="featured-box text-center">
              <div className="featured-box-icon text-light mb-2"> <i className="fas fa-dollar-sign"></i> </div>
              <h4 className="text-12 text-white mb-0">120</h4>
              <p className="text-4 text-white mb-0">Currencies</p>
            </div>
          </div>
          <div className="col-sm-6 col-md-3 mt-4 mt-md-0">
            <div className="featured-box text-center">
              <div className="featured-box-icon text-light mb-2"> <i className="fas fa-users"></i> </div>
              <h4 className="text-12 text-white mb-0">2.5M</h4>
              <p className="text-4 text-white mb-0">Users</p>
            </div>
          </div>
          <div className="col-sm-6 col-md-3 mt-4 mt-md-0">
            <div className="featured-box text-center">
              <div className="featured-box-icon text-light mb-2"> <i className="far fa-life-ring"></i> </div>
              <h4 className="text-12 text-white mb-0">24X7</h4>
              <p className="text-4 text-white mb-0">Support</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    )
}
