import React from 'react'
import Carousel from 'react-elastic-carousel'

const itemStyle= {
  borderRadius : "15px"
}
export default function SendMoneyTestimonial() {
  return (
    <section className="section">
      <div className="container">
        <h2 className="text-9 text-center">What people say about Payyed</h2>
        <p className="text-4 text-center mb-4">A payments experience people love to talk about</p>
        <div className="row">
          <div className="col-lg-10 col-xl-8 mx-auto">
            <div className="owl-carousel owl-theme" data-autoplay="true" data-nav="true" data-loop="true" data-margin="30" data-stagepadding="5" data-items-xs="1" data-items-sm="1" data-items-md="1" data-items-lg="1">
              <Carousel
                enableAutoPlay
                itemsToShow={1}
                autoPlaySpeed={11500}
                >
                
                <div className={`item ${itemStyle}`}  >
                  <div className="testimonial rounded text-center p-4">
                    <p className="text-4">“Easy to use, reasonably priced simply dummy text of the printing and typesetting industry. Quidam lisque persius interesset his et, in quot quidam possim iriure.”</p>
                    <strong className="d-block font-weight-500">Jay Shah</strong> <span className="text-muted">Founder at Icomatic Pvt Ltd</span> </div>
                </div>
                <div className="item">
                  <div className="testimonial rounded text-center p-4">
                    <p className="text-4">“I am happy Working with printing and typesetting industry. Quidam lisque persius interesset his et, in quot quidam persequeris essent possim iriure.”</p>
                    <strong className="d-block font-weight-500">Patrick Cary</strong> <span className="text-muted">Freelancer from USA</span> </div>
                </div>
                <div className="item">
                  <div className="testimonial rounded text-center p-4">
                    <p className="text-4">“Fast easy to use transfers to a different currency. Much better value that the banks.”</p>
                    <strong className="d-block font-weight-500">De Mortel</strong> <span className="text-muted">Online Retail</span> </div>
                </div>
                <div className="item">
                  <div className="testimonial rounded text-center p-4">
                    <p className="text-4">“I have used them twice now. Good rates, very efficient service and it denies high street banks an undeserved windfall. Excellent.”</p>
                    <strong className="d-block font-weight-500">Chris Tom</strong> <span className="text-muted">User from UK</span> </div>
                </div>
                <div className="item">
                  <div className="testimonial rounded text-center p-4">
                    <p className="text-4">“It's a real good idea to manage your money by payyed. The rates are fair and you can carry out the transactions without worrying!”</p>
                    <strong className="d-block font-weight-500">Mauri Lindberg</strong> <span className="text-muted">Freelancer from Australia</span> </div>
                </div>
                <div className="item">
                  <div className="testimonial rounded text-center p-4">
                    <p className="text-4">“Only trying it out since a few days. But up to now excellent. Seems to work flawlessly. I'm only using it for sending money to friends at the moment.”</p>
                    <strong className="d-block font-weight-500">Dennis Jacques</strong> <span className="text-muted">User from USA</span> </div>
                </div>
              </Carousel>
            </div>
            <div className="text-center mt-4"><a href="/#" className="btn-link text-4">See more people review<i className="fas fa-chevron-right text-2 ml-2"></i></a></div>
          </div>
        </div>
      </div>
    </section>
  )
}
