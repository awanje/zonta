import React from 'react'

export default function WhySendFromUs() {
    return (
        <section class="section">
      <div class="container">
        <h2 class="text-9 text-center">Why choose payyed?</h2>
        <p class="text-4 text-center mb-5">Here’s Top 4 reasons why using a Payyed account for manage your money.</p>
        <div class="row">
          <div class="col-md-6 mb-4 mb-md-0">
            <div class="hero-wrap section h-100 p-5 rounded">
              <div class="hero-mask rounded opacity-6 bg-dark"></div>
              <div class="hero-bg rounded" style={{backgroundImage:"url('./images/bg/image-6.jpg')"}}></div>
              <div class="hero-content">
                <h2 class="text-6 text-white mb-3">Why Payyed?</h2>
                <p class="text-light mb-5">Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure. Mutat tacimates id sit. Ridens mediocritatem ius an, eu nec magna imperdiet.</p>
                <h2 class="text-6 text-white mb-3">Send Money with Payyed</h2>
                <p class="text-light">Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure. Mutat tacimates id sit. Ridens mediocritatem ius an, eu nec magna imperdiet.</p>
                <p class="text-light mb-0">Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.</p>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="featured-box style-1">
              <div class="featured-box-icon text-primary"> <i class="far fa-check-circle"></i> </div>
              <h3>Over 180 countries</h3>
              <p>Essent lisque persius interesset his et, in quot quidam.</p>
            </div>
            <div class="featured-box style-1">
              <div class="featured-box-icon text-primary"> <i class="far fa-check-circle"></i> </div>
              <h3>Lower Fees</h3>
              <p>Lisque persius interesset his et, in quot quidam persequeris.</p>
            </div>
            <div class="featured-box style-1">
              <div class="featured-box-icon text-primary"> <i class="far fa-check-circle"></i> </div>
              <h3>Easy to Use</h3>
              <p>Essent lisque persius interesset his et, in quot quidam.</p>
            </div>
            <div class="featured-box style-1">
              <div class="featured-box-icon text-primary"> <i class="far fa-check-circle"></i> </div>
              <h3>Faster Payments</h3>
              <p>Quidam lisque persius interesset his et, in quot quidam.</p>
            </div>
            <div class="featured-box style-1">
              <div class="featured-box-icon text-primary"> <i class="far fa-check-circle"></i> </div>
              <h3>100% secure</h3>
              <p>Essent lisque persius interesset his et, in quot quidam.</p>
            </div>
            <div class="featured-box style-1">
              <div class="featured-box-icon text-primary"> <i class="far fa-check-circle"></i> </div>
              <h3>24/7 customer service</h3>
              <p>Quidam lisque persius interesset his et, in quot quidam.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    )
}
