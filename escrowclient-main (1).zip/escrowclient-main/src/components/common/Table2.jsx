import React, { Component, Fragment  } from 'react';
import ReactDatatable from '@ashvin27/react-datatable';
import './Table2.css'
function ExportButtons(props) {
    
        
        var config = {
            page_size: 10,
            length_menu: [10, 20, 50],
            show_filter: true,
            show_pagination: true,
            filename: "Users",
            button: {
                excel: true,
                csv: true,
            }
        }
        // var records = [
        //     {
        //       "id": "1",
        //       "address": "228 City Road",
        //       "name": ".CN Chinese",
        //       "postcode": "3JH",
        //       "rating": 5,
        //       "salary": "2500"
        //     }
            
        //   ]
    

    

    
        return (
            <div className="table-responsive">
            <ReactDatatable
                config={config}
                records={props.records}
                columns={props.columns}
                className="table custom-table" 
                tHeadClassName="header-style"
                style={{fontSize:"20px"}}
                checkbox
            />
            </div>
        );
    
}

export default ExportButtons;