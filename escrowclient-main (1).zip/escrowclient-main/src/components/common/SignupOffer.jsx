import React from 'react'

export default function SignupOffer() {
    return (
        <section class="hero-wrap py-5">
      <div class="hero-mask opacity-8 bg-dark"></div>
      <div class="hero-bg" style={{backgroundImage:"url('images/bg/image-2.jpg')"}}></div>
      <div class="hero-content">
        <div class="container d-md-flex text-center text-md-left align-items-center justify-content-center">
          <h2 class="text-6 font-weight-400 text-white mb-3 mb-md-0">Sign up today and get your first transaction fee free!</h2>
          <a href="/#" class="btn btn-outline-light text-nowrap ml-4">Sign up Now</a> </div>
      </div>
    </section>
    )
}
