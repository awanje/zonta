import React from 'react'

export default function HelpTopics() {
    return (
        <section className="section py-3 my-3 py-sm-5 my-sm-5">
      <div className="container">
        <div className="row">
          <div className="col-sm-6 col-lg-3 mb-4 mb-lg-0">
            <div className="bg-light shadow-sm rounded p-4 text-center"> <span className="d-block text-17 text-primary mt-2 mb-3"><i className="fas fa-user-circle"></i></span>
              <h3 className="text-body text-4">My Account</h3>
              <p className="mb-0"><a className="text-muted btn-link" href="">See articles<span className="text-1 ml-1"><i className="fas fa-chevron-right"></i></span></a></p>
            </div>
          </div>
          <div className="col-sm-6 col-lg-3 mb-4 mb-lg-0">
            <div className="bg-light shadow-sm rounded p-4 text-center"> <span className="d-block text-17 text-primary mt-2 mb-3"><i className="fas fa-money-check-alt"></i></span>
              <h3 className="text-body text-4">Payment</h3>
              <p className="mb-0"><a className="text-muted btn-link" href="">See articles<span className="text-1 ml-1"><i className="fas fa-chevron-right"></i></span></a></p>
            </div>
          </div>
          <div className="col-sm-6 col-lg-3 mb-4 mb-sm-0">
            <div className="bg-light shadow-sm rounded p-4 text-center"> <span className="d-block text-17 text-primary mt-2 mb-3"><i className="fas fa-shield-alt"></i></span>
              <h3 className="text-body text-4">Security</h3>
              <p className="mb-0"><a className="text-muted btn-link" href="/">See articles<span className="text-1 ml-1"><i className="fas fa-chevron-right"></i></span></a></p>
            </div>
          </div>
          <div className="col-sm-6 col-lg-3">
            <div className="bg-light shadow-sm rounded p-4 text-center"> <span className="d-block text-17 text-primary mt-2 mb-3"><i className="fas fa-credit-card"></i></span>
              <h3 className="text-body text-4">Payment Methods</h3>
              <p className="mb-0"><a className="text-muted btn-link" href="/">See articles<span className="text-1 ml-1"><i className="fas fa-chevron-right"></i></span></a></p>
            </div>
          </div>
        </div>
      </div>
    </section>
    )
}
