import React from 'react'

export default function CantFindHelp() {
    return (
        <section className="section py-4 my-4 py-sm-5 my-sm-5">
      <div className="container">
        <div className="row">
          <div className="col-lg-6">
            <div className="bg-white shadow-sm rounded pl-4 pl-sm-0 pr-4 py-4">
              <div className="row no-gutters">
                <div className="col-12 col-sm-auto text-13 text-light d-flex align-items-center justify-content-center"> <span className="px-4 ml-3 mr-2 mb-4 mb-sm-0"><i className="far fa-envelope"></i></span> </div>
                <div className="col text-center text-sm-left">
                  <div className="">
                    <h5 className="text-3 text-body">Can't find what you're looking for?</h5>
                    <p className="text-muted mb-0">We want to answer all of your queries. Get in touch and we'll get back to you as soon as we can. <a className="btn-link" href="">Contact us<span className="text-1 ml-1"><i className="fas fa-chevron-right"></i></span></a></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="col-lg-6 mt-4 mt-lg-0">
            <div className="bg-white shadow-sm rounded pl-4 pl-sm-0 pr-4 py-4">
              <div className="row no-gutters">
                <div className="col-12 col-sm-auto text-13 text-light d-flex align-items-center justify-content-center"> <span className="px-4 ml-3 mr-2 mb-4 mb-sm-0"><i className="far fa-comment-alt"></i></span> </div>
                <div className="col text-center text-sm-left">
                  <div className="">
                    <h5 className="text-3 text-body">Technical questions</h5>
                    <p className="text-muted mb-0">Have some technical questions? Hit us up on live chat or whatever. <a className="btn-link" href="">Click here<span className="text-1 ml-1"><i className="fas fa-chevron-right"></i></span></a></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    )
}
