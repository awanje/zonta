import React , {useEffect} from 'react'
import PreLoader from '../mini_features/PreLoader.jsx'
import NavBar from '../menu/NavBarWhite.jsx'
import Hero from './HeroSection'
import HelpTopics from './HelpTopics'
import HelpPopularTopics from './HelpPopularTopics'
import CantFindHelp from './CantFindHelp'
import Footer from '../common/Footer'
import $ from 'jquery'

export default function Help() {
    useEffect(() => {
        $('[data-loader="circle-side"]').fadeOut() 
              $('#preloader').delay(333).fadeOut('slow')
              $('body').delay(333) 
      })
    return (
        <>
            <PreLoader />
            <NavBar />
            <Hero />
            <HelpTopics />
            <HelpPopularTopics />
            <CantFindHelp />
            <Footer />
        </>
    )
}
