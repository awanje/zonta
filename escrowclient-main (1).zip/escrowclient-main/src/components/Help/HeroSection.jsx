import React from 'react'

export default function HeroSection() {
    return (
        <section className="hero-wrap section">
    <div className="hero-mask opacity-9 bg-primary"></div>
    <div className="hero-bg" style={{backgroundImage:"url('./images/bg/image-2.jpg')"}}></div>
    <div className="hero-content">
      <div className="container">
        <div className="row align-items-center text-center">
          <div className="col-12">
            <h1 className="text-11 text-white mb-3">How can we help you?</h1>
          </div>
          <div className="col-md-10 col-lg-8 col-xl-6 mx-auto">
            <div className="input-group">
              <input className="form-control shadow-none border-0" type="search" id="search-input" placeholder="Search for answer..." value="" />
              <div className="input-group-append"> <span className="input-group-text bg-white border-0 p-0">
                <button className="btn text-muted px-3 border-0" type="button"><i className="fa fa-search"></i></button>
                </span> </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
    )
}
