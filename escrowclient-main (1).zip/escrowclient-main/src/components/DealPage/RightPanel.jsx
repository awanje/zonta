import React, { useState } from 'react'
import { Modal } from '@material-ui/core';

export default function LeftPanel() {
  const [open, setOpen] = useState({ finalize: false })
const [formFinalize,setFormFinalize]=useState({
email:"",otp:''
})
  let ab = 5;

const handleFinalizeChange=(e)=>{
  console.log(e,'sdfsd')
  setFormFinalize({...formFinalize,[e.name]:e.value})
}

  function handleDone() {
    alert("CLicked from Modal")
  }
  const handleModal = (e) => {
    setOpen({ ...open, [e]: true })
  }
  const handleClose = () => {
    setOpen({ ...open, finalize: false })
  }
  return (
    <aside className="col-lg-3">

      {/*  <!-- Finish Deal?
          =============================== --> */}
      <div className="bg-light shadow-sm rounded text-center p-3 mb-4" style={{ marginTop: "5px" }}>
        <div className="text-15 text-light my-3"><i className="fas fa-check"></i></div>
        <h3 className="text-6 font-weight-500 my-4">Find the Deal Finished?</h3>
        <p className="text-muted opacity-8 mb-4">You can finalize the deal if you're happy with it.<br /></p>
        {/* <a href="/#" className="btn btn-primary btn-block" onClick={()=>handleModal('finalize')}>Finalize Deal</a> */}
        <button className="btn btn-primary btn-block" onClick={() => handleModal('finalize')}>Finalize Deal</button>
      </div>
      {/* <!-- Finish Deal? End -->  */}

      {/*  <!-- Need Help?
          =============================== --> */}
      <div className="bg-light shadow-sm rounded text-center p-3 mb-4" style={{ marginTop: "5px" }}>
        <div className="text-15 text-light my-3"><i className="fas fa-money"></i></div>
        <h3 className="text-6 font-weight-500 my-4">Want Some Quick Payments?</h3>
        <p className="text-muted opacity-8 mb-4">Request a Milestone Payment from the Buyer<br /></p>
        <a href="/#" className="btn btn-primary btn-block">Request Payment</a>
      </div>
      {/* <!-- Need Help? End -->  */}

      {/*  <!-- Open Dispute?
          =============================== --> */}
      <div className="bg-light shadow-sm rounded text-center p-3 mb-4" style={{ marginTop: "5px" }}>
        <div className="text-15 text-light my-3"><i className="fas fa-gavel"></i></div>
        <h3 className="text-6 font-weight-500 my-4">Running into a Dispute?</h3>
        <p className="text-muted opacity-8 mb-4">Open dispute if you find that there is something wrong<br /></p>
        <a href="/#" className="btn btn-danger btn-block"><span style={{ color: "white" }}>File Dispute</span></a>
      </div>
      {/* <!-- Open Dispute? End -->  */}


      <Modal onClose={handleClose} open={open.finalize} style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center'
      }}>
        <div style={{
          minWidth: '500px',
          backgroundColor: 'white',
          color: 'grey',
          padding: '0px',
          minHeight: '300px',
          borderRadius: "5px",
          maxHeight: '70vh'
        }}>



          <div className="modal-content">
            <div className="modal-header">
              <h5 className="modal-title font-weight-400">Finalize the deal</h5>
              <button onClick={handleClose} type="button" className="close font-weight-400" data-dismiss="modal" aria-label="Close">X </button>
            </div>
            <div className="modal-body p-4">
              <form id="changePassword" method="post">
                <div className="form-group">
                  <label for="emailID">Email ID</label>
                  <input type="text" name="email" value={formFinalize.email} onChange={(e)=>handleFinalizeChange(e.target)} className="form-control" data-bv-field="emailid" id="emailID" required placeholder="Email ID" />
                </div>
                <div className="form-group">
                  <label for="otp">Otp</label>
                  <div style={{ display: 'flex' }}>
                    <input type="text" onChange={(e)=>handleFinalizeChange(e.target)} className="form-control" value={formFinalize.otp} name='otp' id="otp" required placeholder={ab} />
                    <button type="button" className="btn btn-success btn-md" data-dismiss="modal" aria-label="Close"> Validate </button>
                  </div>
                  <button type="button" style={{ backgroundColor: 'transparent', border: 'none' }} data-dismiss="modal" aria-label="Close"> Send OTP </button>
                </div>

                <button className="btn btn-success btn-lg" type="button" onClick={handleDone}>Finalize Deal</button>
              </form>
            </div>
          </div>
        </div>





      </Modal>
    </aside>
  )
}
