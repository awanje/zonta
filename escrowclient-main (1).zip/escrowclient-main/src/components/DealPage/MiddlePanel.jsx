import React , {useState} from 'react'
import { ChatFeed, Message } from 'react-chat-ui'



let nav = {
  listStyleType: "none",
  textAlign: "center",
  margin: "0",
  padding: "0",
  float: "right",
  display: "inline-block"
}

let li = {
  display: "inline-block",
  margin: "3px",
  float: "left"
}

export default function MiddlePanel(props) {
  let dealInfo = props.deal;
  const [chatForm , setChatForm] = useState("");
  const [messages , setMessages] = useState([
    new Message({
      id: 1,
      message: "I'm the recipient! (The person you're talking to)",
    }), // Gray bubble
    new Message({ id: 0, message: "I'm you -- the blue bubble!" }) // Blue bubble
  ])

  function handleFormChange(event) {
    const {name , value} = event.target;
    setChatForm(value);
  }

  function handleMessageSend(event){
    event.preventDefault();
    setMessages(prevValue => {
      return [
        ...prevValue,
        new Message({
          id: 0,
          message: chatForm,
        })
      ]
    })
    setChatForm("");

  }
  return (
    <div class="col-lg-9">

      <div className="row">
        <div className="col-lg-4" >
          <div className="bg-light shadow-sm rounded text-center p-3 mb-4" style={{ marginTop: "5px", height: "150px" }}>
            <div className="profile-thumb mt-1 mb-2 float-left"> <img className="rounded-circle" src="images/profile-thumb.jpg" alt="" /></div>
            <div className="float-left" style={{ marginLeft: "15px" }}>
              <p className="text-3 font-weight-500 mb-2" >{dealInfo.seller_mail.substring(0, 10)}</p>
              <p className="text-3 font-weight-700 mb-2 " style={{ color: "green" }}>SELLER</p>
              <p className="mb-2" ><a href="profile.html" className="text-2 text-dark"><span style={{ color: "#00ADD7" }}>View Profile</span></a></p>
            </div>
          </div>
        </div>
        <div className="col-lg-4" >
          <div className="bg-light shadow-sm rounded text-center p-3 mb-4" style={{ marginTop: "5px", height: "150px" }}>
            <div className="profile-thumb mt-1 mb-2 float-left"> <img className="rounded-circle" src="images/profile-thumb.jpg" alt="" /></div>
            <div className="float-left" style={{ marginLeft: "15px" }}>
              <p className="text-3 font-weight-500 mb-2" >{dealInfo.buyer_mail.substring(0, 10)}</p>
              <p className="text-3 font-weight-700 mb-2 " style={{ color: "green" }}>BUYER</p>
              <p className="mb-2" ><a href="profile.html" className="text-2 text-dark"><span style={{ color: "#00ADD7" }}>View Profile</span></a></p>
            </div>
          </div>
        </div>
        <div className="col-lg-4">
          <div className="bg-light shadow-sm rounded text-center p-3 mb-4" style={{ marginTop: "5px", height: "150px" }}>
            <h3 className="text-7 font-weight-400" style={{ marginTop: "30px" }}>PKR - {dealInfo.deal_amount}</h3>
            <p className="mb-2 text-muted opacity-8">Deal Amount</p>


          </div>
        </div>
      </div>
      <div class="bg-light shadow-sm rounded p-4 mb-4">
        <h3 class="text-5 font-weight-400 d-flex align-items-center px-4 mb-3">User Chat</h3><hr />
        <div className="row" style={{ padding: "15px" }}>
          <div className="container" style={{ border: "3px solid #DEE3E4", padding: "15px 15px 0px 15px", borderRadius: "15px" }} >
            <div style={{height:"300px"}}>
              <ChatFeed
                messages={messages} // Array: list of message objects
                // isTyping={this.state.is_typing} // Boolean: is the recipient typing
                hasInputField={false} // Boolean: use our input, or use your own
                showSenderName // show the name of the user who sent the message
                bubblesCentered={false} //Boolean should the bubbles be centered in the feed?
                // JSON: Custom bubble styles
                bubbleStyles={
                  {
                    text: {
                      fontSize: 12
                    },
                    chatbubble: {
                      borderRadius: 70,
                      padding: 10
                    },
                    recipientChatbubble: {
                      backgroundColor: "white"
                    }
                  }
                }
              />
            </div>
            <hr />
            <div className="row mb-2">
              <input className="form-control col-lg-9" value={chatForm} onChange={handleFormChange} type="text" style={{ width: "80%", borderRadius: "9px", border: "none", padding: "3px", marginLeft: "9px" }} placeholder="Enter Message Here" />
              <ul style={nav} className="col-lg-2">
                <li style={li}><a href="#" onClick={handleMessageSend} class="  text-6 text-light mt-1 col-lg-1 "><i style={{ color: "#41A5EE" }} class="fas fa fa-paper-plane"></i></a></li>
                <li style={li}><a href="#" class="  text-6 text-light mt-1 col-lg-1 "><i style={{ color: "#41A5EE" }} class="fas fa fa-picture-o"></i></a></li>
              </ul>
            </div>

          </div>



        </div>
      </div>
      {/* Profile Completeness
          =============================== */}
      <div class="bg-light shadow-sm rounded p-4 mb-4">
        <h3 class="text-5 font-weight-400 d-flex align-items-center mb-3">Deal Agreement <span class="bg-light-4 text-success rounded px-2 py-1 font-weight-400 text-2 ml-2">50%</span></h3>
        <pre className="text-5 font-weight-400">
        {dealInfo.deal_agreement}
        </pre>
      </div>
      {/* Profile Completeness End */}


    </div>
  )
}
