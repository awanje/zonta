import React, { useEffect , useState } from 'react'
import PreLoader from '../mini_features/PreLoader.jsx'
import NavBar from '../menu/NavBarWhite.jsx'
import RightPanel from './RightPanel'
import MiddlePanel from './MiddlePanel'
import Footer from '../common/Footer'
import {useLocation , useParams} from "react-router-dom"
import $ from 'jquery'
import { getDeal } from "../../store/actions/deal.actions"


export default function DealPage(props) {
    const locationData = useLocation().data;
    let { id } = useParams();
    console.log(id)
    const [dealData, setDealData] = useState(
        {
            deal_id: 1,
            deal_amount: 2499,
            commission_amount: 25,
            buyer_id: null,
            seller_id: null,
            seller_mail: "hassanyousaf565@gmail.com",
            buyer_mail: "hytec2020@gmail.com",
            seller_phone: null,
            buyer_phone: null,
            holding_days: 12,
            deal_agreement: "hg sdfghdfjkghdfjkgh dfjkshg",
            deal_for: "nothing",
            listing_id: null,
            status_name: "",
            status_description: ""
        }
    )
    useEffect(() => {
        $('[data-loader="circle-side"]').fadeOut()
        $('#preloader').delay(333).fadeOut('slow')
        $('body').delay(333)
    })
    useEffect( () => {
        async function fetchData(){
            let DealData = await getDeal(1);
            setDealData(DealData.data);
            console.log(DealData);
        }
        //fetchData();
    } , [])
    return (
        <>
            <PreLoader />
            <NavBar />
            <div class="container">
                <div class="row">

                    <MiddlePanel
                    deal={dealData} />
                    <RightPanel />
                </div>
            </div>

            <Footer />
        </>
    )
}

