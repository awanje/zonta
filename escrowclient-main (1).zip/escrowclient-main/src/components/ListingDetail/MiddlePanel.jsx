import React  from 'react'
import uuid from 'react-uuid';
import UserReview from './UserReview'
export default function MiddlePanel() {
  const listing  = {
    title: "New Listing 1",
    image : "images/gig1.jpg",
    price:500,
    protectionDays: "",
    details: "",
    id:0, 
    category:"domain"
  }
  
  

  
  
  return (
    <div className="col-lg-9">

      {/* Main White Div
          ============================================= */}
      <div className="bg-light shadow-sm rounded p-4 mb-4 mt-4">
        <h3 className="text-5 font-weight-400 mb-4">New Listing 1 </h3>
        <div className="row p-3">
        <img src={listing.image} alt="listing image" style={{width:"100%"}} />
        </div>
        <div>
          <h3 className="mt-2">Listing Details</h3>
          <p className="text-3 p-2">
            No fraud<br/>
            100% guaranteed uptime<br/>
            Protected by Deal Vow<br/>
            15 Days Easy Return<br/>
            Change of mind not acceptable<br/> 
          </p>
        </div>
        <h3 className="mt-2">Listing Reviews</h3>
          <hr />
        {/* User Review */}
        <UserReview />
        <UserReview />
        <p className="text-3 text-info"><a href="#"> See More Reviews</a></p>
        



      </div>
     
      
      {/* Main White Div End */}

    </div>
  )
}
