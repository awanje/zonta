import React from 'react'

export default function UserReview() {
    return (
        <div className=" transaction-item  shadow-sm rounded p-1 mb-4 mt-4">
            <div className="row" style={{marginLeft:"10px"}}>
            <p className="text-5  float-left mt-2" > Ab Jones</p>
            <p className="mb-0 text-3 mt-3 font-weight-400 " style={{marginLeft:"9px"}}>
            <i class="fa fa-star text-warning" aria-hidden="true"></i>
            <i class="fa fa-star text-warning" aria-hidden="true"></i>
            <i class="fa fa-star text-warning" aria-hidden="true"></i>
            <i class="fa fa-star text-warning" aria-hidden="true"></i>
            <i class="fa fa-star text-warning" aria-hidden="true"></i>
            </p>
            </div>
            <div className="row" style={{marginLeft:"15px"}}>
            <p>It was really fantastic to work with smith johnes</p>
            </div>
        </div>
    )
}
