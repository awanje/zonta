import React from 'react'

export default function LeftPanel() {
    return (
        <aside className="col-lg-3"> 
          
          {/* <!-- Profile Details
          =============================== --> */}
          <div className="bg-light shadow-sm rounded text-center p-3 mb-4 mt-4">
            <h2>Seller Profile</h2>
            <hr />
            <div className="profile-thumb mt-1 mb-2"> <img className="rounded-circle" src="images/profile-thumb.jpg" alt="" />
              
            </div>
            <p className="text-5 font-weight-500 mb-0">Smith Rhodes</p>
            <p className="mb-0 text-3 font-weight-400 ">5/5<br />
            <i class="fa fa-star text-warning" aria-hidden="true"></i>
            <i class="fa fa-star text-warning" aria-hidden="true"></i>
            <i class="fa fa-star text-warning" aria-hidden="true"></i>
            <i class="fa fa-star text-warning" aria-hidden="true"></i>
            <i class="fa fa-star text-warning" aria-hidden="true"></i>
            </p>
            
            
          </div>
          {/* <!-- Profile Details End -->
          */}

          <div className="bg-light shadow-sm rounded text-center p-3 mb-4 mt-4">
            <div className="row">
            <p className="float-left col-lg-6 text-6 font-weight-400 text-success">Price: </p>
            <p className="float-right col-lg-6 text-6 text-success font-weight-600">750<span className="text-light font-weight-200">(PKR)</span></p>
            </div>
            
            <div className="row">
            <p className="d-inline p-2">Deal Protection Offered By Deal Vow</p>
            </div>
            
            <div className="text-center">
            <button className="btn btn-success btn-md"> Buy Now</button>
            </div>
            
          </div>
          
        </aside>
    )
}
