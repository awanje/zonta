import React from 'react'

export default function LeftPanel() {
    return (
        <aside className="col-lg-3"> 
          
          {/* <!-- Profile Details
          =============================== --> */}
          <div className="bg-light shadow-sm rounded text-center p-3 mb-4 mt-4">
            <div className="profile-thumb mt-3 mb-4"> <img className="rounded-circle" src="images/profile-thumb.jpg" alt="" />
              
            </div>
            <p className="text-5 font-weight-500 mb-0">Smith Rhodes</p>
            <p className="mb-0 text-3 font-weight-400">5/5</p>
            <i class="fa fa-star text-warning" aria-hidden="true"></i>
            <i class="fa fa-star text-warning" aria-hidden="true"></i>
            <i class="fa fa-star text-warning" aria-hidden="true"></i>
            <i class="fa fa-star text-warning" aria-hidden="true"></i>
            <i class="fa fa-star text-warning" aria-hidden="true"></i>
            
          </div>
          {/* <!-- Profile Details End -->
          */}
          
        </aside>
    )
}
