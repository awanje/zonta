import React from 'react'

export default function Listing(props) {

    return (
        //account-card-primary
        <>
            <div key={props.key} className="col-12 col-sm-6 col-lg-4" >
                <div className="account-card  text-white rounded  mb-4 mb-lg-0" style={{ backgroundColor: "white" }}>
                    <div>
                        <a href="/#" data-target="#view-listing-details" data-toggle="modal" ><img src={props.imgUrl} style={{ height: "100%", width: "100%", marginBottom: "0px" }} /></a>
                    </div>
                    {/* <div className="p-3">
                <p className="d-flex align-items-center m-0"> <span className="text-uppercase font-weight-500">Smith Rhodes</span>  </p>
                
                </div> */}
                    <div style={{ borderBottom: '1px solid', boxShadow: "2px 2px 2px 2px #C0C2C6", borderRadius: "2px", padding: "5px", marginLeft: "1px", marginRight: "1px", backgroundColor: "white", marginTop: "0px" }}>
                        <p className="text-4 font-weight-500" style={{ color: "black" }}><a style={{color:"black"}}href="/#" data-target="#view-listing-details" data-toggle="modal" >{props.title}</a><span className="float-right" style={{ color: "green" }}>Rs.{props.price}</span></p>
                        <div className=" text-center">
                            <button className="btn btn-success " style={{ height: "40px", padding: "6px", textAlign: "center", width: "60%", }}>Buy Now</button>
                        </div>
                    </div>


                </div>


            </div>

        </>

    )
}
