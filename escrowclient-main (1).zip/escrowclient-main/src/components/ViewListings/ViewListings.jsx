import React , {useEffect} from 'react'
import PreLoader from '../mini_features/PreLoader.jsx'
import NavBar from '../menu/NavBarWhite.jsx'
import SecondaryMenu from  '../SecondaryMenu'
import LeftPanel from './LeftPanel'
import MiddlePanel from './MiddlePanel'
import Footer from '../common/Footer'
import $ from 'jquery'

export default function BankCards() {
    useEffect(() => {
        $('[data-loader="circle-side"]').fadeOut() 
              $('#preloader').delay(333).fadeOut('slow')
              $('body').delay(333) 
      })
    return (
        <>
            <PreLoader />
            <NavBar />
            <div class="container">
                <div class="row">
                    <LeftPanel />
                    <MiddlePanel />
                </div>
            </div>

            <Footer />
        </>
    )
}

