import React , {useState } from 'react'
import Listing from './Listing'
import uuid from 'react-uuid';

export default function MiddlePanel() {
  const [viewListing , setViewListing] = useState(1);
  const [listings , setListings] = useState([{
    title: "New Listing 1",
    image : "images/gig1.jpg",
    price:500,
    protectionDays: "",
    details: "",
    id:0, 
    category:"domain"
  },{
    title: "New Listing 2",
    image : "images/gig1.jpg",
    price:1000,
    protectionDays: "",
    details: "",
    id:1,
    category:"domain"
  }])
  
  

  
  
  return (
    <div className="col-lg-9">

      {/* Credit or Debit Cards
          ============================================= */}
      <div className="bg-light shadow-sm rounded p-4 mb-4 mt-4">
        <h3 className="text-5 font-weight-400 mb-4">Seller Listings <span className="text-muted text-4">(Virtual)</span></h3>
        <div className="row">
        {listings.map(listing => {
          return (<Listing
            imgUrl={listing.image}
            title={listing.title}
            key={uuid()}
            price={listing.price}
            viewSetter = {setViewListing}
            listingID = {listing.id}
          />)
        })}

          
        </div>
      </div>
      {/* View Listing Details Modal
          ================================== */}
          <div id="view-listing-details" className="modal fade" role="dialog" aria-hidden="true">
                <div className="modal-dialog modal-dialog-centered" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title font-weight-400">View Listing </h5>
                            <button type="button" className="close font-weight-400" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
                        </div>
                        <div className="modal-body p-4">
                            <img src="images/gig1.jpg" style={{ height: "240px", width: "450px" }} />
                            <p className="text-5 font-weight-500" style={{ color: "black" }}>New Listing 1</p>
                            <pre className="text-2">
                              Detail listing 1
                              <br/>
                              detail listing 2
                              <br/>
                              detail listing 3
                              <br/>
                            </pre>
                            <span className="text-4 float-right" style={{ color: "green" }}>Rs.500</span>
                        </div>
                    </div>
                </div>
            </div>
      
      
      {/* Credit or Debit Cards End */}

    </div>
  )
}
