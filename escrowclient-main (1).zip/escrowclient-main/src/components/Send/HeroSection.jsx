import React, { useState, useRef, useEffect } from 'react'
import { Redirect } from "react-router-dom";
import SimpleReactValidator from 'simple-react-validator';
import InitiateDealForm from './SendRequestForm'
export default function Slider() {

  const commissionPerc = 1;
  //const history = useHistory();
  const simpleValidator = useRef(new SimpleReactValidator());

  const [redirect, setRedirect] = useState({
    redirect: false,
    path: '',
    props: {},
    from: ""
  })

  const [sendForm, setSendForm] = useState({
    sendingAmount: "",
    recievingAmount: "",
    email: "",
    commission: "",
    render: false
  })

  function handleSendChange(event) {
    const { name, value } = event.target;
    simpleValidator.current.showMessageFor(name)

    setSendForm(prevValue => {

      if (name === "sendingAmount") {
        let commissionValue = Math.ceil(Number((value / 100) * commissionPerc));
        let recieveMoney = Number(value) - commissionValue;
        return {
          ...prevValue,
          [name]: value,
          recievingAmount: recieveMoney,
          commission: commissionValue
        }
      } else {
        return {
          ...prevValue,
          [name]: value
        }
      }
    })
  }

  function handleFormSubmit(event) {
    console.log("triggered");
    event.preventDefault();
    let { name } = event.target;
    if (simpleValidator.current.fieldValid('email') && simpleValidator.current.fieldValid('sendingAmount')) {
        if (name === "send") {
            if (sendForm.sendingAmount < 10000) {
                setRedirect({
                    redirect: true,
                    path: '/sendmoney',
                    props: { ...sendForm, from: "home" }
                })
            } else {
                setRedirect({
                    redirect: true,
                    path: '/signup',
                    props: { ...sendForm, from: "sendmoney" }
                })
            }
        }
    } else {
        simpleValidator.current.showMessageFor('email')
        simpleValidator.current.showMessageFor('sendingAmount')
        setSendForm(prevValue => {
            return {
                ...prevValue,
                render: true
            }
        })
    }
    


}


  useEffect(() => {

  }, [sendForm.render])

  return (
    <>
      {redirect.redirect ? <Redirect
        strict
        sensitive
        from="/home"
        to={{
          pathname: redirect.path,
          state: redirect.props
        }
        } /> : ""
      }
      <section className="hero-wrap section shadow-md py-4">
        <div className="hero-mask opacity-7 bg-dark"></div>
        <div className="hero-bg" style={{ backgroundImage: "url('images/bg/image-6.jpg')" }}></div>
        <div className="hero-content py-5">
          <div className="container">
            <div className="row">
              <div className="col-lg-6 col-xl-7 my-auto text-center text-lg-left pb-4 pb-lg-0">
                <h2 className="text-17 text-white"><span className="font-weight-400 text-15">A better way to</span> <br />
                Buy Something </h2>
                <p className="text-4 text-white mb-4">Buy anything using Deal Vow to protect yourself from frauds.</p>
                <a className="btn btn-outline-light video-btn" href="#" data-src="https://www.youtube.com/embed/7e90gBu4pas" data-toggle="modal" data-target="#videoModal"><span className="text-2 mr-3"><i className="fas fa-play"></i></span>See How it Works</a> </div>
                <InitiateDealForm />
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
