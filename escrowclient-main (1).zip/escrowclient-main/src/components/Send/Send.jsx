
import React , {useEffect} from 'react'
import {useLocation} from 'react-router-dom'
import PreLoader from '../mini_features/PreLoader.jsx'
import NavBar from '../menu/NavBarWhite.jsx'
import Hero from './HeroSection.jsx'
import HowItWorks from './HowSendWorks'
import WhyChooseUs from '../common/WhyChooseUs'
import SendMoneyVideo from './SendMoneyVideo'
import SendMoneyTestimonial from '../common/Testimonial'
import Faq from './Faq.jsx'
import SignupOffer from '../common/SignupOffer.jsx'
import Footer from '../common/Footer'
import $ from 'jquery'

function Send(props) {
  let location = useLocation();
  useEffect(() => {
    $('[data-loader="circle-side"]').fadeOut() 
	      $('#preloader').delay(333).fadeOut('slow')
        $('body').delay(333)
        console.log(location)
  })
  
  return (
    <>
      <PreLoader />
      <NavBar />
      <Hero />
      <HowItWorks />
      <WhyChooseUs />
      <SendMoneyVideo />
      <SendMoneyTestimonial />
      <Faq />
      <SignupOffer />
      <Footer />
      {/* {$('[data-loader="circle-side"]').fadeOut()} 
	      {$('#preloader').delay(333).fadeOut('slow')} 
	      {$('body').delay(333)} */}
    </>
  )
}

export default Send;
