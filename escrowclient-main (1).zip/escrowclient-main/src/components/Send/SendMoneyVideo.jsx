import React from 'react'

export default function SendMoneyVideo() {
    return (
        <section class="hero-wrap section shadow-md">
        <div class="hero-mask opacity-9 bg-primary"></div>
        <div class="hero-bg" style={{backgroundImage:"url('images/bg/image-1.jpg')"}}></div>
        <div class="hero-content py-3 py-lg-5 my-3 my-lg-5">
          <div class="container text-center">
            <h2 class="text-9 text-white mb-4 mb-lg-5">How does buying through Deal vow work?</h2>
            <a class="video-btn d-inline-flex" href="/#" data-src="https://www.youtube.com/embed/7e90gBu4pas" data-toggle="modal" data-target="#videoModal"> <span class="btn-video-play bg-white shadow-md rounded-circle m-auto"><i class="fas fa-play"></i></span> </a> </div>
        </div>
      </section>
    )
}
