import React from 'react'

export default function Faq() {
    return (
        <section className="section bg-white">
      <div className="container">
        <h2 className="text-9 text-center">Frequently Asked Questions</h2>
        <p className="text-4 text-center mb-4 mb-sm-5">Can't find it here? Check out our <a href="help.html">Help center</a></p>
        <div className="row">
          <div className="col-md-10 col-lg-8 mx-auto">
            <hr className="mb-0" />
            <div className="accordion accordion-alternate arrow-right" id="popularTopics">
              <div className="card">
                <div className="card-header" id="heading1">
                  <h5 className="mb-0"> <a href="#" className="collapsed" data-toggle="collapse" data-target="#collapse1" aria-expanded="false" aria-controls="collapse1">What is Payyed?</a> </h5>
                </div>
                <div id="collapse1" className="collapse" aria-labelledby="heading1" data-parent="#popularTopics">
                  <div className="card-body"> Lisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure. Mutat tacimates id sit. Ridens mediocritatem ius an, eu nec magna imperdiet. </div>
                </div>
              </div>
              <div className="card">
                <div className="card-header" id="heading2">
                  <h5 className="mb-0"> <a href="#" className="collapsed" data-toggle="collapse" data-target="#collapse2" aria-expanded="false" aria-controls="collapse2">How to send money online?</a> </h5>
                </div>
                <div id="collapse2" className="collapse" aria-labelledby="heading2" data-parent="#popularTopics">
                  <div className="card-body"> Iisque Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. </div>
                </div>
              </div>
              <div className="card">
                <div className="card-header" id="heading3">
                  <h5 className="mb-0"> <a href="#" className="collapsed" data-toggle="collapse" data-target="#collapse3" aria-expanded="false" aria-controls="collapse3">Is my money safe with Payyed?</a> </h5>
                </div>
                <div id="collapse3" className="collapse" aria-labelledby="heading3" data-parent="#popularTopics">
                  <div className="card-body"> Iisque persius interesset his et, in quot quidam persequeris vim, ad mea essent possim iriure. Mutat tacimates id sit. Ridens mediocritatem ius an, eu nec magna imperdiet. </div>
                </div>
              </div>
              <div className="card">
                <div className="card-header" id="heading4">
                  <h5 className="mb-0"> <a href="#" className="collapsed" data-toggle="collapse" data-target="#collapse4" aria-expanded="false" aria-controls="collapse4">How much fees does Payyed charge?</a> </h5>
                </div>
                <div id="collapse4" className="collapse" aria-labelledby="heading4" data-parent="#popularTopics">
                  <div className="card-body"> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. </div>
                </div>
              </div>
              <div className="card">
                <div className="card-header" id="heading5">
                  <h5 className="mb-0"> <a href="#" className="collapsed" data-toggle="collapse" data-target="#collapse5" aria-expanded="false" aria-controls="collapse5">What is the fastest way to send money abroad?</a> </h5>
                </div>
                <div id="collapse5" className="collapse" aria-labelledby="heading5" data-parent="#popularTopics">
                  <div className="card-body"> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. </div>
                </div>
              </div>
              <div className="card">
                <div className="card-header" id="heading6">
                  <h5 className="mb-0"> <a href="#" className="collapsed" data-toggle="collapse" data-target="#collapse6" aria-expanded="false" aria-controls="collapse6">Can I open an Payyed account for business?</a> </h5>
                </div>
                <div id="collapse6" className="collapse" aria-labelledby="heading6" data-parent="#popularTopics">
                  <div className="card-body"> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. </div>
                </div>
              </div>
            </div>
            <hr className="mt-0"/>
          </div>
        </div>
        <div className="text-center mt-4"><a href="#" className="btn-link text-4">See more FAQ<i className="fas fa-chevron-right text-2 ml-2"></i></a></div>
      </div>
    </section>
    )
}
