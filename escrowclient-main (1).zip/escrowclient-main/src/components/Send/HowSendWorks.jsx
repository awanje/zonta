import React from 'react'

export default function HowSendWorks() {
    return (
        <section className="section bg-white">
      <div className="container">
        <h2 className="text-9 text-center"> The simple way to Buy Something</h2>
        <p className="text-4 text-center mb-5">Just get the details listed and buy it with payment protection.</p>
        <div className="row">
          <div className="col-lg-4 mb-4">
            <div className="featured-box style-3">
              <div className="featured-box-icon text-light"><span className="w-100 text-20 font-weight-500">1</span></div>
              <h3>Sign Up Your Account</h3>
              <p className="text-3">Become a register user first, then log in to your account and enter your card or bank details that is required for you.</p>
            </div>
          </div>
          <div className="col-lg-4 mb-4">
            <div className="featured-box style-3">
              <div className="featured-box-icon text-light"><span className="w-100 text-20 font-weight-500">2</span></div>
              <h3>Select Your Seller</h3>
              <p className="text-3">Enter your seller's email address then add an amount with currency to send securely.</p>
            </div>
          </div>
          <div className="col-lg-4 mb-4 mb-sm-0">
            <div className="featured-box style-3">
              <div className="featured-box-icon text-light"><span className="w-100 text-20 font-weight-500">3</span></div>
              <h3>Initiate Deal</h3>
              <p className="text-3">After you intiate deal, the seller will be notified via an email and your deal will be confirmed once he agrees to the agreement.</p>
            </div>
          </div>
        </div>
        <div className="text-center mt-2"><a href="/signup" className="btn btn-outline-primary shadow-none text-uppercase">Sign up Now</a></div>
      </div>
    </section>
    )
}
