import React from 'react'

export default function HeroSection() {
    return (
        <section className="page-header page-header-text-light py-0 mb-0">
	<section className="hero-wrap section">
    <div className="hero-mask opacity-7 bg-dark"></div>
    <div className="hero-bg hero-bg-scroll" style={{backgroundImage:"url('./images/bg/image-2.jpg')"}}></div>
    <div className="hero-content">
      <div className="container">
        <div className="row">
          <div className="col-12 text-center">
            <h1 className="text-11 font-weight-500 text-white mb-4">About Payyed</h1>
            <p className="text-5 text-white line-height-4 mb-4">Our mission is to help you save on transfer fees and exchange rates!</p>
            <a href="/#" className="btn btn-primary m-2">Open a Free Account</a> <a className="btn btn-outline-light video-btn m-2" href="/#" data-src="https://www.youtube.com/embed/7e90gBu4pas" data-toggle="modal" data-target="#videoModal"><span className="mr-2"><i className="fas fa-play-circle"></i></span>See How it Works</a> </div>
        </div>
      </div>
    </div>
  </section>
    </section>
    )
}
