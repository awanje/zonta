import React from 'react'

export default function Investors() {
    return (
        <section className="section bg-white">
      <div className="container">
        <h2 className="text-9 text-center">Our Investors</h2>
        <p className="text-4 text-center mb-5">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
        <div className="brands-grid separator-border">
          <div className="row align-items-center">
            <div className="col-6 col-sm-4 col-lg-2 text-center"><a href=""><img className="img-fluid" src="images/partner/partner-1.png" alt="Brands" /></a></div>
            <div className="col-6 col-sm-4 col-lg-2 text-center"><a href=""><img className="img-fluid" src="images/partner/partner-2.png" alt="Brands" /></a></div>
            <div className="col-6 col-sm-4 col-lg-2 text-center"><a href=""><img className="img-fluid" src="images/partner/partner-3.png" alt="Brands" /></a></div>
            <div className="col-6 col-sm-4 col-lg-2 text-center"><a href=""><img className="img-fluid" src="images/partner/partner-4.png" alt="Brands" /></a></div>
            <div className="col-6 col-sm-4 col-lg-2 text-center"><a href=""><img className="img-fluid" src="images/partner/partner-5.png" alt="Brands" /></a></div>
            <div className="col-6 col-sm-4 col-lg-2 text-center"><a href=""><img className="img-fluid" src="images/partner/partner-6.png" alt="Brands" /></a></div>
            <div className="col-6 col-sm-4 col-lg-2 text-center"><a href=""><img className="img-fluid" src="images/partner/partner-7.png" alt="Brands" /></a></div>
            <div className="col-6 col-sm-4 col-lg-2 text-center"><a href=""><img className="img-fluid" src="images/partner/partner-8.png" alt="Brands" /></a></div>
            <div className="col-6 col-sm-4 col-lg-2 text-center"><a href=""><img className="img-fluid" src="images/partner/partner-9.png" alt="Brands" /></a></div>
            <div className="col-6 col-sm-4 col-lg-2 text-center"><a href=""><img className="img-fluid" src="images/partner/partner-10.png" alt="Brands" /></a></div>
            <div className="col-6 col-sm-4 col-lg-2 text-center"><a href=""><img className="img-fluid" src="images/partner/partner-11.png" alt="Brands" /></a></div>
            <div className="col-6 col-sm-4 col-lg-2 text-center"><a href=""><img className="img-fluid" src="images/partner/partner-1.png" alt="Brands" /></a></div>
          </div>
        </div>
      </div>
    </section>
    )
}
