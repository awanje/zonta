import React , {useEffect} from 'react'
import PreLoader from '../mini_features/PreLoader.jsx'
import NavBar from '../menu/NavBarWhite.jsx'
import Hero from './HeroSection'
import WhoWeAre from './WhoWeAre'
import OurValues from './OurValues'
import Leadership from './Leadership'
import Investors from './Investors'
import ServiceCountBanner from '../common/ServiceCountBanner'
import Footer from '../common/Footer'
import Testimonial from '../common/Testimonial'
import $ from 'jquery'

export default function About() {
    useEffect(() => {
        $('[data-loader="circle-side"]').fadeOut() 
              $('#preloader').delay(333).fadeOut('slow')
              $('body').delay(333) 
      })
    return (
        <>
            <PreLoader />
            <NavBar />
            <Hero />
            <WhoWeAre />
            <OurValues />
            <Leadership />
            <Investors />
            <Testimonial />
            <ServiceCountBanner />
            <Footer />
        </>
    )
}
