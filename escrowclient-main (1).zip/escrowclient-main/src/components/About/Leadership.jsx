import React from 'react'

export default function Leadership() {
    return (
        <section className="section">
      <div className="container">
        <h2 className="text-9 text-center">Leadership</h2>
        <p className="text-4 text-center mb-5">Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
        <div className="row">
          <div className="col-sm-6 col-md-3 text-center mb-4 mb-md-0">
            <div className="team rounded d-inline-block"> <img className="img-fluid rounded" alt="" src="images/team/leader.jpg" />
              <h3>Neil Patel</h3>
              <p className="text-muted">CEO &amp; Founder</p>
              <ul className="social-icons social-icons-sm d-inline-flex">
                <li className="social-icons-facebook"><a data-toggle="tooltip" href="#" target="_blank" title="" data-original-title="Facebook"><i className="fab fa-facebook-f"></i></a></li>
                <li className="social-icons-twitter"><a data-toggle="tooltip" href="" target="_blank" title="" data-original-title="Twitter"><i className="fab fa-twitter"></i></a></li>
                <li className="social-icons-google"><a data-toggle="tooltip" href="" target="_blank" title="" data-original-title="Google"><i className="fab fa-google"></i></a></li>
              </ul>
            </div>
          </div>
          <div className="col-sm-6 col-md-3 text-center mb-4 mb-md-0">
            <div className="team rounded d-inline-block"> <img className="img-fluid rounded" alt="" src="images/team/leader-2.jpg" />
              <h3>James Maxwell</h3>
              <p className="text-muted">Co-Founder</p>
              <ul className="social-icons social-icons-sm d-inline-flex">
                <li className="social-icons-facebook"><a data-toggle="tooltip" href="" target="_blank" title="" data-original-title="Facebook"><i className="fab fa-facebook-f"></i></a></li>
                <li className="social-icons-twitter"><a data-toggle="tooltip" href="" target="_blank" title="" data-original-title="Twitter"><i className="fab fa-twitter"></i></a></li>
                <li className="social-icons-google"><a data-toggle="tooltip" href="" target="_blank" title="" data-original-title="Google"><i className="fab fa-google"></i></a></li>
              </ul>
            </div>
          </div>
          <div className="col-sm-6 col-md-3 text-center mb-4 mb-md-0">
            <div className="team rounded d-inline-block"> <img className="img-fluid rounded" alt="" src="images/team/leader-3.jpg" />
              <h3>Ruby Clinton</h3>
              <p className="text-muted">Chief Marketing Officer</p>
              <ul className="social-icons social-icons-sm d-inline-flex">
                <li className="social-icons-facebook"><a data-toggle="tooltip" href="" target="_blank" title="" data-original-title="Facebook"><i className="fab fa-facebook-f"></i></a></li>
                <li className="social-icons-twitter"><a data-toggle="tooltip" href="" target="_blank" title="" data-original-title="Twitter"><i className="fab fa-twitter"></i></a></li>
                <li className="social-icons-google"><a data-toggle="tooltip" href="" target="_blank" title="" data-original-title="Google"><i className="fab fa-google"></i></a></li>
              </ul>
            </div>
          </div>
          <div className="col-sm-6 col-md-3 text-center mb-4 mb-md-0">
            <div className="team rounded d-inline-block"> <img className="img-fluid rounded" alt="" src="images/team/leader-4.jpg" />
              <h3>Miky Sheth</h3>
              <p className="text-muted">General Manager</p>
              <ul className="social-icons social-icons-sm d-inline-flex">
                <li className="social-icons-facebook"><a data-toggle="tooltip" href="" target="_blank" title="" data-original-title="Facebook"><i className="fab fa-facebook-f"></i></a></li>
                <li className="social-icons-twitter"><a data-toggle="tooltip" href="" target="_blank" title="" data-original-title="Twitter"><i className="fab fa-twitter"></i></a></li>
                <li className="social-icons-google"><a data-toggle="tooltip" href="" target="_blank" title="" data-original-title="Google"><i className="fab fa-google"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
    )
}
